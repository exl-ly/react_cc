import type { Initiative, Status } from "./initiatives";

// Share of an initiative's budget considered "at risk", weighted by status.
export const RISK_FACTOR: Record<Status, number> = {
  "off-track": 0.4,
  attention: 0.2,
  "on-track": 0,
};

// How each signal contributes to the composite attention score (sums to 1).
export const WEIGHTS = {
  severity: 0.4,
  valueAtRisk: 0.35,
  slippage: 0.25,
};

// Status severity on a 0..1 scale (off-track most severe).
export const SEVERITY: Record<Status, number> = {
  "off-track": 1,
  attention: 0.6,
  "on-track": 0,
};

// Estimated dollars at risk ($M) = budget x status risk factor.
export const valueAtRiskM = (i: Initiative): number =>
  Math.round(i.budgetM * RISK_FACTOR[i.status]);

// How far behind plan an initiative is right now (0 when on/ahead of plan).
export const slippage = (i: Initiative): number =>
  Math.max(0, i.originalPlan - i.progress);

/**
 * Composite attention score in 0..1 for each initiative, combining status
 * severity, value at risk, and plan slippage. Value at risk and slippage are
 * normalized across the provided set so the three signals are comparable.
 */
export function scoreInitiatives(list: Initiative[]): Map<string, number> {
  const maxVar = Math.max(1, ...list.map(valueAtRiskM));
  const maxSlip = Math.max(1, ...list.map(slippage));

  const scores = new Map<string, number>();
  for (const i of list) {
    const score =
      WEIGHTS.severity * SEVERITY[i.status] +
      WEIGHTS.valueAtRisk * (valueAtRiskM(i) / maxVar) +
      WEIGHTS.slippage * (slippage(i) / maxSlip);
    scores.set(i.id, score);
  }
  return scores;
}

/**
 * Assigns a unique fine-grained rank (1..N) to every initiative.
 *
 * Hybrid model: items are first ordered by composite score (highest first) to
 * get a computed rank. A per-initiative `rankOverride` then pins/reorders
 * specific items; everything is finally re-sorted by effective rank (ties
 * broken by score) to produce a unique 1..N ordering.
 */
export function rankInitiatives(
  list: Initiative[]
): Map<string, { rank: number; score: number }> {
  const scores = scoreInitiatives(list);

  const computed = [...list].sort(
    (a, b) => (scores.get(b.id) ?? 0) - (scores.get(a.id) ?? 0)
  );

  const computedRank = new Map<string, number>();
  computed.forEach((i, idx) => computedRank.set(i.id, idx + 1));

  const ordered = [...list].sort((a, b) => {
    const aRank = a.rankOverride ?? computedRank.get(a.id) ?? 0;
    const bRank = b.rankOverride ?? computedRank.get(b.id) ?? 0;
    if (aRank !== bRank) return aRank - bRank;
    return (scores.get(b.id) ?? 0) - (scores.get(a.id) ?? 0);
  });

  const result = new Map<string, { rank: number; score: number }>();
  ordered.forEach((i, idx) =>
    result.set(i.id, { rank: idx + 1, score: scores.get(i.id) ?? 0 })
  );
  return result;
}
