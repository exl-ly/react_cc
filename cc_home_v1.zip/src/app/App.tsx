import { useState, useMemo, useRef } from "react";
import {
  Search,
  LayoutGrid,
  List,
  RefreshCw,
  ChevronDown,
  ChevronRight,
  Table2,
} from "lucide-react";
import { ThemeProvider, useTheme } from "./theme-context";
import { FastHeader } from "./components/fast-header";
import { Sidebar } from "./components/sidebar";
import { InitiativeTable } from "./components/initiative-table";
import { PriorityBoard } from "./components/priority-board";
import { CommandCenter } from "./components/command-center";
import { INITIATIVES } from "./data/initiatives";
import { rankInitiatives } from "./data/scoring";

const PRIORITY_TIER: Record<string, string> = {
  Critical: "P1",
  High: "P2",
  Medium: "P3",
};

export default function App() {
  return (
    <ThemeProvider>
      <Portal />
    </ThemeProvider>
  );
}

function Portal() {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";

  const [activeLeader, setActiveLeader] = useState<string | null>(null);
  const [activePillar, setActivePillar] = useState<string | null>(null);
  const [activeStatus, setActiveStatus] = useState<string | null>(null);
  const [activeTower, setActiveTower] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activePriority, setActivePriority] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grouped" | "flat">("grouped");
  const [tableOpen, setTableOpen] = useState(false);
  const [focus, setFocus] = useState<{ name: string; nonce: number } | null>(null);
  const mainScrollRef = useRef<HTMLDivElement | null>(null);
  const rankMap = useMemo(() => rankInitiatives(INITIATIVES), []);

  const filtered = useMemo(() => INITIATIVES.filter((i) => {
    if (activeLeader && i.leader !== activeLeader) return false;
    if (activePillar && i.pillar !== activePillar) return false;
    if (activeStatus && i.status !== activeStatus) return false;
    if (activeTower && i.tower !== activeTower) return false;
    if (activeCategory && i.category !== activeCategory) return false;
    if (activePriority && i.priority !== activePriority) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return i.name.toLowerCase().includes(q) || i.id.toLowerCase().includes(q) || i.leader.toLowerCase().includes(q) || i.statusNote.toLowerCase().includes(q);
    }
    return true;
  }), [activeLeader, activePillar, activeStatus, activeTower, activeCategory, activePriority, searchQuery]);

  const hasFilters = activeLeader || activePillar || activeStatus || activeTower || activeCategory || activePriority || searchQuery;
  const resetOverview = () => {
    setActiveLeader(null);
    setActivePillar(null);
    setActiveStatus(null);
    setActiveTower(null);
    setActiveCategory(null);
    setActivePriority(null);
    setSearchQuery("");
    mainScrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  const toolbarBg = isLight ? "#ffffff" : "#0c1018";
  const footerBg = isLight ? "#ffffff" : "#0c1018";

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: theme.bg, color: theme.textPrimary, fontFamily: "var(--font-sans, Roboto, system-ui, sans-serif)", overflow: "hidden", transition: "background 0.2s, color 0.2s" }}>
      <FastHeader
        initiatives={INITIATIVES} filteredInitiatives={filtered} activePillar={activePillar} onPillarFilter={setActivePillar}
        activeStatus={activeStatus}
        onStatusFilter={setActiveStatus}
        onHomeClick={resetOverview}
      />

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          {/* Toolbar */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 16px", background: toolbarBg, borderBottom: `1px solid ${theme.border}`, flexShrink: 0, boxShadow: isLight ? "0 1px 3px rgba(60,64,67,0.06)" : "none" }}>
            {/* Search */}
            <div style={{ position: "relative", flex: 1, maxWidth: 340 }}>
              <Search size={13} color={theme.textTertiary} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }} />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search initiatives, leaders, notes..."
                style={{ width: "100%", background: isLight ? "#f1f3f4" : "#161b28", border: `1px solid ${theme.border}`, borderRadius: 20, padding: "6px 12px 6px 32px", color: theme.textPrimary, fontSize: 12, outline: "none", boxSizing: "border-box", fontFamily: "inherit" }}
              />
            </div>

            {/* Active filter chips */}
            <div style={{ display: "flex", gap: 6, flex: 1, flexWrap: "wrap" }}>
              {activeTower && <FTag label={`Tower: ${activeTower}`} onRemove={() => setActiveTower(null)} theme={theme} />}
              {activeCategory && <FTag label={`Category: ${activeCategory}`} onRemove={() => setActiveCategory(null)} theme={theme} />}
              {activeLeader && <FTag label={`Leader: ${activeLeader}`} onRemove={() => setActiveLeader(null)} theme={theme} />}
              {activePillar && <FTag label={`Pillar: ${activePillar}`} onRemove={() => setActivePillar(null)} theme={theme} />}
              {activeStatus && <FTag label={`Status: ${activeStatus}`} onRemove={() => setActiveStatus(null)} theme={theme} />}
              {activePriority && <FTag label={`Priority: ${PRIORITY_TIER[activePriority] ?? activePriority}`} onRemove={() => setActivePriority(null)} theme={theme} />}
              {hasFilters && (
                <button onClick={resetOverview} style={{ background: "none", border: "none", color: theme.textTertiary, fontSize: 11, cursor: "pointer", padding: "2px 6px", display: "flex", alignItems: "center", gap: 4, fontFamily: "inherit" }}>
                  <RefreshCw size={10} /> Clear all
                </button>
              )}
            </div>

            <div style={{ color: theme.textTertiary, fontSize: 11, whiteSpace: "nowrap" }}>
              <span style={{ color: theme.brandPrimary, fontWeight: 600 }}>{filtered.length}</span> of {INITIATIVES.length} initiatives
            </div>

            {/* View toggle */}
            <div style={{ display: "flex", background: isLight ? "#f1f3f4" : "#161b28", border: `1px solid ${theme.border}`, borderRadius: 8, overflow: "hidden" }}>
              {(["grouped", "flat"] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  title={mode === "grouped" ? "Group by pillar" : "Flat list"}
                  style={{ background: viewMode === mode ? theme.brandPrimaryBg : "transparent", border: "none", padding: "5px 10px", cursor: "pointer", display: "flex", alignItems: "center", color: viewMode === mode ? theme.brandPrimary : theme.textTertiary, transition: "all 0.15s" }}
                >
                  {mode === "grouped" ? <LayoutGrid size={13} /> : <List size={13} />}
                </button>
              ))}
            </div>
          </div>

          {/* Priority action board + collapsible detailed table */}
          <div ref={mainScrollRef} style={{ flex: 1, overflowY: "auto", scrollbarWidth: "thin", scrollbarColor: `${theme.border} transparent` }}>
            <CommandCenter
              initiatives={INITIATIVES}
              rankMap={rankMap}
              activeTower={activeTower}
              onTowerSelect={(t) => setActiveTower(activeTower === t ? null : t)}
              activePriority={activePriority}
              onPrioritySelect={(p) => setActivePriority(activePriority === p ? null : p)}
              onSelectInitiative={(ini) => {
                setTableOpen(true);
                setFocus({ name: ini.name, nonce: Date.now() });
              }}
            />

            <PriorityBoard
              initiatives={filtered}
              rankMap={rankMap}
              onSelect={(ini) => {
                setTableOpen(true);
                setFocus({ name: ini.name, nonce: Date.now() });
              }}
            />

            {/* Dive deeper: detailed portfolio table (collapsed by default) */}
            <div style={{ padding: "0 16px 20px" }}>
              <div
                onClick={() => setTableOpen((o) => !o)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "11px 14px",
                  background: toolbarBg,
                  border: `1px solid ${theme.border}`,
                  borderRadius: 10,
                  cursor: "pointer",
                  boxShadow: isLight ? "0 1px 2px rgba(60,64,67,0.06)" : "none",
                }}
              >
                <div style={{ color: theme.textTertiary, display: "flex" }}>
                  {tableOpen ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
                </div>
                <Table2 size={14} color={theme.textSecondary} />
                <span style={{ color: theme.textPrimary, fontSize: 13, fontWeight: 600 }}>
                  Initiative Portfolio Overview
                </span>
                <span style={{ color: theme.textTertiary, fontSize: 11 }}>
                  {tableOpen ? "Hide" : "Expand to dive deeper"} ·{" "}
                  <span style={{ color: theme.textSecondary, fontWeight: 600 }}>{filtered.length}</span> initiatives
                </span>
              </div>

              {tableOpen && (
                <div
                  style={{
                    marginTop: 8,
                    border: `1px solid ${theme.border}`,
                    borderRadius: 10,
                    overflow: "hidden",
                  }}
                >
                  <InitiativeTable initiatives={filtered} groupByPillar={viewMode === "grouped" && !activePillar} focus={focus} />
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div style={{ padding: "6px 20px", background: footerBg, borderTop: `1px solid ${theme.divider}`, display: "flex", alignItems: "center", justifyContent: "flex-end", flexShrink: 0 }}>
            <div style={{ color: theme.textTertiary, fontSize: 10, fontFamily: "var(--font-mono, monospace)", opacity: 0.6 }}>
              FY2025 Strategic Portfolio · Confidential
            </div>
          </div>
        </div>

        <Sidebar
          activeLeader={activeLeader} onLeaderChange={setActiveLeader}
          activePillar={activePillar} onPillarChange={setActivePillar}
          activeStatus={activeStatus} onStatusChange={setActiveStatus}
          activeTower={activeTower} onTowerChange={setActiveTower}
          activeCategory={activeCategory} onCategoryChange={setActiveCategory}
          scopeInitiatives={filtered}
        />
      </div>
    </div>
  );
}

function FTag({ label, onRemove, theme }: { label: string; onRemove: () => void; theme: ReturnType<typeof useTheme>["theme"] }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "3px 8px", background: theme.brandPrimaryBg, border: `1px solid ${theme.chipActiveBorder}`, borderRadius: 12, color: theme.brandPrimary, fontSize: 11, fontWeight: 500 }}>
      {label}
      <button onClick={onRemove} style={{ background: "none", border: "none", cursor: "pointer", color: theme.brandPrimary, padding: 0, lineHeight: 1, fontSize: 14, display: "flex", alignItems: "center" }}>×</button>
    </div>
  );
}
