import { useState, type ReactNode } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { LEADERS, CATEGORIES, type Initiative } from "../data/initiatives";
import { useTheme } from "../theme-context";

interface SidebarProps {
  activeLeader: string | null;
  onLeaderChange: (l: string | null) => void;
  activePillar: string | null;
  onPillarChange: (p: string | null) => void;
  activeStatus: string | null;
  onStatusChange: (s: string | null) => void;
  activeTower: string | null;
  onTowerChange: (t: string | null) => void;
  activeCategory: string | null;
  onCategoryChange: (c: string | null) => void;
  scopeInitiatives: Initiative[];
}

const AVATAR_COLORS = [
  "#4285f4",
  "#7b1fa2",
  "#0097a7",
  "#e65100",
  "#1e8e3e",
  "#d93025",
];

const initials = (name: string) =>
  name
    .split(" ")
    .map((n) => n[0])
    .join("");
const avatarColor = (name: string) =>
  AVATAR_COLORS[LEADERS.indexOf(name as any) % AVATAR_COLORS.length];

export function Sidebar({
  activeLeader,
  onLeaderChange,
  activePillar,
  onPillarChange,
  activeStatus,
  onStatusChange,
  activeTower,
  onTowerChange,
  activeCategory,
  onCategoryChange,
  scopeInitiatives,
}: SidebarProps) {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";
  const [isTowersExpanded, setIsTowersExpanded] = useState(true);
  const [isCategoriesExpanded, setIsCategoriesExpanded] = useState(true);
  const [isLeadersExpanded, setIsLeadersExpanded] = useState(true);

  const PILLARS = [
    { key: "Fast", color: theme.pillarFast, label: "Focus" },
    { key: "Acceleration", color: theme.pillarAccel, label: "Acceleration" },
    { key: "Scale", color: theme.pillarScale, label: "Scale" },
    { key: "Transform", color: theme.pillarTrans, label: "Transformation" },
  ];

  const STATUSES = [
    { key: "on-track", label: "On Track", color: theme.onTrack },
    { key: "attention", label: "Needs Attention", color: theme.attention },
    { key: "off-track", label: "Off Track", color: theme.offTrack },
  ];

  const TOWERS = [
    { key: "AI", color: "#7b1fa2" },
    { key: "Prod and Dev", color: "#34a853" },
    { key: "Breakthrough", color: "#fbbc04" },
    { key: "Cross-GPT", color: "#ea4335" },
    { key: "Enterprise Tech", color: "#4285f4" },
  ];

  const scopedTowerStats = TOWERS.map((t) => ({
    ...t,
    count: scopeInitiatives.filter((i) => i.tower === t.key).length,
  })).filter((t) => t.count > 0);

  const scopedCategoryStats = CATEGORIES.map((c) => ({
    key: c,
    count: scopeInitiatives.filter((i) => i.category === c).length,
  })).filter((c) => c.count > 0);

  const scopedLeaderStats = LEADERS.map((leaderName) => ({
    leaderName,
    count: scopeInitiatives.filter((i) => i.leader === leaderName).length,
    onTrack: scopeInitiatives.filter(
      (i) => i.leader === leaderName && i.status === "on-track"
    ).length,
    offTrack: scopeInitiatives.filter(
      (i) => i.leader === leaderName && i.status === "off-track"
    ).length,
    attention: scopeInitiatives.filter(
      (i) => i.leader === leaderName && i.status === "attention"
    ).length,
  })).filter((l) => l.count > 0);

  const base: React.CSSProperties = {
    width: 232,
    minWidth: 232,
    background: theme.sidebarBg,
    borderLeft: `1px solid ${theme.sidebarBorder}`,
    display: "flex",
    flexDirection: "column",
    height: "100%",
    overflowY: "auto",
    scrollbarWidth: "none",
    boxShadow: isLight ? "-2px 0 6px rgba(60,64,67,0.06)" : "none",
  };

  return (
    <div style={base}>
      <Section
        label="Towers"
        theme={theme}
        collapsible
        isExpanded={isTowersExpanded}
        onToggle={() => setIsTowersExpanded(!isTowersExpanded)}
      >
        <FilterChip
          active={activeTower === null}
          color={theme.brandPrimary}
          theme={theme}
          onClick={() => onTowerChange(null)}
        >
          All Towers
          <span
            style={{
              marginLeft: "auto",
              color: theme.textTertiary,
              fontSize: 11,
            }}
          >
            {scopeInitiatives.length}
          </span>
        </FilterChip>
        {scopedTowerStats.map((t) => (
          <FilterChip
            key={t.key}
            active={activeTower === t.key}
            color={t.color}
            theme={theme}
            onClick={() => onTowerChange(activeTower === t.key ? null : t.key)}
          >
            {t.key}
            <span
              style={{
                marginLeft: "auto",
                color: theme.textTertiary,
                fontSize: 11,
              }}
            >
              {t.count}
            </span>
          </FilterChip>
        ))}
      </Section>

      <Divider theme={theme} />

      <Section
        label="Categories"
        theme={theme}
        collapsible
        isExpanded={isCategoriesExpanded}
        onToggle={() => setIsCategoriesExpanded(!isCategoriesExpanded)}
      >
        <FilterChip
          active={activeCategory === null}
          color={theme.brandPrimary}
          theme={theme}
          onClick={() => onCategoryChange(null)}
        >
          All Categories
          <span
            style={{
              marginLeft: "auto",
              color: theme.textTertiary,
              fontSize: 11,
            }}
          >
            {scopeInitiatives.length}
          </span>
        </FilterChip>
        {scopedCategoryStats.map((c) => (
          <FilterChip
            key={c.key}
            active={activeCategory === c.key}
            color={theme.brandPrimary}
            theme={theme}
            onClick={() =>
              onCategoryChange(activeCategory === c.key ? null : c.key)
            }
          >
            {c.key}
            <span
              style={{
                marginLeft: "auto",
                color: theme.textTertiary,
                fontSize: 11,
              }}
            >
              {c.count}
            </span>
          </FilterChip>
        ))}
      </Section>

      <Divider theme={theme} />

      <Section
        label="Leaders"
        theme={theme}
        collapsible
        isExpanded={isLeadersExpanded}
        onToggle={() => setIsLeadersExpanded(!isLeadersExpanded)}
      >
        <LeaderChip
          active={activeLeader === null}
          onClick={() => onLeaderChange(null)}
          theme={theme}
        >
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              background: isLight ? "#e8eaed" : theme.elevated,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <span
              style={{
                color: theme.textTertiary,
                fontSize: 10,
                fontWeight: 700,
              }}
            >
              ALL
            </span>
          </div>
          <span
            style={{
              color: theme.textSecondary,
              fontSize: 12,
              fontWeight: 500,
            }}
          >
            All Leaders
          </span>
          <span
            style={{
              marginLeft: "auto",
              color: theme.textTertiary,
              fontSize: 11,
              fontWeight: 500,
            }}
          >
            {scopeInitiatives.length}
          </span>
        </LeaderChip>

        {isLeadersExpanded &&
          scopedLeaderStats.map(({ leaderName, ...stats }) => {
            const isActive = activeLeader === leaderName;
            return (
              <button
                key={leaderName}
                onClick={() => onLeaderChange(isActive ? null : leaderName)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  width: "100%",
                  padding: "7px 10px",
                  borderRadius: 8,
                  border: "none",
                  cursor: "pointer",
                  background: isActive ? theme.chipActiveBg : "transparent",
                  outline: isActive
                    ? `1.5px solid ${theme.chipActiveBorder}`
                    : "none",
                  transition: "all 0.15s",
                  textAlign: "left",
                }}
              >
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: "50%",
                    background: avatarColor(leaderName),
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#fff",
                    fontSize: 11,
                    fontWeight: 700,
                    flexShrink: 0,
                    letterSpacing: "0.01em",
                  }}
                >
                  {initials(leaderName)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      color: isActive ? theme.brandPrimary : theme.textPrimary,
                      fontSize: 12,
                      fontWeight: 500,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {leaderName}
                  </div>
                  <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
                    {stats.onTrack > 0 && (
                      <span
                        style={{
                          color: theme.onTrack,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.onTrack}↑
                      </span>
                    )}
                    {stats.attention > 0 && (
                      <span
                        style={{
                          color: theme.attention,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.attention}!
                      </span>
                    )}
                    {stats.offTrack > 0 && (
                      <span
                        style={{
                          color: theme.offTrack,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.offTrack}↓
                      </span>
                    )}
                  </div>
                </div>
                <span
                  style={{
                    color: isActive ? theme.brandPrimary : theme.textTertiary,
                    fontSize: 12,
                    fontWeight: 600,
                    flexShrink: 0,
                  }}
                >
                  {stats.count}
                </span>
              </button>
            );
          })}
      </Section>

      <Divider theme={theme} />

      {/* <Section label="FAST Pillar" theme={theme}>
        <FilterChip active={activePillar === null} color={theme.brandPrimary} theme={theme} onClick={() => onPillarChange(null)}>
          All Pillars
        </FilterChip>
        {PILLARS.map((p) => (
          <FilterChip key={p.key} active={activePillar === p.key} color={p.color} theme={theme} onClick={() => onPillarChange(activePillar === p.key ? null : p.key)}>
            <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 18, height: 18, borderRadius: 4, background: `${p.color}18`, border: `1px solid ${p.color}44`, color: p.color, fontSize: 10, fontWeight: 700, flexShrink: 0 }}>{p.key[0]}</span>
            {p.label}
            <span style={{ marginLeft: "auto", color: theme.textTertiary, fontSize: 11 }}>{INITIATIVES.filter((i) => i.pillar === p.key).length}</span>
          </FilterChip>
        ))}
      </Section> */}

      {/* <Divider theme={theme} />

      <Section label="Status" theme={theme}>
        <FilterChip
          active={activeStatus === null}
          color={theme.brandPrimary}
          theme={theme}
          onClick={() => onStatusChange(null)}
        >
          All Status
        </FilterChip>
        {STATUSES.map((s) => (
          <FilterChip
            key={s.key}
            active={activeStatus === s.key}
            color={s.color}
            theme={theme}
            onClick={() =>
              onStatusChange(activeStatus === s.key ? null : s.key)
            }
          >
            <div
              style={{
                width: 9,
                height: 9,
                borderRadius: "50%",
                background: s.color,
                flexShrink: 0,
              }}
            />
            {s.label}
            <span
              style={{
                marginLeft: "auto",
                color: theme.textTertiary,
                fontSize: 11,
              }}
            >
              {INITIATIVES.filter((i) => i.status === s.key).length}
            </span>
          </FilterChip>
        ))}
      </Section> */}
    </div>
  );
}

function Section({
  label,
  children,
  theme,
  collapsible,
  isExpanded,
  onToggle,
}: {
  label: string;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
  collapsible?: boolean;
  isExpanded?: boolean;
  onToggle?: () => void;
}) {
  return (
    <div style={{ padding: "12px 8px 8px" }}>
      <div
        onClick={collapsible ? onToggle : undefined}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 4,
          cursor: collapsible ? "pointer" : "default",
          marginBottom: 4,
          padding: "0 4px",
          userSelect: "none",
        }}
      >
        <div
          style={{
            color: theme.textTertiary,
            fontSize: 10,
            fontWeight: 700,
            letterSpacing: "0.1em",
          }}
        >
          {label.toUpperCase()}
        </div>
        {collapsible && (
          <div
            style={{
              color: theme.textTertiary,
              display: "flex",
              alignItems: "center",
            }}
          >
            {isExpanded ? (
              <ChevronDown size={12} />
            ) : (
              <ChevronRight size={12} />
            )}
          </div>
        )}
      </div>
      {(!collapsible || isExpanded) && (
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {children}
        </div>
      )}
    </div>
  );
}

function LeaderChip({
  active,
  onClick,
  children,
  theme,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
}) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        width: "100%",
        padding: "7px 10px",
        borderRadius: 8,
        border: "none",
        cursor: "pointer",
        background: active ? theme.chipActiveBg : "transparent",
        outline: active ? `1.5px solid ${theme.chipActiveBorder}` : "none",
        transition: "all 0.15s",
        textAlign: "left",
      }}
    >
      {children}
    </button>
  );
}

function FilterChip({
  active,
  color,
  onClick,
  children,
  theme,
}: {
  active: boolean;
  color: string;
  onClick: () => void;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
}) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        width: "100%",
        padding: "6px 10px",
        borderRadius: 8,
        border: "none",
        cursor: "pointer",
        background: active ? `${color}12` : "transparent",
        outline: active ? `1.5px solid ${color}44` : "none",
        color: active ? color : theme.textSecondary,
        fontSize: 12,
        fontWeight: active ? 500 : 400,
        transition: "all 0.15s",
        textAlign: "left",
      }}
    >
      {children}
    </button>
  );
}

function Divider({ theme }: { theme: ReturnType<typeof useTheme>["theme"] }) {
  return (
    <div style={{ height: 1, background: theme.divider, margin: "4px 0" }} />
  );
}
