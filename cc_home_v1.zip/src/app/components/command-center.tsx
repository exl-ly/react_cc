import { AlertTriangle, Sparkles, XCircle } from "lucide-react";
import type { Initiative, Pillar, Status } from "../data/initiatives";
import { valueAtRiskM } from "../data/scoring";
import { useTheme } from "../theme-context";

interface CommandCenterProps {
  initiatives: Initiative[];
  rankMap: Map<string, { rank: number; score: number }>;
  activeTower: string | null;
  onTowerSelect: (tower: string) => void;
  activePriority: string | null;
  onPrioritySelect: (priority: string) => void;
  onSelectInitiative: (ini: Initiative) => void;
}

const PRIORITIES: { key: Initiative["priority"]; tier: string }[] = [
  { key: "Critical", tier: "P1" },
  { key: "High", tier: "P2" },
  { key: "Medium", tier: "P3" },
];

const PRIORITY_TIER: Record<string, string> = {
  Critical: "P1",
  High: "P2",
  Medium: "P3",
};

const STATUS_LABEL: Record<Status, string> = {
  "on-track": "On Track",
  "off-track": "Off Track",
  attention: "Needs Attention",
};

const PILLAR_LETTER: Record<Pillar, string> = {
  Focus: "F",
  Acceleration: "A",
  Scale: "S",
  Transform: "T",
};

type Theme = ReturnType<typeof useTheme>["theme"];

function statusCounts(items: Initiative[]) {
  return {
    on: items.filter((i) => i.status === "on-track").length,
    att: items.filter((i) => i.status === "attention").length,
    off: items.filter((i) => i.status === "off-track").length,
  };
}

function healthColor(items: Initiative[], theme: Theme) {
  if (items.length === 0) return theme.textTertiary;
  if (items.some((i) => i.status === "off-track")) return theme.offTrack;
  if (items.some((i) => i.status === "attention")) return theme.attention;
  return theme.onTrack;
}

function formatM(n: number): string {
  return `$${n}M`;
}

function SectionTitle({ children, theme }: { children: React.ReactNode; theme: Theme }) {
  return (
    <div
      style={{
        color: theme.textTertiary,
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        marginBottom: 8,
      }}
    >
      {children}
    </div>
  );
}

export function CommandCenter({
  initiatives,
  rankMap,
  activeTower,
  onTowerSelect,
  activePriority,
  onPrioritySelect,
  onSelectInitiative,
}: CommandCenterProps) {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";

  const towers = Array.from(new Set(initiatives.map((i) => i.tower)));

  const cardBase: React.CSSProperties = {
    background: theme.surface,
    border: `1px solid ${theme.border}`,
    borderRadius: 9,
    boxShadow: isLight ? "0 1px 2px rgba(60,64,67,0.05)" : "none",
  };

  const rankOf = (i: Initiative) => rankMap.get(i.id)?.rank ?? Number.MAX_SAFE_INTEGER;
  const topAttention = [...initiatives]
    .filter((i) => i.status !== "on-track")
    .sort((a, b) => rankOf(a) - rankOf(b))
    .slice(0, 3);

  // ── AI Executive Commentary (derived) ──
  const atRisk = initiatives.filter((i) => i.status !== "on-track");
  const totalAtRiskM = atRisk.reduce((sum, i) => sum + valueAtRiskM(i), 0);

  const towerRisk = new Map<string, number>();
  atRisk.forEach((i) => towerRisk.set(i.tower, (towerRisk.get(i.tower) ?? 0) + valueAtRiskM(i)));
  const topTowers = Array.from(towerRisk.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([t]) => t);

  const tiers = Array.from(new Set(topAttention.map((i) => PRIORITY_TIER[i.priority]))).sort();

  const commentary = [
    {
      label: "Why these items",
      value: `${tiers.join("/") || "Top"} - off-track or behind plan, high value at risk`,
    },
    {
      label: "Business impact",
      value: `${formatM(totalAtRiskM)} estimated value at risk across ${atRisk.length} initiatives`,
    },
    {
      label: "Pattern detected",
      value: topTowers.length
        ? `${topTowers.join(" and ")} drive most risk`
        : "No concentrated risk detected",
    },
    {
      label: "Recommended action",
      value: `Review top ${topAttention.length} recovery plans this week`,
    },
  ];

  return (
    <div style={{ padding: "16px 16px 0", display: "flex", flexDirection: "column", gap: 16 }}>
      {/* AI Executive Commentary + Top Attention Items */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
          gap: 8,
          alignItems: "start",
        }}
      >
        {/* Left: AI Executive Commentary */}
        <div>
          <SectionTitle theme={theme}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
              <Sparkles size={11} color={theme.brandPrimary} />
              AI Executive Commentary
            </span>
          </SectionTitle>
          <div style={{ ...cardBase, padding: "12px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
            {commentary.map((c) => (
              <div key={c.label}>
                <div style={{ color: theme.textTertiary, fontSize: 9, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 2 }}>
                  {c.label}
                </div>
                <div style={{ color: theme.textPrimary, fontSize: 12, lineHeight: 1.35 }}>
                  {c.value}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Top Attention Items */}
        <div>
          <SectionTitle theme={theme}>Top Attention Items</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {topAttention.length === 0 ? (
              <div style={{ ...cardBase, padding: "12px 14px", color: theme.textTertiary, fontSize: 12 }}>
                No off-track or attention initiatives.
              </div>
            ) : (
              topAttention.map((ini) => {
                const color = ini.status === "off-track" ? theme.offTrack : theme.attention;
                const Icon = ini.status === "off-track" ? XCircle : AlertTriangle;
                const riskM = valueAtRiskM(ini);
                const rank = rankMap.get(ini.id)?.rank;
                return (
                  <button
                    key={ini.name}
                    onClick={() => onSelectInitiative(ini)}
                    title="Open in portfolio table"
                    style={{
                      ...cardBase,
                      borderLeft: `3px solid ${color}`,
                      padding: "9px 14px",
                      display: "flex",
                      flexDirection: "column",
                      gap: 3,
                      cursor: "pointer",
                      textAlign: "left",
                      fontFamily: "inherit",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      {rank != null && (
                        <span style={{ color, fontSize: 11, fontWeight: 800, fontFamily: "var(--font-mono)", flexShrink: 0 }}>
                          #{rank}
                        </span>
                      )}
                      <span style={{ width: 9, height: 9, borderRadius: "50%", background: color, flexShrink: 0 }} />
                      <span style={{ color: theme.textPrimary, fontSize: 13, fontWeight: 600, flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {ini.name}
                      </span>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 5, color, fontSize: 11, fontWeight: 600, whiteSpace: "nowrap" }}>
                        <Icon size={11} color={color} strokeWidth={2.5} />
                        {STATUS_LABEL[ini.status]}
                      </span>
                    </div>
                    <div style={{ color: theme.textTertiary, fontSize: 11, fontFamily: "var(--font-mono)" }}>
                      {PILLAR_LETTER[ini.pillar]} {ini.pillar} · {ini.tower} · {PRIORITY_TIER[ini.priority]}
                    </div>
                    {riskM > 0 && (
                      <div style={{ color: theme.textSecondary, fontSize: 11, fontWeight: 600 }}>
                        Impact: <span style={{ color }}>{formatM(riskM)} at risk</span>
                      </div>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Business Tower Health */}
      <div>
        <SectionTitle theme={theme}>Business Tower Health</SectionTitle>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {towers.map((tower) => {
            const items = initiatives.filter((i) => i.tower === tower);
            const c = statusCounts(items);
            const dot = healthColor(items, theme);
            const budgetM = items.reduce((sum, i) => sum + i.budgetM, 0);
            const active = activeTower === tower;
            return (
              <button
                key={tower}
                onClick={() => onTowerSelect(tower)}
                title={`Filter by tower: ${tower}`}
                style={{
                  ...cardBase,
                  borderColor: active ? theme.brandPrimary : theme.border,
                  boxShadow: active ? `0 0 0 2px ${theme.brandPrimary}22` : cardBase.boxShadow,
                  padding: "10px 12px",
                  minWidth: 180,
                  flex: "1 1 180px",
                  textAlign: "left",
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ width: 9, height: 9, borderRadius: "50%", background: dot, flexShrink: 0 }} />
                  <span style={{ color: theme.textPrimary, fontSize: 13, fontWeight: 600, flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {tower}
                  </span>
                  <span style={{ color: theme.textSecondary, fontSize: 12, fontWeight: 700, fontFamily: "var(--font-mono)" }}>
                    {items.length}
                  </span>
                </div>
                <div style={{ marginTop: 5, fontSize: 10, color: theme.textTertiary }}>
                  <span style={{ color: theme.onTrack, fontWeight: 600 }}>{c.on} On</span>
                  {" · "}
                  <span style={{ color: theme.attention, fontWeight: 600 }}>{c.att} Att</span>
                  {" · "}
                  <span style={{ color: theme.offTrack, fontWeight: 600 }}>{c.off} Off</span>
                </div>
                <div style={{ marginTop: 3, fontSize: 10, color: theme.textTertiary }}>
                  Budget exposure:{" "}
                  <span style={{ color: theme.textSecondary, fontWeight: 600, fontFamily: "var(--font-mono)" }}>
                    {formatM(budgetM)}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Priority x Tower Heatmap */}
      <div>
        <SectionTitle theme={theme}>Priority x Tower Heatmap</SectionTitle>
        <div
          style={{
            ...cardBase,
            padding: 10,
            display: "grid",
            gridTemplateColumns: `minmax(96px, 0.7fr) repeat(${towers.length}, 1fr)`,
            gap: 6,
          }}
        >
          <div />
          {towers.map((tower) => (
            <div
              key={tower}
              title={tower}
              style={{ color: theme.textTertiary, fontSize: 10, fontWeight: 700, textAlign: "center", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", padding: "0 4px" }}
            >
              {tower}
            </div>
          ))}

          {PRIORITIES.map((p) => (
            <Row
              key={p.key}
              priority={p}
              towers={towers}
              initiatives={initiatives}
              theme={theme}
              isLight={isLight}
              activePriority={activePriority}
              activeTower={activeTower}
              onPrioritySelect={onPrioritySelect}
              onTowerSelect={onTowerSelect}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function Row({
  priority,
  towers,
  initiatives,
  theme,
  isLight,
  activePriority,
  activeTower,
  onPrioritySelect,
  onTowerSelect,
}: {
  priority: { key: Initiative["priority"]; tier: string };
  towers: string[];
  initiatives: Initiative[];
  theme: Theme;
  isLight: boolean;
  activePriority: string | null;
  activeTower: string | null;
  onPrioritySelect: (priority: string) => void;
  onTowerSelect: (tower: string) => void;
}) {
  return (
    <>
      <div style={{ display: "flex", alignItems: "center", color: theme.textSecondary, fontSize: 11, fontWeight: 600 }}>
        <span style={{ color: theme.textPrimary, fontWeight: 800, marginRight: 6 }}>{priority.tier}</span>
        {priority.key}
      </div>
      {towers.map((tower) => {
        const items = initiatives.filter((i) => i.priority === priority.key && i.tower === tower);
        const dot = healthColor(items, theme);
        const active = activePriority === priority.key && activeTower === tower;
        return (
          <button
            key={tower}
            onClick={() => {
              onPrioritySelect(priority.key);
              onTowerSelect(tower);
            }}
            title={`${priority.tier} ${priority.key} - ${tower}: ${items.length}`}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
              padding: "6px 4px",
              borderRadius: 7,
              border: active ? `1.5px solid ${theme.brandPrimary}` : `1px solid ${theme.border}`,
              background: active
                ? `${theme.brandPrimary}14`
                : isLight
                  ? "rgba(0,0,0,0.015)"
                  : "rgba(255,255,255,0.02)",
              cursor: items.length ? "pointer" : "default",
              fontFamily: "inherit",
              opacity: items.length ? 1 : 0.55,
            }}
          >
            <span style={{ width: 8, height: 8, borderRadius: "50%", background: dot, flexShrink: 0 }} />
            <span style={{ color: theme.textPrimary, fontSize: 12, fontWeight: 700, fontFamily: "var(--font-mono)" }}>
              {items.length}
            </span>
          </button>
        );
      })}
    </>
  );
}
