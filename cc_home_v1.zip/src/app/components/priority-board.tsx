import { useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
} from "lucide-react";
import type { Initiative, Pillar } from "../data/initiatives";
import { useTheme } from "../theme-context";

interface PriorityBoardProps {
  initiatives: Initiative[];
  rankMap: Map<string, { rank: number; score: number }>;
  onSelect?: (ini: Initiative) => void;
}

type Tier = "P1" | "P2" | "P3";

const TIER_OF: Record<Initiative["priority"], Tier> = {
  Critical: "P1",
  High: "P2",
  Medium: "P3",
};

const TIERS: {
  key: Tier;
  label: string;
  caption: string;
  defaultOpen: boolean;
}[] = [
  { key: "P1", label: "Critical", caption: "Act now", defaultOpen: true },
  { key: "P2", label: "High", caption: "Monitor closely", defaultOpen: false },
  { key: "P3", label: "Medium", caption: "Track", defaultOpen: false },
];

const PILLAR_LETTER: Record<Pillar, string> = {
  Focus: "F",
  Acceleration: "A",
  Scale: "S",
  Transform: "T",
};

const CARD_GRID_TEMPLATE =
  "44px 48px minmax(200px, 1.6fr) 124px 92px 96px 104px 112px";

export function PriorityBoard({ initiatives, rankMap, onSelect }: PriorityBoardProps) {
  const { theme } = useTheme();

  const rankOf = (i: Initiative) =>
    rankMap.get(i.id)?.rank ?? Number.MAX_SAFE_INTEGER;

  return (
    <div style={{ padding: "16px 16px 8px" }}>
      {TIERS.map((tier) => {
        const items = initiatives
          .filter((i) => TIER_OF[i.priority] === tier.key)
          .sort((a, b) => rankOf(a) - rankOf(b));
        return (
          <PriorityGroup
            key={tier.key}
            tier={tier}
            items={items}
            theme={theme}
            rankMap={rankMap}
            onSelect={onSelect}
          />
        );
      })}
    </div>
  );
}

function PriorityGroup({
  tier,
  items,
  theme,
  rankMap,
  onSelect,
}: {
  tier: (typeof TIERS)[number];
  items: Initiative[];
  theme: ReturnType<typeof useTheme>["theme"];
  rankMap: Map<string, { rank: number; score: number }>;
  onSelect?: (ini: Initiative) => void;
}) {
  const [open, setOpen] = useState(tier.defaultOpen);
  const isLight = theme.mode === "light";

  const total = items.length;
  const onTrack = items.filter((i) => i.status === "on-track").length;
  const attention = items.filter((i) => i.status === "attention").length;
  const offTrack = items.filter((i) => i.status === "off-track").length;

  const tierColor =
    tier.key === "P1"
      ? theme.offTrack
      : tier.key === "P2"
        ? theme.attention
        : theme.textTertiary;

  return (
    <div style={{ marginBottom: 14 }}>
      {/* Group header */}
      <div
        onClick={() => setOpen((o) => !o)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "10px 12px",
          background: theme.surface,
          border: `1px solid ${theme.border}`,
          borderLeft: `3px solid ${tierColor}`,
          borderRadius: 10,
          cursor: "pointer",
          boxShadow: isLight ? "0 1px 2px rgba(60,64,67,0.06)" : "none",
        }}
      >
        <div style={{ color: theme.textTertiary, display: "flex" }}>
          {open ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
        </div>

        <div
          style={{
            padding: "3px 9px",
            borderRadius: 7,
            background: `${tierColor}1a`,
            color: tierColor,
            fontSize: 13,
            fontWeight: 800,
            letterSpacing: "0.02em",
            flexShrink: 0,
          }}
        >
          {tier.key}
        </div>

        <div style={{ minWidth: 0 }}>
          <div
            style={{
              color: theme.textPrimary,
              fontSize: 13,
              fontWeight: 600,
              lineHeight: 1.2,
            }}
          >
            {tier.label}
            <span
              style={{
                color: theme.textTertiary,
                fontWeight: 400,
                marginLeft: 8,
              }}
            >
              {tier.caption}
            </span>
          </div>
        </div>

        <div
          style={{
            marginLeft: "auto",
            display: "flex",
            alignItems: "center",
            gap: 14,
          }}
        >
          {/* Health ratio bar */}
          {total > 0 && (
            <div
              style={{
                width: 120,
                height: 5,
                display: "flex",
                borderRadius: 999,
                overflow: "hidden",
                background: theme.divider,
              }}
            >
              <div
                style={{
                  width: `${(onTrack / total) * 100}%`,
                  background: theme.onTrack,
                }}
              />
              <div
                style={{
                  width: `${(attention / total) * 100}%`,
                  background: theme.attention,
                }}
              />
              <div
                style={{
                  width: `${(offTrack / total) * 100}%`,
                  background: theme.offTrack,
                }}
              />
            </div>
          )}
          <div
            style={{
              color: theme.textSecondary,
              fontSize: 12,
              fontWeight: 600,
              whiteSpace: "nowrap",
            }}
          >
            <span style={{ color: theme.textPrimary }}>{total}</span> item
            {total === 1 ? "" : "s"}
          </div>
        </div>
      </div>

      {/* Cards */}
      {open && (
        <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 6 }}>
          {items.length > 0 && (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: CARD_GRID_TEMPLATE,
                alignItems: "center",
                gap: 12,
                padding: "6px 14px",
                borderRadius: 8,
                border: `1px solid ${theme.border}`,
                background: isLight ? "#f8f9fa" : "#0c1018",
                color: theme.textTertiary,
                fontSize: 9,
                fontWeight: 700,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                position: "sticky",
                top: 0,
                zIndex: 3,
              }}
            >
              <span style={{ opacity: 0.9 }}>Rank</span>
              <span style={{ opacity: 0.9 }}>Pillar</span>
              <span style={{ opacity: 0.9 }}>Initiative</span>
              <span style={{ opacity: 0.9 }}>Status</span>
              <span style={{ opacity: 0.9 }}>Owner</span>
              <span style={{ opacity: 0.9 }}>Budget</span>
              <span style={{ opacity: 0.9 }}>Due</span>
              <span style={{ opacity: 0.9 }}>% Complete</span>
            </div>
          )}
          {items.length === 0 ? (
            <div
              style={{
                padding: "16px 12px",
                color: theme.textTertiary,
                fontSize: 12,
                textAlign: "center",
              }}
            >
              No {tier.key} initiatives match the current filters.
            </div>
          ) : (
            items.map((ini) => (
              <ActionCard
                key={ini.name}
                ini={ini}
                theme={theme}
                rank={rankMap.get(ini.id)?.rank}
                onSelect={onSelect}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
}

function ActionCard({
  ini,
  theme,
  rank,
  onSelect,
}: {
  ini: Initiative;
  theme: ReturnType<typeof useTheme>["theme"];
  rank?: number;
  onSelect?: (ini: Initiative) => void;
}) {
  const isLight = theme.mode === "light";

  const STATUS = {
    "on-track": {
      label: "On Track",
      color: theme.onTrack,
      bg: theme.onTrackBg,
      border: theme.onTrackBorder,
      Icon: CheckCircle2,
    },
    "off-track": {
      label: "Off Track",
      color: theme.offTrack,
      bg: theme.offTrackBg,
      border: theme.offTrackBorder,
      Icon: XCircle,
    },
    attention: {
      label: "Needs Attention",
      color: theme.attention,
      bg: theme.attentionBg,
      border: theme.attentionBorder,
      Icon: AlertTriangle,
    },
  } as const;

  const PILLAR_COLOR: Record<Pillar, string> = {
    Focus: theme.pillarFast,
    Acceleration: theme.pillarAccel,
    Scale: theme.pillarScale,
    Transform: theme.pillarTrans,
  };

  const sm = STATUS[ini.status];
  const pillarColor = PILLAR_COLOR[ini.pillar] ?? theme.textTertiary;
  const days = Math.ceil(
    (new Date(ini.dueDate).getTime() - Date.now()) / 86400000
  );
  const overdue = days < 0;
  const note = (ini.statusNote || "").replace(/\n/g, " ").trim();

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onSelect?.(ini)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect?.(ini);
        }
      }}
      title="View full details in the portfolio table"
      style={{
        display: "grid",
        gridTemplateColumns: CARD_GRID_TEMPLATE,
        alignItems: "center",
        gap: 12,
        padding: "10px 14px",
        background: theme.surface,
        border: `1px solid ${theme.border}`,
        borderLeft: `3px solid ${sm.color}`,
        borderRadius: 9,
        boxShadow: isLight ? "0 1px 2px rgba(60,64,67,0.05)" : "none",
        cursor: "pointer",
        transition: "transform 0.12s, box-shadow 0.12s, border-color 0.12s",
        outline: "none",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-1px)";
        e.currentTarget.style.boxShadow = `0 4px 14px ${sm.color}22`;
        e.currentTarget.style.borderColor = `${sm.color}55`;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = isLight
          ? "0 1px 2px rgba(60,64,67,0.05)"
          : "none";
        e.currentTarget.style.borderColor = theme.border;
      }}
    >
      {/* Rank badge */}
      <div
        title="Priority rank (lower = address first)"
        style={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          minWidth: 30,
          padding: "2px 6px",
          borderRadius: 6,
          background: `${sm.color}14`,
          border: `1px solid ${sm.color}33`,
          color: sm.color,
          fontSize: 11,
          fontWeight: 800,
          fontFamily: "var(--font-mono)",
          justifySelf: "start",
        }}
      >
        {rank != null ? `#${rank}` : "-"}
      </div>

      {/* Pillar chip */}
      <div
        title={ini.pillar}
        style={{
          width: 20,
          height: 20,
          borderRadius: 5,
          background: `${pillarColor}15`,
          border: `1px solid ${pillarColor}40`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 10,
          fontWeight: 800,
          color: pillarColor,
        }}
      >
        {PILLAR_LETTER[ini.pillar] ?? "?"}
      </div>

      {/* Name + note */}
      <div style={{ minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
          <span
            style={{
              color: theme.textPrimary,
              fontSize: 13,
              fontWeight: 600,
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {ini.name}
          </span>
          <span
            style={{
              color: theme.textTertiary,
              fontSize: 10,
              fontFamily: "var(--font-mono)",
              flexShrink: 0,
            }}
          >
            {ini.id}
          </span>
        </div>
        {note && (
          <div
            style={{
              color: theme.textTertiary,
              fontSize: 11,
              marginTop: 2,
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {note}
          </div>
        )}
      </div>

      {/* Status pill */}
      <div>
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 5,
            padding: "3px 8px",
            borderRadius: 12,
            background: sm.bg,
            border: `1px solid ${sm.border}`,
          }}
        >
          <sm.Icon size={9} color={sm.color} strokeWidth={2.5} />
          <span
            style={{
              color: sm.color,
              fontSize: 10,
              fontWeight: 600,
              whiteSpace: "nowrap",
            }}
          >
            {sm.label}
          </span>
        </div>
      </div>

      {/* Leader */}
      <div
        style={{
          color: theme.textSecondary,
          fontSize: 11,
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        }}
        title={ini.leader}
      >
        {ini.leader}
      </div>

      {/* Budget */}
      <div style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}>
        <span style={{ color: theme.textTertiary, fontSize: 9 }}>Budget</span>
        <span
          style={{
            color: theme.textSecondary,
            fontSize: 11,
            fontWeight: 600,
            fontFamily: "var(--font-mono)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
          title={ini.budget}
        >
          {ini.budget}
        </span>
      </div>

      {/* Due date + days left */}
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        <span
          style={{
            color: theme.textSecondary,
            fontSize: 10,
            fontFamily: "var(--font-mono)",
            display: "flex",
            alignItems: "center",
            gap: 4,
          }}
        >
          <Clock size={9} color={overdue ? theme.offTrack : theme.textTertiary} />
          {ini.dueDate}
        </span>
        <span
          style={{
            color: overdue ? theme.offTrack : theme.textTertiary,
            fontSize: 9,
            fontWeight: 500,
          }}
        >
          {overdue ? `${Math.abs(days)}d overdue` : `${days}d left`}
        </span>
      </div>

      {/* Progress */}
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "baseline",
          }}
        >
          <span style={{ color: theme.textTertiary, fontSize: 9 }}>Progress</span>
          <span
            style={{
              color: sm.color,
              fontSize: 11,
              fontWeight: 600,
              fontFamily: "var(--font-mono)",
            }}
          >
            {ini.progress}%
          </span>
        </div>
        <div
          style={{
            height: 4,
            borderRadius: 2,
            background: theme.divider,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              width: `${ini.progress}%`,
              height: "100%",
              background: sm.color,
              borderRadius: 2,
            }}
          />
        </div>
      </div>
    </div>
  );
}
