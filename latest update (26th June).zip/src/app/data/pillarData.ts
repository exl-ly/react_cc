import { Pillar } from "./pillarTypes";

export const pillarData: Pillar[] = [
  {
    id: "fast",
    name: "Focus",
    color: "#010035",

    initiatives: [
      {
        id: "fast-1",
        name: "Next Gen - Lyric",
        score: 78,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "Next Gen Delivery Progress",
            type: "progress",
            value: 65,
            cardWidth: true,
          },

          {
            id: "m2",
            label: "Client NPS",
            type: "score",
            value: 40,
            trend: "(+4 last month)",
            cardWidth: false,
          },

          {
            id: "m5",
            label: "Customer Count / New Logos",
            type: "score",
            value: 22,
            trend: "(+6 YoY)",
            cardWidth: false,
          },

          {
            id: "m6",
            label: "Client Migration Progress",
            type: "progress",
            value: 48,
            cardWidth: true,
          },
        ],
      },
      {
        id: "fast-2",
        name: "Next Gen - WFN",
        score: 78,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "Next Gen Delivery Progress",
            type: "progress",
            value: 40,
            cardWidth: true,
          },

          {
            id: "m2",
            label: "Client NPS",
            type: "score",
            value: 26,
            trend: "(+2 last month)",
            cardWidth: true,
          },
          {
            id: "m6",
            label: "Client Migration Progress",
            type: "progress",
            value: 35,
            cardWidth: true,
          },
        ],
      },
      {
        id: "fast-3",
        name: "Next Gen - E-NG",
        score: 78,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "Next Gen Delivery Progress",
            type: "progress",
            value: 10,
            cardWidth: true,
          },

          {
            id: "m2",
            label: "Client NPS",
            type: "score",
            value: 15,
            trend: "(+1 last month)",
            cardWidth: true,
          },

          {
            id: "m5",
            label: "Customer Count / New Logos",
            type: "score",
            value: 8,
            trend: "(+3 YoY)",
            cardWidth: true,
          },

          {
            id: "m6",
            label: "Client Migration Progress",
            type: "progress",
            value: 15,
            cardWidth: true,
          },
        ],
      },

      {
        id: "fast-4",
        name: "Deliver on BU Strat Plan Priorities",
        score: 71,
        health: "Needs Attention",
        lastUpdatedAt:"Dec 2025",
        

        metrics: [
          {
            id: "m1",
            label: "Execution Progress",
            type: "progress",
            value: 52,
            cardWidth: true,
          },

          {
            id: "m2",
            label: "Cost CAGR",
            type: "milestone",
            current: "6.4%",
            target: "3.7%",
            cardWidth: true,
            responsible:true
          },

          {
            id: "m3",
            label: "Cost Realization",
            type: "milestone",
            current: "-",
            target: "$390M",
            cardWidth: true,
          },
        ],
      },

      {
        id: "fast-5",
        name: "Deliver on Functional Priorities (Sales, Service, Finance)",
        score: 64,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "Associate Profile",
            type: "milestone",
            current: "-",
            target: "65k",
            cardWidth: true,
          },

          {
            id: "m2",
            label: "Core HR & Payroll",
            type: "milestone",
            current: "-",
            target: "35k",
            cardWidth: true,
          },

          {
            id: "m3",
            label: "Adoption & Usage (%)",
            type: "progress",
            value: 55,
            cardWidth: true,
          },
        ],
      },

      {
        id: "fast-6",
        name: "Other Key Initiatives (PI Acceleration, SAP Rise)",
        score: 82,
        health: "Needs Attention",
        lastUpdatedAt:"Dec 2025",

        metrics: [
          {
            id: "m1",
            label: "PR Rollout Progress",
            type: "milestone",
            current: "31 countries",
            target: "75 countries",
            cardWidth: true,
            responsible:true
          },

          {
            id: "m2",
            label: "Client Migration Progress",
            type: "progress",
            value: 75,
            cardWidth: true,
          },

          {
            id: "m3",
            label: "Revenue Realization",
            type: "milestone",
            current: "-",
            target: "$8M",
            cardWidth: true,
          },
          {
            id: "m4",
            label: "SAP Cloud Migration Progress",
            type: "milestone",
            current: "52",
            target: "-",
            cardWidth: true,
          },
        ],
      },
    ],
  },

  {
    id: "accelerate",
    name: "Accelerate",
    color: "#7C3AED",

    initiatives: [
      {
        id: "acc-1",
        name: "AI Foundation",

        score: 81,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label:
              "AI Execution Progress % (Execution Progress and Data Central Progress)",
            type: "progress",
            value: 60,
            cardWidth: true,
          },
          {
            id: "m2",
            label: "Cost Savings Realization",
            type: "milestone",
            current: "-",
            target: "$19M",
            cardWidth: true,
          },

          {
            id: "m3",
            label: "Churn Rate Reduction",
            type: "progress",
            value: 8,
            cardWidth: true,
          },

          {
            id: "m4",
            label: "Call Avoidance",
            type: "milestone",
            current: "-",
            target: "200k",
            cardWidth: true,
          },
        ],
      },
      // {
      //   id: "acc-2",
      //   name: "AI Outcome",

      //   score: 69,
      //   health: "Null Track",

      //   metrics: [
      //     {
      //       id: "m1",
      //       label: "Revenue Impact Improvement / Revenue Realization",
      //       type: "currentTarget",
      //       current: "Gross - $10M Net - $5M",
      //       target: "Gross - $30M Net - $15M",
      //       // type: "number",
      //       // value: "Gross - 30 Net - 15",
      //       cardWidth: true,
      //     },
      //     {
      //       id: "m2",
      //       label: "Operational Efficiency Improvement (%)",
      //       type: "progress",
      //       value: 60,
      //       cardWidth: true,
      //     },

      //     {
      //       id: "m3",
      //       label: "Cost Saving",
      //       type: "currentTarget",
      //       current: "$40M",
      //       target: "$120M",
      //       cardWidth: true,
      //     },
      //   ],
      // },

      {
        id: "acc-3",
        name: "AI Enablement",

        score: 69,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "AI Tools Access (%)",
            type: "progress",
            value: 58,
            cardWidth: true,
          },
          {
            id: "m2",
            label: "AI Tool adoption (%)",
            type: "progress",
            value: 58,
            cardWidth: true,
          },

          {
            id: "m3",
            label: "AI Training Coverage Progress (%)",
            type: "progress",
            value: 84,
            cardWidth: true,
          },

          // {
          //   id: "m2",
          //   label: "Milestones",
          //   type: "milestone",
          //   current: 14,
          //   target: 22,
          // },

          // {
          //   id: "m3",
          //   label: "Coverage",
          //   type: "progress",
          //   value: 62,
          // },
        ],
      },

      // {
      //   id: "acc-4",
      //   name: "AI Delivery",

      //   score: 69,
      //   health: "Null Track",

      //   metrics: [
      //     {
      //       id: "m1",
      //       label: "Persona Coverage (%)",
      //       type: "progress",
      //       value: 58,
      //       cardWidth: true,
      //     },
      //     // {
      //     //   id: "m2",
      //     //   label: "Agent Rollout",
      //     //   type: "progress",
      //     //   value: "28 last Qtr",
      //     // },
      //     {
      //       id: "m2",
      //       type: "score",
      //       label: "Agent Rollout",
      //       value: 28,
      //       cardWidth: true,
      //     },

      //     {
      //       id: "m3",
      //       label: "Persona agent adoption rate %",
      //       type: "progress",
      //       value: 84,
      //       cardWidth: true,
      //     },
      //   ],
      // },
      {
        id: "acc-5",
        name: "AI Strategy",

        score: 69,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "AI BU roadmap execution %",
            type: "progress",
            value: 58,
            cardWidth: true,
          },
          {
            id: "m2",
            label: "Productivity Benefit %",
            type: "progress",
            value: 58,
            cardWidth: true,
          },

          {
            id: "m3",
            label: "White Papers published (Quarter/Year)",
            type: "score",
            value: 10,
            cardWidth: true,
          },
        ],
      },
      {
        id: "acc-6",
        name: "AI (E+Digital Employee)",

        score: 69,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "Digital Employee Deployment (%)",
            type: "progress",
            value: 72,
            cardWidth: true,
          },
        ],
      },
      {
        id: "acc-7",
        name: "AI NG acceleration",

        score: 69,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "Migration & Implementation Progress (%)",
            type: "progress",
            value: 58,
            cardWidth: true,
          },
          {
            id: "m2",
            label: "Productivity & Speed Impact (%)",
            type: "progress",
            value: 58,
            cardWidth: true,
          },

          // {
          //   id: "m3",
          //   label: "White Papers published (Quarter/Year)",
          //   type: "number",
          //   value: 84,
          // },
        ],
      },
      {
        id: "acc-8",
        name: "TAM Expansion",

        score: 69,
        health: "Null Track",
        lastUpdatedAt:"NA",

        metrics: [
          {
            id: "m1",
            label: "Revenue Generated",
            type: "currency",
            current: "-",
            target: "$120M",
            cardWidth: true,
          },
          {
            id: "m2",
            label: "New Markets",
            type: "number",
            value: 40,
            cardWidth: true,
          },
        ],
      },
    ],
  },

  {
    id: "scale",
    name: "Scale",
    color: "#0891B2",
 
    initiatives: [
      {
        id: "scale-1",
        name: "Breakthrough Revenue",
 
        score: 84,
        health: "Null Track",
        lastUpdatedAt:"NA",
 
        metrics: [
          {
            id: "m1",
            label: "Breakthrough Overall Revenue",
            type: "progress",
            value: 43,
            current: "$145M",
            target: "$340M",
            cardWidth: true,
          },
          {
            id: "m2",
            label: "Marketplace (Revenue & Margin)",
            type: "currentTarget",
            current: "$45M",
            target: "$110M",
            cardWidth: true,
          },
          {
            id: "m3",
            label: "Data Solutions (Revenue & Margin)",
            type: "currentTarget",
            current: "$60M",
            target: "$157M",
            cardWidth: true,
          },
          {
            id: "m4",
            label: "Ventures (Invt. Gain & Revenue Contribution)",
            type: "currentTarget",
            current: "$40M",
            target: "$73M",
            cardWidth: true,
          },
        ],
      },
    ],
  },

  {
    id: "transform",
    name: "Transform",
    color: "#EA580C",

    initiatives: [
      {
        id: "trans-9",
        name: "Risk and Resiliency",

        score: 67,
        health: "Needs Attention",
        lastUpdatedAt:"March 2026",

        metrics: [
          {
            id: "m1",
            label: "Client availability ",
            type: "number",
            value: 99.9921,
            cardWidth: true,
            // current: "99.9921%",
            // target: "99.9999%",
          },
          {
            id: "m2",
            label: "MTTD",
            type: "milestone",
            // current: "5.55 YTD",
            // target: "<=8.05 YTD(41.40 % YoY improvement)",
            current: "41.39% YoY",
            target: ">=15% YoY",
            cardWidth: true,
          },
          {
            id: "m3",
            label: "MTTR",
            type: "milestone",
            // current: "20.52 YTD",
            // target: "<=19.45 YTD(10.21% YoY Improvement)",
            current: "10.21% YoY",
            target: ">=15% YoY",
            cardWidth: true,
            responsible:true
          },
          {
            id: "m4",
            label: "Critical Incident Volume",
            type: "milestone",
            // value: "22.5% YOY Reduction",
            current: "22.5% YOY",
            target: ">10% YOY",
            cardWidth: true,
            // trend: "(+4 last month)",
          },
        ],
      },
      {
        id: "trans-7",
        name: "Cloud Migration",

        score: 67,
        health: "On Track",
        lastUpdatedAt:"May 2026",

        metrics: [
          {
            id: "m1",
            label: "Cloud Migration Progress (%)",
            type: "progress",
            // value: 13,
            value: 16,
            cardWidth: true,
          },

          {
            id: "m2",
            // label: "Migration Adherence (%)",
            label: "Migration by Business Units",
            type: "milestone",
            // value: 92,
            current: "2K",
            target: "41K",
            cardWidth: true,
          },
          {
            id: "m3",
            label: "Legacy Decommission",
            type: "milestone",
            current: "7458",
            target: "41K",
            cardWidth: true,
          },
        ],
      },
      {
        id: "trans-1",
        name: "GPT Global Delivery Model",

        score: 73,
        health: "Needs Attention",
        lastUpdatedAt: "Dec 2025",

        metrics: [
          {
            id: "m1",
            label: "Resource Mix ratio",
            type: "milestone",
            current: "94:6",
            target: "90:10",
            cardWidth: true,
            responsible:true
          },

          {
            id: "m2",
            label: "Geo Mix ratio",
            type: "milestone",
            current: "56:9:35",
            target: "35:25:40",
            cardWidth: true,
            responsible:true
          },

          {
            id: "m3",
            label: "Microsite exited",            
            type: "milestone",
            current: "-",
            target: "20 Sites",
            // current: "$20M",
            // target: "$40M",
            cardWidth: true,
          },
          {
            id: "m4",
            label: "Cost Realization",
            type: "milestone",
            current: "-",
            target: "$70M",
            cardWidth: true,
          },
        ],
      },

      {
        id: "trans-2",
        name: "Vendor Management(TESM)",

        score: 67,
        health: "Needs Attention",
        lastUpdatedAt: "Dec 2025",

        metrics: [
          {
            id: "m1",
            label: "Saving Realization",
            type: "milestone",
            current: "-",
            target: "$140M",
            // type: "number",
            // value: "$140M",
            cardWidth: true,
          },

          {
            id: "m2",
            label: "Cost CAGR",
            type: "milestone",
            // current: "7.8%",
            // target: "3.7%",
            current: "10.5%",
            target: "4%",
            cardWidth: true,
            responsible:true
          },
        ],
      },
      {
        id: "trans-3",
        name: "SDLC/ADLC",

        score: 67,
        health: "Null Track",
        lastUpdatedAt: "Dec 2025",

        metrics: [
          {
            id: "m1",
            label: "Saving Realization",
            type: "milestone",
            current: "-",
            target: "$150M",
            cardWidth: true,
          },
        ],
      },

      {
        id: "trans-5",
        name: "Stakeholder Excellence",

        score: 67,
        health: "Null Track",
        lastUpdatedAt: "Dec 2025",

        metrics: [
          {
            id: "m1",
            label: "NPS Score",
            type: "milestone",
            // current: "32",
            // target: "40+",
            current: "-",
            target: "40+",
            cardWidth: true,
          },
          {
            id: "m2",
            label: "Participation Rate %",
            type: "progress",
            value: 87,
            cardWidth: true,
          },

          {
            id: "m3",
            label: "Engagement Level",
            type: "number",
            // value: 83,
            value: 82,
            cardWidth: true,
          },
        ],
      },
      {
        id: "trans-6",
        name: "People Excellence (Workforce & Talent Strategy)",

        score: 67,
        health: "Null Track",
        lastUpdatedAt: "Dec 2025",

        metrics: [
          {
            id: "m1",
            label: "Internal mobility Rate %",
            type: "progress",
            value: 20,
            cardWidth: true,
          },
          {
            id: "m2",
            label: "MyVoiceleadership Score",
            type: "milestone",
            current: "17",
            target: ">= ADP Average",
            // trend: "(+4 last month)",
            cardWidth: true,
          },
        ],
      },
      
      {
        id: "trans-8",
        name: "IAM",

        score: 67,
        health: "Null Track",
        lastUpdatedAt: "Dec 2025",

        metrics: [
          // {
          //   id: "m1",
          //   label: "IAM Access Management",
          //   type: "currentTarget",
          //   current: "1000",
          //   target: "1920",
          // },
          // {
          //   id: "m2",
          //   label: "IAM Governance & IGA Progress (%)",
          //   type: "progress",
          //   value: 30,
          // },
          // {
          //   id: "m3",
          //   label: "Privileged Access Management (PAM)",
          //   type: "currentTarget",
          //   current: "20",
          //   target: "46",
          //   // type: "milestone",
          //   // current: "20",
          //   // target: "46",
          //   // trend: "(+4 last month)",
          // },

          {
            id: "m1",
            label: "AD Domain Hardening",
            type: "milestone",
            current: "-",
            target: 44,
            cardWidth: true,
          },
          {
            id: "m2",
            label: "SaaS App Remidiation",
            type: "milestone",
            current: "-",
            target: 6021,
            cardWidth: true,
          },
          {
            id: "m3",
            label: "RBAC",
            type: "milestone",
            current: "-",
            target: 540,
            cardWidth: true,
          },
          {
            id: "m4",
            label: "Privileged Access Management (PAM)",
            type: "milestone",
            current: "-",
            target: "51,142",
            cardWidth: true,
          },
        ],
      },
      
    ],
  },
];
