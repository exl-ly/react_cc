export type TowerV1 = "Focus" | "Accelerate" | "Scale" | "Transform";

export interface TeamV1 {
  id: string;
  name: string;
  leader: string;
}

export interface PriorityV1 {
  id: string;
  name: string;
}

export interface InitiativeV1 {
  id: string;
  priority: string;
  team: string;
  name: string;
  owner: string;
  tower: Tower;
  status: string;
  error: boolean;
}
