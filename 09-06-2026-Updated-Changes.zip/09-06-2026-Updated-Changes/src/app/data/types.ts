export type Tower = "Focus" | "Accelerate" | "Scale" | "Transform";

export interface Team {
  id: string;
  name: string;
  leader: string;
}

export interface Priority {
  id: string;
  name: string;
}

export interface Initiative {
  id: string;
  priority: string;
  team: string;
  name: string;
  owner: string;
  tower: Tower;
  status: string;
  towerTeam: string;
  error: boolean;
}
