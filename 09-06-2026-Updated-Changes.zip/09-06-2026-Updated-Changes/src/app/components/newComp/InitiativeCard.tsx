import { Card, Chip, Typography, Stack, Box, Tooltip } from "@mui/material";
import WarningIcon from "@mui/icons-material/Warning";
import { Initiative } from "../../data/types";
import CommentIcon from "@mui/icons-material/Comment";

const towerColors = {
  Focus: "rgb(26, 115, 232)",
  Accelerate: "rgb(123, 31, 162)",
  Scale: "rgb(0, 151, 167)",
  Transform: "rgb(230, 81, 0)",
};

const towerBorders = {
  Focus: "1px solid rgba(26, 115, 232, 0.25)",
  Accelerate: "1px solid rgba(123, 31, 162, 0.25)",
  Scale: "1px solid rgba(0, 151, 167, 0.25)",
  Transform: "1px solid rgba(230, 81, 0, 0.25)",
};

const towerBGColors = {
  Focus: "rgba(26, 115, 232, 0.082)",
  Accelerate: "rgba(123, 31, 162, 0.082)",
  Scale: "rgba(0, 151, 167, 0.082)",
  Transform: "rgba(230, 81, 0, 0.082)",
};

interface Props {
  initiative: Initiative;
}

export default function InitiativeCard({ initiative }: Props) {
  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case "on track":
        return "#34A853";
      case "off track":
        return "#FB8C00";
      case "at risk":
        return "#EA4335";
      default:
        return "#9AA0A6"; // Not Started
    }
  };
  return (
    <>
      <Stack
        direction="row"
        sx={{
          minHeight: 65,
          maxHeight: 65, // keep all cards same height
          borderRadius: 1,
          overflow: "hidden",
        }}
      >
        {/* Content */}
        <Box
          sx={{
            flex: 1,
            padding: "4px 8px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "start",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "start",
              gap: 0.5,
              width: "100%",
            }}
          >
            <Typography
              variant="subtitle2"
              sx={{
                fontWeight: 600,
                fontSize: "10px",
                lineHeight: 1.4,
                mb: 0.5,
                color: "rgb(95, 99, 104)",
              }}
            >
              {initiative.name}
            </Typography>
            {initiative.error === true && (
              <Tooltip
                title="Immediate attention required"
                arrow
                slotProps={{
                  tooltip: {
                    sx: {
                      fontSize: "8px",
                    },
                  },
                }}
              >
                <WarningIcon
                  sx={{
                    color: "#ef4444",
                    fontSize: "17px",
                    cursor: "pointer",
                    flexShrink: 0,
                  }}
                />
              </Tooltip>
            )}
          </Box>

          <Typography
            variant="caption"
            // color="text.primary"
            sx={{
              fontSize: "10px",
              lineHeight: 1.4,
              mb: 0.5,
            }}
          >
            Tower: {initiative?.towerteam}
          </Typography>

          {/* <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          > */}
          <Typography
            variant="caption"
            color="text.secondary"
            sx={{
              fontSize: "9px",
              lineHeight: 1.1,
              mt: 0.2,
            }}
          >
            Leader: {initiative.owner}
          </Typography>

          <Box
            sx={{
              alignItems: "right",
              textAlign: "right",
              position: "relative",
              bottom: "15px",
            }}
          >
            <CommentIcon sx={{ fontSize: "16px" }} />
          </Box>
          {/* </Box> */}
        </Box>

        {/* Status Border */}
        <Box
          sx={{
            width: 6,
            bgcolor: getStatusColor(initiative.status),
          }}
        />
      </Stack>
    </>
  );
}
