import { Box } from "@mui/material";
import InitiativeCard from "./InitiativeCard";
import { Initiative } from "../../data/types";

interface Props {
  initiatives: Initiative[];
}

export default function InitiativeCell({ initiatives }: Props) {
  return (
    <Box
      sx={{
        // minHeight: 30,
        display: "flex",
        flexDirection: "column",
        gap: 1,
        // p: 1,
      }}
    >
      {initiatives.map((item) => (
        <InitiativeCard key={item.id} initiative={item} />
      ))}
    </Box>
  );
}
