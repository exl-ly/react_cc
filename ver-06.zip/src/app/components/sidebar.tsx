import { useState, type ReactNode } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { LEADERS, INITIATIVES, CATEGORIES } from "../data/initiatives";
import { useTheme } from "../theme-context";

interface SidebarProps {
  activeLeader: string | null;
  onLeaderChange: (l: string | null) => void;
  activePillar: string | null;
  onPillarChange: (p: string | null) => void;
  activeStatus: string | null;
  onStatusChange: (s: string | null) => void;
  activeTower: string | null;
  onTowerChange: (t: string | null) => void;
  activeCategory: string | null;
  onCategoryChange: (c: string | null) => void;
}

const AVATAR_COLORS = [
  "#4285f4",
  "#7b1fa2",
  "#0097a7",
  "#e65100",
  "#1e8e3e",
  "#d93025",
];

const initials = (name: string) =>
  name
    .split(" ")
    .map((n) => n[0])
    .join("");
const avatarColor = (name: string) =>
  AVATAR_COLORS[LEADERS.indexOf(name as any) % AVATAR_COLORS.length];

export function Sidebar({
  activeLeader,
  onLeaderChange,
  activePillar,
  onPillarChange,
  activeStatus,
  onStatusChange,
  activeTower,
  onTowerChange,
  activeCategory,
  onCategoryChange,
}: SidebarProps) {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";
  const [isLeadersExpanded, setIsLeadersExpanded] = useState(true);

  const PILLARS = [
    { key: "Fast", color: theme.pillarFast, label: "Focus" },
    { key: "Acceleration", color: theme.pillarAccel, label: "Acceleration" },
    { key: "Scale", color: theme.pillarScale, label: "Scale" },
    { key: "Transform", color: theme.pillarTrans, label: "Transformation" },
  ];

  const STATUSES = [
    { key: "on-track", label: "On Track", color: theme.onTrack },
    { key: "attention", label: "Needs Attention", color: theme.attention },
    { key: "off-track", label: "Off Track", color: theme.offTrack },
  ];

  const TOWERS = [
    { key: "Enterprise Technology", color: "#4285f4" },
    { key: "Product & Dev", color: "#34a853" },
    { key: "Breakthrough Business", color: "#fbbc04" },
    { key: "Others", color: "#42854f" },
  ];

  const base: React.CSSProperties = {
    width: 232,
    minWidth: 232,
    background: theme.sidebarBg,
    borderRight: `1px solid ${theme.sidebarBorder}`,
    display: "flex",
    flexDirection: "column",
    height: "100%",
    overflowY: "auto",
    scrollbarWidth: "none",
    boxShadow: isLight ? "2px 0 6px rgba(60,64,67,0.06)" : "none",
  };

  return (
    <div style={base}>
      <Section label="Towers" theme={theme}>
        <FilterChip
          active={activeTower === null}
          color={theme.brandPrimary}
          theme={theme}
          onClick={() => onTowerChange(null)}
        >
          All Towers
        </FilterChip>
        {TOWERS.map((t) => (
          <FilterChip
            key={t.key}
            active={activeTower === t.key}
            color={t.color}
            theme={theme}
            onClick={() => onTowerChange(activeTower === t.key ? null : t.key)}
          >
            {t.key}
            <span
              style={{
                marginLeft: "auto",
                color: theme.textTertiary,
                fontSize: 11,
              }}
            >
              {INITIATIVES.filter((i) => i.tower === t.key).length}
            </span>
          </FilterChip>
        ))}
      </Section>

      <Divider theme={theme} />

      <Section label="Categories" theme={theme}>
        <FilterChip
          active={activeCategory === null}
          color={theme.brandPrimary}
          theme={theme}
          onClick={() => onCategoryChange(null)}
        >
          All Categories
        </FilterChip>
        {CATEGORIES.map((c) => (
          <FilterChip
            key={c}
            active={activeCategory === c}
            color={theme.brandPrimary}
            theme={theme}
            onClick={() => onCategoryChange(activeCategory === c ? null : c)}
          >
            {c}
            <span
              style={{
                marginLeft: "auto",
                color: theme.textTertiary,
                fontSize: 11,
              }}
            >
              {INITIATIVES.filter((i) => i.category === c).length}
            </span>
          </FilterChip>
        ))}
      </Section>

      <Divider theme={theme} />

      <Section
        label="Leaders"
        theme={theme}
        collapsible
        isExpanded={isLeadersExpanded}
        onToggle={() => setIsLeadersExpanded(!isLeadersExpanded)}
      >
        <LeaderChip
          active={activeLeader === null}
          onClick={() => onLeaderChange(null)}
          theme={theme}
        >
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              background: isLight ? "#e8eaed" : theme.elevated,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <span
              style={{
                color: theme.textTertiary,
                fontSize: 10,
                fontWeight: 700,
              }}
            >
              ALL
            </span>
          </div>
          <span
            style={{
              color: theme.textSecondary,
              fontSize: 12,
              fontWeight: 500,
            }}
          >
            All Leaders
          </span>
          <span
            style={{
              marginLeft: "auto",
              color: theme.textTertiary,
              fontSize: 11,
              fontWeight: 500,
            }}
          >
            {INITIATIVES.length}
          </span>
        </LeaderChip>

        {isLeadersExpanded &&
          LEADERS.map((leaderName) => {
            const isActive = activeLeader === leaderName;
            const stats = {
              count: INITIATIVES.filter((i) => i.leader === leaderName).length,
              onTrack: INITIATIVES.filter(
                (i) => i.leader === leaderName && i.status === "on-track"
              ).length,
              offTrack: INITIATIVES.filter(
                (i) => i.leader === leaderName && i.status === "off-track"
              ).length,
              attention: INITIATIVES.filter(
                (i) => i.leader === leaderName && i.status === "attention"
              ).length,
            };

            return (
              <button
                key={leaderName}
                onClick={() => onLeaderChange(isActive ? null : leaderName)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  width: "100%",
                  padding: "7px 10px",
                  borderRadius: 8,
                  border: "none",
                  cursor: "pointer",
                  background: isActive ? theme.chipActiveBg : "transparent",
                  outline: isActive
                    ? `1.5px solid ${theme.chipActiveBorder}`
                    : "none",
                  transition: "all 0.15s",
                  textAlign: "left",
                }}
              >
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: "50%",
                    background: avatarColor(leaderName),
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#fff",
                    fontSize: 11,
                    fontWeight: 700,
                    flexShrink: 0,
                    letterSpacing: "0.01em",
                  }}
                >
                  {initials(leaderName)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      color: isActive ? theme.brandPrimary : theme.textPrimary,
                      fontSize: 12,
                      fontWeight: 500,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {leaderName}
                  </div>
                  <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
                    {stats.onTrack > 0 && (
                      <span
                        style={{
                          color: theme.onTrack,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.onTrack}↑
                      </span>
                    )}
                    {stats.attention > 0 && (
                      <span
                        style={{
                          color: theme.attention,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.attention}!
                      </span>
                    )}
                    {stats.offTrack > 0 && (
                      <span
                        style={{
                          color: theme.offTrack,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.offTrack}↓
                      </span>
                    )}
                  </div>
                </div>
                <span
                  style={{
                    color: isActive ? theme.brandPrimary : theme.textTertiary,
                    fontSize: 12,
                    fontWeight: 600,
                    flexShrink: 0,
                  }}
                >
                  {stats.count}
                </span>
              </button>
            );
          })}
      </Section>

      <Divider theme={theme} />

      {/* <Section label="FAST Pillar" theme={theme}>
        <FilterChip active={activePillar === null} color={theme.brandPrimary} theme={theme} onClick={() => onPillarChange(null)}>
          All Pillars
        </FilterChip>
        {PILLARS.map((p) => (
          <FilterChip key={p.key} active={activePillar === p.key} color={p.color} theme={theme} onClick={() => onPillarChange(activePillar === p.key ? null : p.key)}>
            <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 18, height: 18, borderRadius: 4, background: `${p.color}18`, border: `1px solid ${p.color}44`, color: p.color, fontSize: 10, fontWeight: 700, flexShrink: 0 }}>{p.key[0]}</span>
            {p.label}
            <span style={{ marginLeft: "auto", color: theme.textTertiary, fontSize: 11 }}>{INITIATIVES.filter((i) => i.pillar === p.key).length}</span>
          </FilterChip>
        ))}
      </Section> */}

      {/* <Divider theme={theme} />

      <Section label="Status" theme={theme}>
        <FilterChip
          active={activeStatus === null}
          color={theme.brandPrimary}
          theme={theme}
          onClick={() => onStatusChange(null)}
        >
          All Status
        </FilterChip>
        {STATUSES.map((s) => (
          <FilterChip
            key={s.key}
            active={activeStatus === s.key}
            color={s.color}
            theme={theme}
            onClick={() =>
              onStatusChange(activeStatus === s.key ? null : s.key)
            }
          >
            <div
              style={{
                width: 9,
                height: 9,
                borderRadius: "50%",
                background: s.color,
                flexShrink: 0,
              }}
            />
            {s.label}
            <span
              style={{
                marginLeft: "auto",
                color: theme.textTertiary,
                fontSize: 11,
              }}
            >
              {INITIATIVES.filter((i) => i.status === s.key).length}
            </span>
          </FilterChip>
        ))}
      </Section> */}
    </div>
  );
}

function Section({
  label,
  children,
  theme,
  collapsible,
  isExpanded,
  onToggle,
}: {
  label: string;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
  collapsible?: boolean;
  isExpanded?: boolean;
  onToggle?: () => void;
}) {
  return (
    <div style={{ padding: "12px 8px 8px" }}>
      <div
        onClick={collapsible ? onToggle : undefined}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 4,
          cursor: collapsible ? "pointer" : "default",
          marginBottom: 4,
          padding: "0 4px",
          userSelect: "none",
        }}
      >
        <div
          style={{
            color: theme.textTertiary,
            fontSize: 10,
            fontWeight: 700,
            letterSpacing: "0.1em",
          }}
        >
          {label.toUpperCase()}
        </div>
        {collapsible && (
          <div
            style={{
              color: theme.textTertiary,
              display: "flex",
              alignItems: "center",
            }}
          >
            {isExpanded ? (
              <ChevronDown size={12} />
            ) : (
              <ChevronRight size={12} />
            )}
          </div>
        )}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {children}
      </div>
    </div>
  );
}

function LeaderChip({
  active,
  onClick,
  children,
  theme,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
}) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        width: "100%",
        padding: "7px 10px",
        borderRadius: 8,
        border: "none",
        cursor: "pointer",
        background: active ? theme.chipActiveBg : "transparent",
        outline: active ? `1.5px solid ${theme.chipActiveBorder}` : "none",
        transition: "all 0.15s",
        textAlign: "left",
      }}
    >
      {children}
    </button>
  );
}

function FilterChip({
  active,
  color,
  onClick,
  children,
  theme,
}: {
  active: boolean;
  color: string;
  onClick: () => void;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
}) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        width: "100%",
        padding: "6px 10px",
        borderRadius: 8,
        border: "none",
        cursor: "pointer",
        background: active ? `${color}12` : "transparent",
        outline: active ? `1.5px solid ${color}44` : "none",
        color: active ? color : theme.textSecondary,
        fontSize: 12,
        fontWeight: active ? 500 : 400,
        transition: "all 0.15s",
        textAlign: "left",
      }}
    >
      {children}
    </button>
  );
}

function Divider({ theme }: { theme: ReturnType<typeof useTheme>["theme"] }) {
  return (
    <div style={{ height: 1, background: theme.divider, margin: "4px 0" }} />
  );
}
