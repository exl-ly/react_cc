import { Card, Chip, Typography, Stack, Box } from "@mui/material";
import { Initiative } from "../../data/types";

const towerColors = {
  Focus: "rgb(26, 115, 232)",
  Accelerate: "rgb(123, 31, 162)",
  Scale: "rgb(0, 151, 167)",
  Transform: "rgb(230, 81, 0)",
};

const towerBorders = {
  Focus: "1px solid rgba(26, 115, 232, 0.25)",
  Accelerate: "1px solid rgba(123, 31, 162, 0.25)",
  Scale: "1px solid rgba(0, 151, 167, 0.25)",
  Transform: "1px solid rgba(230, 81, 0, 0.25)",
};

const towerBGColors = {
  Focus: "rgba(26, 115, 232, 0.082)",
  Accelerate: "rgba(123, 31, 162, 0.082)",
  Scale: "rgba(0, 151, 167, 0.082)",
  Transform: "rgba(230, 81, 0, 0.082)",
};

interface Props {
  initiative: Initiative;
}

export default function InitiativeCard({ initiative }: Props) {
  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case "on track":
        return "#34A853";
      case "off track":
        return "#FB8C00";
      case "at risk":
        return "#EA4335";
      default:
        return "#9AA0A6"; // Not Started
    }
  };
  return (
    <Card
      sx={{
        p: 0.6,
        // borderLeft: `4px solid ${towerColors[initiative.tower]}`,
        borderRadius: 2,
      }}
    >
      <Stack direction="row" spacing={1.5}>
        {/* Tower Badge */}
        <Box
          sx={{
            width: 20,
            height: 20,
            borderRadius: 1.5,
            bgcolor: towerBGColors[initiative.tower],
            border: towerBorders[initiative.tower],
            color: towerColors[initiative.tower],
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 700,
            fontSize: 10,
            flexShrink: 0,
          }}
        >
          {initiative.towerteam?.charAt(0).toUpperCase()}
        </Box>

        <Box flex={1}>
          <Box
            sx={{
              display: "flex",
              alignItems: "baseline",
              justifyContent: "space-between",
              gap: 1,
            }}
          >
            <Typography
              variant="subtitle2"
              sx={{
                fontWeight: 600,
                lineHeight: 1.3,
                fontSize: "12px",
                flex: 1,
              }}
            >
              {initiative.name}
            </Typography>

            <Box
              sx={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                bgcolor: getStatusColor(initiative.status),
                flexShrink: 0,
              }}
            />
          </Box>
          <Box sx={{ display: "flex", justifyContent: "space-between" }}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginTop: "5px",
              }}
            >
              <Typography
                variant="caption"
                color="text.primary"
                sx={{
                  fontSize: "10px",
                  lineHeight: 1,
                }}
              >
                Category: {initiative?.towerteam}
              </Typography>
            </Box>

            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginTop: "5px",
              }}
            >
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                  fontSize: "10px",
                  lineHeight: 1,
                }}
              >
                Leader: {initiative.owner}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Stack>
    </Card>
  );
}
