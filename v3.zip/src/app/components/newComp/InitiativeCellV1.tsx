import { Box } from "@mui/material";
import { InitiativeV1 } from "../../data/typesTower";
import InitiativeCardV1 from "./InitiativeCardV1";

interface Props {
  initiatives: InitiativeV1[];
}

export default function InitiativeCellV1({ initiatives }: Props) {
  return (
    <Box
      sx={{
        minHeight: 30,
        display: "flex",
        flexDirection: "column",
        gap: 1,
        p: 1,
      }}
    >
      {initiatives.map((item) => (
        <InitiativeCardV1 key={item.id} initiative={item} />
      ))}
    </Box>
  );
}
