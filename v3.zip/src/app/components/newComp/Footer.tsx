import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  Stack,
  IconButton,
} from "@mui/material";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import { useNavigate } from "react-router-dom";

export default function Footer() {
  const navigate = useNavigate();

  return (
    <Box sx={{ p: 0, bgcolor: "#f6f8fb", mt: "10px" }}>
      <Card
        sx={{
          borderRadius: 3,
          border: "1px solid #e3e8ef",
          overflow: "hidden",
        }}
      >
        <CardContent
          sx={{
            p: "5px",
            "&:last-child": {
              pb: "5px",
            },
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 0,
          }}
        >
          <Stack direction="row" spacing={1} alignItems="center">
            <IconButton
              sx={{
                width: "fit-content",
                borderRadius: 2,
                bgcolor: "#eef5ff",
                border: "1px solid #d7e7ff",
              }}
            >
              <GridViewRoundedIcon sx={{ color: "#d0271d" }} />
            </IconButton>

            <Box>
              <Typography fontWeight={700} fontSize={14}>
                Explore the full strategic portfolio
              </Typography>
              <Typography color="text.secondary" fontSize={10}>
                Dive deeper into initiatives across all towers.
              </Typography>
            </Box>
          </Stack>

          <Button
            variant="contained"
            endIcon={<ArrowForwardRoundedIcon />}
            onClick={() => navigate("/cockpit-view")}
            sx={{
              textTransform: "none",
              borderRadius: 1.5,
              px: 3,
              py: 0.5,
              fontWeight: 600,
              bgcolor: "#d0271d",
              "&:hover": {
                bgcolor: "#f90e00",
              },
            }}
          >
            Open Detailed View
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
}
