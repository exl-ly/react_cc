import React from "react";
import { Star, Flag, Crown } from "lucide-react";

interface Initiative {
  name: string;
  owner: string;
  metric: string;
  metricValue: string;
  status: "On Track" | "At Risk" | "Off Track" | "Not Started";
}

interface PriorityMatrixProps {
  initiatives: {
    fast: Initiative[];
    accelerate: Initiative[];
    scale: Initiative[];
    transform: Initiative[];
  };
}

const statusColors = {
  "On Track": { bg: "#10b981", text: "#059669" },
  "At Risk": { bg: "red", text: "#d97706" },
  "Off Track": { bg: "orange", text: "#dc2626" },
  "Not Started": { bg: "#e5e7eb", text: "#6b7280" },
};

const priorityIcons = [
  { icon: Crown, color: "#8b5cf6", label: "High" },
  { icon: Star, color: "#6366f1", label: "Medium" },
  { icon: Flag, color: "#8b5cf6", label: "Low" },
];

export function PriorityMatrix({ initiatives }: PriorityMatrixProps) {
  const pillars = [
    { key: "fast", label: "FOCUS", color: "#10b981", icon: "🚀" },
    {
      key: "accelerate",
      label: "ACCELERATE",
      color: "#f20505",
      icon: "⚡",
    },
    { key: "scale", label: "SCALE", color: "#10b981", icon: "📊" },
    { key: "transform", label: "TRANSFORM", color: "#f59e0b", icon: "🔄" },
  ];

  return (
    <div className="bg-white rounded-xl p-4 pt-1 pb-1 shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ fontSize: "16px" }}>
          STRATEGIC PRIORITY MATRIX
        </h2>
        <div className="flex gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#10b981]"></div>
            <span>On Track</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[red]"></div>
            <span>At Risk</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[orange]"></div>
            <span>Off Track</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#9ca3af]"></div>
            <span>Not Started</span>
          </div>
        </div>
      </div>

      <div className="flex gap-4 mb-4 pl-34">
        {pillars.map((pillar, idx) => (
          <div
            key={pillar.key}
            className="flex-1 h-8 rounded-lg flex items-center justify-center gap-2 font-semibold text-sm relative"
            style={{
              backgroundColor: `${pillar.color}20`,
              color: pillar.color,
            }}
          >
            {idx < pillars.length - 1 && (
              <div
                className="absolute -right-3 top-1/2 -translate-y-1/2 w-0 h-0 border-t-[24px] border-b-[24px] border-l-[20px] border-t-transparent border-b-transparent z-10"
                style={{
                  borderLeftColor: `${pillar.color}20`,
                  visibility: "hidden",
                }}
              ></div>
            )}
            <span className="text-lg">{pillar.icon}</span>
            <span>{pillar.label}</span>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        {[0, 1, 2].map((priorityIndex) => (
          <div
            key={priorityIndex}
            className="grid grid-cols-[120px_1fr_1fr_1fr_1fr] gap-4"
          >
            <div className="flex items-start gap-2 py-3">
              {React.createElement(priorityIcons[priorityIndex].icon, {
                className: "w-5 h-5",
                style: { color: priorityIcons[priorityIndex].color },
              })}
              <div>
                <div className="font-semibold text-sm">
                  Priority {priorityIndex + 1}
                </div>
                <div
                  className="text-xs"
                  style={{ color: priorityIcons[priorityIndex].color }}
                >
                  {priorityIcons[priorityIndex].label}
                </div>
              </div>
            </div>

            {pillars.map((pillar) => {
              const initiative =
                initiatives[pillar.key as keyof typeof initiatives][
                  priorityIndex
                ];
              if (!initiative)
                return (
                  <div
                    key={pillar.key}
                    className="bg-gray-50 rounded-lg p-2"
                    style={{ fontSize: "10px" }}
                  ></div>
                );

              const statusStyle = statusColors[initiative.status];

              return (
                <div
                  key={pillar.key}
                  className="bg-gray-50 rounded-lg p-2 hover:shadow-md transition-shadow"
                >
                  <div
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <div
                      className="font-semibold text-sm mb-2"
                      style={{ fontSize: "12px", width: "95%" }}
                    >
                      {initiative.name}
                    </div>
                    <div
                      style={{
                        backgroundColor: statusStyle.bg,
                        color: statusStyle.text,
                        width: "8px",
                        height: "8px",
                        borderRadius: "60px",
                      }}
                    >
                      {/* <span
                        className="px-2 py-1 rounded font-medium"
                        style={{
                          backgroundColor: statusStyle.bg,
                          color: statusStyle.text,
                          fontSize: "10px",
                          width: "fill-content",
                        }}
                      > */}
                      {/* {initiative.status} */}
                      {/* </span> */}
                    </div>
                  </div>
                  <div className="text-xs text-gray-600 mb-1">
                    Leader: {initiative.owner}
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    {/* <span className="text-gray-600">{initiative.metric}: {initiative.metricValue}</span> */}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
