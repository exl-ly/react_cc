import { useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Calendar,
  Download,
  ChevronDown,
} from "lucide-react";
// import { Sidebar } from './components/Sidebar';
import { MetricCard } from "./Metriccard";
import { PriorityMatrix } from "./PriorityMatrix";
import { useTheme } from "../theme-context";

export default function Overview() {
  const [selectedPillar, setSelectedPillar] = useState("All Pillars");
  const [selectedPeriod, setSelectedPeriod] = useState("Q2 FY25");

  const { theme, toggle } = useTheme();

  const metricCards = [
    {
      title: "FOCUS",
      percentage: 11,
      status: "On Track" as const,
      keyFocus: "Operational Efficiency",
      color: "#10b981",
      icon: "rocket" as const,
      chartData: [45, 52, 48, 55, 51, 58, 62, 59, 65, 68, 72, 75],
    },
    {
      title: "ACCELERATE",
      percentage: 10,
      status: "At Risk" as const,
      keyFocus: "User Adoption",
      color: "red",
      icon: "gauge" as const,
      chartData: [65, 62, 58, 60, 55, 52, 54, 56, 53, 55, 57, 58],
    },
    {
      title: "SCALE",
      percentage: 3,
      status: "On Track" as const,
      keyFocus: "Platform Expansion",
      color: "#10b981",
      icon: "chart" as const,
      chartData: [40, 42, 45, 48, 52, 55, 58, 56, 60, 59, 61, 63],
    },
    {
      title: "TRANSFORM",
      percentage: 10,
      status: "Off Track" as const,
      keyFocus: "Innovation & Transformation",
      color: "#f59e0b",
      icon: "refresh" as const,
      chartData: [50, 48, 45, 42, 40, 38, 36, 37, 38, 39, 39, 40],
    },
  ];

  const initiatives = {
    fast: [
      {
        name: "Lyric - Next Gen",
        owner: "Yesh",
        metric: "Value",
        metricValue: "£100M",
        status: "On Track" as const,
      },
      {
        name: "WFN - Next Gen",
        owner: "Max",
        metric: "Value",
        metricValue: "£75M",
        status: "At Risk" as const,
      },
      {
        name: "E - Next Gen",
        owner: "Roberto",
        metric: "Value",
        metricValue: "£50M",
        status: "Off Track" as const,
      },
    ],
    accelerate: [
      {
        name: "AI Infrastructure Progress(AI Studio)",
        owner: "Prasanna & Team",
        metric: "Adoption",
        metricValue: "45%",
        status: "At Risk" as const,
      },
      {
        name: "AI Productivity Benefit (Cumulative %)",
        owner: "Prasanna & Team",
        metric: "Accuracy",
        metricValue: "35%",
        status: "At Risk" as const,
      },
      {
        name: "AI Infrastructure Progress(Personalization Engine & Data Central)",
        owner: "Amin & Team",
        metric: "Readiness",
        metricValue: "60%",
        status: "At Risk" as const,
      },
    ],
    scale: [
      {
        name: "Breakthrough Business Revenue - Marketplace",
        owner: "Oz & Team",
        metric: "Coverage",
        metricValue: "55%",
        status: "On Track" as const,
      },
      {
        name: "Breakthrough Business Revenue - Data",
        owner: "Oz & Team",
        metric: "Completion",
        metricValue: "40%",
        status: "At Risk" as const,
      },
      {
        name: "Investment and Revenue Gains from Ventures",
        owner: "Oz & Team",
        metric: "Savings",
        metricValue: "20%",
        status: "On Track" as const,
      },
    ],
    transform: [
      {
        name: "Vendor Management(TESM)",
        owner: "Varun & Team",
        metric: "Users",
        metricValue: "3K",
        status: "At Risk" as const,
      },
      {
        name: "GPT Global Delivery Model",
        owner: "Varun & Team",
        metric: "Automation",
        metricValue: "25%",
        status: "At Risk" as const,
      },
      {
        name: "SDLC/ADLC",
        owner: "Ram & Team",
        metric: "Users",
        metricValue: "500",
        status: "Off Track" as const,
      },
    ],
  };

  return (
    <div
      style={{
        background: theme.surface,
        borderBottom: `1px solid ${theme.border}`,
      }}
    >
      {/* <Sidebar activeItem="Overview" /> */}

      <div
        style={{
          // display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "14px 18px 12px",
        }}
      >
        <div>
          <div className="flex items-start justify-between mb-2">
            <div>
              <h1
                className="text-0.8xl font-bold mb-0.4"
                style={{ color: "#d0271d" }}
              >
                Command Center Homepage
              </h1>
              <p className="text-gray-600" style={{ fontSize: "12px" }}>
                Executive overview of strategic initiatives across all pillars
              </p>
            </div>

            {/* <div className="flex items- center gap-3">
              <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg flex items-center gap-2 hover:bg-gray-50">
                <span>{selectedPillar}</span>
                <ChevronDown className="w-4 h-4" />
              </button>

              <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg flex items-center gap-2 hover:bg-gray-50">
                <Calendar className="w-4 h-4" />
                <span>{selectedPeriod}</span>
                <ChevronDown className="w-4 h-4" />
              </button>

              <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg flex items-center gap-2 hover:bg-gray-50">
                <Download className="w-4 h-4" />
                <span>Export</span>
              </button>
            </div> */}
          </div>

          {/* <div className="relative mb-8"> */}
          {/* <button className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 z-10">
              <ChevronLeft className="w-5 h-5" />
            </button> */}

          <div
            className="gap-0 overflow-x-auto pb-2 scrollbar-hide"
            style={{ display: "flex", justifyContent: "space-between" }}
          >
            {metricCards.map((card) => (
              <MetricCard key={card.title} {...card} />
            ))}
          </div>

          {/* <button className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 z-10">
              <ChevronRight className="w-5 h-5" />
            </button> */}
          {/* </div> */}

          <PriorityMatrix initiatives={initiatives} />
        </div>
      </div>
    </div>
  );
}
