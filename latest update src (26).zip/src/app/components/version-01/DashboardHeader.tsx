import { Box, Card, Stack, Typography, Avatar } from "@mui/material";

import { headerConfig } from "../../../config/headerConfig";
import adplogo from "../../../images/adp-logo.jpg";
import { useTheme } from "../../theme-context";
import InitiativeDashboard from "./InitiativeDashboard";

const InitiativeCard = ({ label, value, color }: any) => (
  <Card
    elevation={0}
    sx={{
      px: 1.5,
      py: 0.6,
      borderRadius: 2,
      //   minWidth: 90,
      border: "1px solid #ECECEC",
    }}
  >
    <Typography fontSize={10}>{label}</Typography>

    <Stack direction="row" spacing={0.5} alignItems="center">
      <Box
        sx={{
          width: 8,
          height: 8,
          bgcolor: color,
          borderRadius: "50%",
        }}
      />

      <Typography fontSize={12} fontWeight={700}>
        {value}
      </Typography>
    </Stack>
  </Card>
);

const SummaryCard = ({ title, value, bg }: any) => (
  <Card
    elevation={0}
    sx={{
      minWidth: 75,
      px: 0.5,
      py: 0,
      bgcolor: bg,
      borderRadius: 2,
      textAlign: "center",
      alignItems: "center",
    }}
  >
    <Typography fontWeight={800} fontSize={10}>
      {value}
    </Typography>

    <Typography fontSize={10}>{title}</Typography>
  </Card>
);

export default function DashboardHeader() {
  const { theme } = useTheme();

  return (
    <>
      <Box
        sx={{
          px: 0.75,
          py: 0.8,
          bgcolor: "#fff",
          borderBottom: "1px solid #E2E8F0",
        }}
      >
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
        >
          {/* LEFT */}

          <Stack direction="row" spacing={1.5} alignItems="center">
            {/* LOGO */}
            <Avatar
              src={adplogo}
              variant="square"
              sx={{
                width: 56,
                height: 28,
              }}
            />

            {/* TITLE */}
            <Box>
              <Typography
                sx={{
                  fontWeight: 700,
                  fontSize: 14, // keep larger
                  lineHeight: 1.1,
                }}
              >
                {headerConfig.company.title}
              </Typography>

              <Typography
                sx={{
                  fontSize: 10,
                  color: "#667085",
                  lineHeight: 1,
                }}
              >
                {headerConfig.company.subtitle}
              </Typography>
            </Box>

            {/* STATUS CARDS */}

            <Stack direction="row" spacing={0.6} alignItems="stretch">
              {headerConfig.initiatives.map((item) => (
                <InitiativeCard key={item.label} {...item} />
              ))}
              <Box sx={{ width: "30px" }} />
              {headerConfig.summary.map((item) => (
                <SummaryCard key={item.title} {...item} />
              ))}
            </Stack>
          </Stack>

          {/* RIGHT */}

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              height: 54,
            }}
          >
            <Box
              sx={{
                px: 1.5,
                py: 0.7,
                background: theme.tableHeaderBg || "#0D1B66",
                borderRadius: "8px",
                color: "#fff",
                fontSize: "10px",
                fontFamily: "var(--font-mono)",
                border: `1px solid ${theme.chipActiveBorder || "#273A8A"}`,
                fontWeight: 600,
                display: "flex",
                alignItems: "center",
                gap: 0.7,
                whiteSpace: "nowrap",
                minHeight: 38,
              }}
            >
              {/* LIVE DOT */}
              <Box
                sx={{
                  width: 6,
                  height: 6,
                  borderRadius: "50%",
                  bgcolor: "#00E676",
                  animation: "livePulse 1.5s infinite",
                }}
              />

              <Typography
                sx={{
                  fontSize: "10px",
                  color: "#fff",
                  fontWeight: 600,
                }}
              >
                Live ·{" "}
                {new Date().toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </Typography>
            </Box>

            <style>
              {`
      @keyframes livePulse {
        0% {
          opacity: 1;
          transform: scale(1);
        }
        50% {
          opacity: .5;
          transform: scale(1.2);
        }
        100% {
          opacity: 1;
          transform: scale(1);
        }
      }
    `}
            </style>
          </Box>
        </Stack>
      </Box>
      <InitiativeDashboard />
    </>
  );
}
