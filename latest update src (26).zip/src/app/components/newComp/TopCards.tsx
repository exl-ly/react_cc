import React from "react";
import {
  Avatar,
  Box,
  Card,
  CardContent,
  Chip,
  FormControlLabel,
  Grid,
  Switch,
  Tooltip,
  Typography,
} from "@mui/material";

import RocketLaunchIcon from "@mui/icons-material/RocketLaunch";
import SpeedIcon from "@mui/icons-material/Speed";
import BarChartIcon from "@mui/icons-material/BarChart";
import SyncIcon from "@mui/icons-material/Sync";
import { useTheme } from "../../theme-context";
import { useNavigate } from "react-router-dom";

interface PillarCard {
  title: string;
  value: number;
  status: "On Track" | "At Risk" | "Off Track" | "Null Track";
  focus: string;
  color: string;
  icon: React.ReactNode;
}

const pillarData: PillarCard[] = [
  {
    title: "FOCUS",
    value: 75,
    status: "On Track",
    focus: "Deliver on BU & Fuctional Priorities",
    color: "#d0271d",
    icon: <RocketLaunchIcon />,
  },
  {
    title: "ACCELERATE",
    value: 58,
    status: "At Risk",
    focus: "Product Portfolio Impact",
    color: "#d0271d",
    icon: <SpeedIcon />,
  },
  {
    title: "SCALE",
    value: 63,
    status: "On Track",
    focus: "GPT Led Growth Beds",
    color: "#d0271d",
    icon: <BarChartIcon />,
  },
  {
    title: "TRANSFORM",
    value: 40,
    status: "Off Track",
    focus: "GPT Operations & Engagement",
    color: "#d0271d",
    icon: <SyncIcon />,
  },
];

const getStatusColor = (status: string) => {
  console.log("status color in top cards: "+status)
  switch (status?.toLowerCase()) {
    case "on track":
      return "#34A853";
    case "off track":
      return "#FB8C00";
    case "at risk":
      return "#EA4335";
    default:
      return "#9AA0A6";
  }
};

const TopCards: React.FC = () => {
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();

  const handleSwitchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      navigate("/cockpit-view");
    } else {
      navigate("/new");
    }
  };
  return (
    <Box
      sx={{
        width: "100%",
        px: 0,
        py: 0,
        mb: 1,
      }}
    >
      <Box sx={{ mb: 1 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            background: "#fff",
            borderRadius: "5px",
            px: 1,
            py: 1,
          }}
        >
          <Box>
            <Typography
              variant="body2"
              sx={{
                fontSize: "15px",
                color: "rgb(32, 33, 36)",
                fontWeight: "500",
              }}
            >
              Command Center - Dashboard
            </Typography>

            <Typography
              variant="body2"
              sx={{ color: "rgb(154, 160, 166)", fontSize: "11px" }}
            >
              Executive Overview of Strategic Initiatives across All Pillars
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {/* <Tooltip title="Switch to Cockpit View" arrow placement="bottom">
              <Box
                onClick={() => navigate("/cockpit-view")}
                sx={{
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: "10px",
                  background:
                    "linear-gradient(145deg, #7dd3fc 0%, #3b82f6 45%, #1d4ed8 100%)",
                  border: "2px solid rgba(255,255,255,0.5)",
                  boxShadow: `
        inset 0 2px 6px rgba(255,255,255,0.6),
        inset 0 4px 2px rgba(0,0,0,0.2),
        0 2px 5px rgba(29,78,216,0.35)
      `,
                  position: "relative",
                  overflow: "hidden",
                  transition: "all 0.25s ease",

                  "&::before": {
                    content: '""',
                    position: "absolute",
                    top: 6,
                    left: 10,
                    right: 10,
                    height: "40%",
                    borderRadius: "50%",
                    background:
                      "linear-gradient(to bottom, rgba(255,255,255,0.7), rgba(255,255,255,0.05))",
                  },

                  "&:hover": {
                    background:
                      "linear-gradient(145deg, #2563eb 0%, #1d4ed8 45%, #1e3a8a 100%)",
                    transform: "translateY(-2px)",
                  },
                }}
              >
                <Box
                  sx={{
                    color: "#fff",
                    fontSize: 10,
                    fontWeight: 800,
                    textShadow: "0 2px 4px rgba(0,0,0,0.3)",
                    zIndex: 1,
                    userSelect: "none",
                  }}
                >
                  C
                </Box>
              </Box>
            </Tooltip> */}
            {/* <Box sx={{ marginRight: "10px" }}>
              <img
                src={cockpitImg}
                alt="cockpitImg"
                style={{ width: 20, height: "auto" }}
              />
            </Box> */}
            <div
              style={{
                padding: "5px 10px",
                background: theme.brandPrimaryBg,
                borderRadius: 6,
                color: theme.brandPrimaryText,
                fontSize: 11,
                fontFamily: "var(--font-mono)",
                border: `1px solid ${theme.chipActiveBorder}`,
                fontWeight: 500,
              }}
            >
              Live ·{" "}
              {new Date().toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
                year: "numeric",
              })}
            </div>
          </Box>
        </Box>
      </Box>
      <Grid container spacing={2} wrap="nowrap">
        {pillarData.map((pillar) => (
          <Grid
            key={pillar.title}
            size={3} // MUI v6
          >
            <Card sx={{ p: 0 }}>
              <CardContent
                sx={{
                  p: "10px",
                  "&:last-child": {
                    pb: "10px",
                  },
                }}
              >
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <Box display="flex" gap={1} alignItems="center">
                    <Avatar
                      sx={{
                        bgcolor: pillar.color,
                      }}
                    >
                      {pillar.icon}
                    </Avatar>

                    <Box>
                      <Typography
                        fontWeight={700}
                        sx={{ color: pillar.color, fontSize: "12px" }}
                      >
                        {pillar.title}
                      </Typography>

                      <Typography
                        variant="h3"
                        fontWeight={700}
                        lineHeight={1}
                        sx={{ fontSize: "20px" }}
                      >
                        {pillar.value}%
                      </Typography>
                    </Box>
                  </Box>

                  <Chip
                    size="small"
                    label={
                      <Box
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          gap: 0.75,
                        }}
                      >
                        <Box
                          sx={{
                            width: 8,
                            height: 8,
                            borderRadius: "50%",
                            bgcolor: getStatusColor(pillar.status),
                          }}
                        />
                        {pillar.status}
                      </Box>
                    }
                    sx={{
                      fontWeight: 600,
                      bgcolor: "#F8FAFC",
                      border: "1px solid #E5E7EB",
                    }}
                  />
                </Box>

                <Typography mt={0.9} variant="body2" sx={{ fontSize: "11px" }}>
                  <Box
                    component="span"
                    sx={{
                      color: pillar.color,
                      fontWeight: 700,
                      fontSize: "11px",
                    }}
                  >
                    Key Focus:
                  </Box>{" "}
                  {pillar.focus}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default TopCards;
