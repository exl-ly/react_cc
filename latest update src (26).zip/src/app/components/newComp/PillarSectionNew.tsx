import React from "react";
import { Box, Card, Typography } from "@mui/material";
import PriorityMatrix from "./PriorityMatrix";
import LeadershipTable from "./LeadershipTable";
import NeedAttention from "./NeedAttention";

const PillarSectionNew = () => {
  return (
    <Box
      sx={{
        width: "100%",
        backgroundColor: "#fff",
        padding: "0 10px",
      }}
    >
      <Box
        sx={{
          display: {
            xs: "block",
            md: "flex",
          },
          gap: 1,
          width: "100%",
        }}
      >
        {/* Left Card - 70% */}
        <Card
          elevation={0}
          sx={{
            flex: 10,
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            p: 1,
            backgroundColor: "#fff",
            minHeight: 420,
          }}
        >
          <PriorityMatrix />
        </Card>
      </Box>
    </Box>
  );
};

export default PillarSectionNew;
