import { createContext, useContext, useState, type ReactNode } from "react";

export type ThemeMode = "dark" | "light";

export interface Theme {
  mode: ThemeMode;
  // surfaces
  bg: string;
  bgSub: string;
  surface: string;
  surfaceHover: string;
  elevated: string;
  // borders
  border: string;
  borderStrong: string;
  divider: string;
  // text
  textPrimary: string;
  textSecondary: string;
  textTertiary: string;
  textDisabled: string;
  // brand
  brandPrimary: string;
  brandPrimaryBg: string;
  brandPrimaryText: string;
  // status
  onTrack: string;
  onTrackBg: string;
  onTrackBorder: string;
  offTrack: string;
  nullTrack:string;
  offTrackBg: string;
  offTrackBorder: string;
  attention: string;
  attentionBg: string;
  attentionBorder: string;
  // pillar colors
  pillarFast: string;
  pillarAccel: string;
  pillarScale: string;
  pillarTrans: string;
  // sidebar
  sidebarBg: string;
  sidebarBorder: string;
  // chips
  chipActiveBg: string;
  chipActiveBorder: string;
  // misc
  shadow: string;
  shadowMd: string;
  boxShadow: string;
  tableHeaderBg: string;
  rowEvenBg: string;
  rowOddBg: string;
  rowExpandBg: string;
  typography: {
    // fontFamily: string;

    h1: {
      fontSize: string;
      fontWeight: number;
    };

    h2: {
      fontSize: string;
      fontWeight: number;
    };

    h3: {
      fontSize: string;
      fontWeight: number;
    };

    body1: {
      fontSize: string;
      fontWeight: number;
    };

    body2: {
      fontSize: string;
      fontWeight: number;
    };

    caption: {
      fontSize: string;
      fontWeight: number;
    };
  };

}

const DARK: Theme = {
  mode: "dark",
  bg: "#0f1117",
  bgSub: "#0a0d12",
  surface: "#161b27",
  surfaceHover: "#1d2335",
  elevated: "#1d2335",
  border: "rgba(255,255,255,0.07)",
  borderStrong: "rgba(255,255,255,0.13)",
  divider: "rgba(255,255,255,0.05)",
  textPrimary: "#e8eaf0",
  textSecondary: "#8b95a8",
  textTertiary: "#4f596b",
  textDisabled: "#333b4a",
  brandPrimary: "#4285f4",
  brandPrimaryBg: "rgba(66,133,244,0.14)",
  brandPrimaryText: "#8ab4f8",
  onTrack: "#34a853",
  onTrackBg: "rgba(52,168,83,0.12)",
  onTrackBorder: "rgba(52,168,83,0.3)",
  offTrack: "#ea4335",
  nullTrack:"#767a8191",
  offTrackBg: "rgba(234,67,53,0.12)",
  offTrackBorder: "rgba(234,67,53,0.3)",
  attention: "#fbbc04",
  attentionBg: "rgba(251,188,4,0.12)",
  attentionBorder: "rgba(251,188,4,0.3)",
  pillarFast: "#4285f4",
  pillarAccel: "#9c27b0",
  pillarScale: "#00acc1",
  pillarTrans: "#ff8f00",
  sidebarBg: "#0c1018",
  sidebarBorder: "rgba(255,255,255,0.06)",
  chipActiveBg: "rgba(66,133,244,0.14)",
  chipActiveBorder: "rgba(66,133,244,0.35)",
  tableHeaderBg: "#0c1018",
  rowEvenBg: "#0f1117",
  rowOddBg: "#111521",
  rowExpandBg: "rgba(66,133,244,0.05)",
  shadow: "0 1px 3px rgba(0,0,0,0.4)",
  shadowMd: "0 4px 12px rgba(0,0,0,0.5)",
  boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  typography: {
    // fontFamily: "Inter, sans-serif",

    h1: { fontSize: "32px", fontWeight: 700 },
    h2: { fontSize: "24px", fontWeight: 600 },
    h3: { fontSize: "20px", fontWeight: 600 },

    body1: { fontSize: "14px", fontWeight: 400 },
    body2: { fontSize: "12px", fontWeight: 400 },

    caption: { fontSize: "11px", fontWeight: 400 },
  },
};

const LIGHT: Theme = {
  mode: "light",
  bg: "#f8f9fa",
  bgSub: "#f1f3f4",
  surface: "#ffffff",
  surfaceHover: "#f1f3f4",
  elevated: "#ffffff",
  border: "rgba(0,0,0,0.08)",
  borderStrong: "rgba(0,0,0,0.15)",
  divider: "rgba(0,0,0,0.06)",
  textPrimary: "#010035",
  textSecondary: "#383d5a",
  textTertiary: "#544F4A",
  textDisabled: "#bdc1c6",
  brandPrimary: "#1a73e8",
  brandPrimaryBg: "rgba(26,115,232,0.08)",
  brandPrimaryText: "#1a73e8",
  onTrack: "#18B96E",
  onTrackBg: "rgba(30,142,62,0.09)",
  onTrackBorder: "rgba(30,142,62,0.25)",
  offTrack: "#d93025",
  nullTrack: "#767a8191",
  offTrackBg: "rgba(217,48,37,0.08)",
  offTrackBorder: "rgba(217,48,37,0.22)",
  attention: "#f29900",
  attentionBg: "rgba(242,153,0,0.09)",
  attentionBorder: "rgba(242,153,0,0.28)",
  pillarFast: "#1a73e8",
  pillarAccel: "#7b1fa2",
  pillarScale: "#0097a7",
  pillarTrans: "#e65100",
  sidebarBg: "#ffffff",
  sidebarBorder: "rgba(0,0,0,0.08)",
  chipActiveBg: "rgba(26,115,232,0.09)",
  chipActiveBorder: "rgba(26,115,232,0.3)",
  tableHeaderBg: "#010035",
  rowEvenBg: "#ffffff",
  rowOddBg: "#fafafa",
  rowExpandBg: "#f0f4ff",
  shadow: "0 1px 3px rgba(60,64,67,0.12), 0 1px 2px rgba(60,64,67,0.08)",
  shadowMd: "0 4px 8px rgba(60,64,67,0.15), 0 1px 3px rgba(60,64,67,0.1)",
  boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  typography: {
    // fontFamily: "Inter, sans-serif",

    h1: { fontSize: "32px", fontWeight: 700 },
    h2: { fontSize: "24px", fontWeight: 600 },
    h3: { fontSize: "20px", fontWeight: 600 },

    body1: { fontSize: "14px", fontWeight: 400 },
    body2: { fontSize: "12px", fontWeight: 400 },

    caption: { fontSize: "11px", fontWeight: 400 },
  },
};

interface ThemeCtx {
  theme: Theme;
  toggle: () => void;
}

const Ctx = createContext<ThemeCtx>({
  theme: LIGHT,
  toggle: () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>("light");
  const theme = mode === "dark" ? DARK : LIGHT;
  const toggle = () => setMode((m) => (m === "dark" ? "light" : "dark"));
  return <Ctx.Provider value={{ theme, toggle }}>{children}</Ctx.Provider>;
}

export const useTheme = () => useContext(Ctx);
