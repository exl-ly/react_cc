export const towerOptions = [
  "Product & Development",
  "AI",
  "Breakthrough",
  "Cross GPT",
  "Enterprise Tech",
  "GPT Strat Ops",
];
