import { Sun, Moon } from "lucide-react";
import type { Initiative } from "../data/initiatives";
import { useTheme } from "../theme-context";
import {
  Avatar,
  Box,
  Button,
  FormControlLabel,
  Switch,
  Tooltip,
  Typography,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import { useNavigate } from "react-router-dom";
import adplogo from "../../images/adp-logo.jpg";
import React from "react";

interface FastHeaderProps {
  initiatives: Initiative[];
  filteredInitiatives: Initiative[];
  activePillar?: string | null;
  onPillarFilter?: (pillar: string | null) => void;
  activeStatus?: string | null;
  onStatusFilter?: (status: string | null) => void;
}

const FAST_PILLARS = [
  {
    key: "Focus",
    letter: "F",
    full: "Focus",
    sub: "BU & Functional Priorities",
    pillarKey: "pillarFast" as const,
  },
  {
    key: "Acceleration",
    letter: "A",
    full: "Accelerate",
    sub: "Product Portfolio Impact",
    pillarKey: "pillarAccel" as const,
  },
  {
    key: "Scale",
    letter: "S",
    full: "Scale",
    sub: "GPT Led Growth Bets",
    pillarKey: "pillarScale" as const,
  },
  {
    key: "Transform",
    letter: "T",
    full: "Transform",
    sub: "GPT Operations & Engagement",
    pillarKey: "pillarTrans" as const,
  },
];

export function FastHeaderNew({
  initiatives,
  filteredInitiatives,
  selectedTowers = [],
  setSelectedTowers,
  towerOptions = [],
}: FastHeaderProps) {
  if (selectedTowers.length === towerOptions.length && setSelectedTowers)
    selectedTowers = [];
  const { theme, toggle } = useTheme();

  const navigate = useNavigate();

  const isLight = theme.mode === "light";
  console.log("initiatives", initiatives);
  console.log("filteredInitiatives", filteredInitiatives);

  return (
    <>
      <div
        style={{
          background: theme.surface,
          borderBottom: `1px solid ${theme.border}`,
        }}
      >
        {/* Top bar */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "10px 8px 10px",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {/* ADP-style logo bar */}
            {/* <div style={{ display: "flex", alignItems: "center", gap: 2 }}>
              {["#4285f4", "#ea4335", "#fbbc04", "#34a853"].map((c, i) => (
                <div
                  key={i}
                  style={{
                    width: 4,
                    height: 28,
                    background: c,
                    borderRadius: 2,
                  }}
                />
              ))}
            </div> */}

            <img
              src={adplogo}
              alt="ADP-Logo"
              style={{ width: "60px", height: "26px" }}
            />

            <div>
              <div
                style={{
                  color: theme.textPrimary,
                  fontSize: 15,
                  fontWeight: 500,
                  letterSpacing: "0.01em",
                  lineHeight: 1.3,
                }}
              >
                Command Center - Overview
              </div>
              <div
                style={{
                  color: theme.textTertiary,
                  fontSize: 11,
                  marginTop: 1,
                  letterSpacing: "0.02em",
                }}
              >
                Strategic Initiative Dashboard · FY2027
              </div>
            </div>
          </div>

          {setSelectedTowers && towerOptions.length > 0 && (
            <div
              style={{
                display: "flex",
                gap: 3,
                flexWrap: "wrap",
                alignItems: "center",
                // justifyContent:"center"
                // marginRight:"10px"
              }}
            >
              {towerOptions.map((tab) => {
                const isActive =
                  selectedTowers.length > 0 && selectedTowers.includes(tab);
                console.log(`${tab} activated: ${isActive}`);
                return (
                  <Box
                    key={tab}
                    onClick={() => {
                      setSelectedTowers([tab]);
                    }}
                    sx={{
                      padding: "6px 8px",
                      borderBottom: isActive
                        ? "1px solid rgb(217, 48, 37)"
                        : "1px solid transparent",
                      cursor: "pointer",
                      fontSize: 10,
                      fontWeight: 500,
                      color: isActive ? "rgb(217, 48, 37)" : "#666",
                      transition: "0.2s ease",

                      "&:hover": {
                        color: isActive
                          ? "rgb(230, 90, 82)" // lighter active red
                          : "#888",
                        backgroundColor: "rgba(217, 48, 37, 0.06)",
                      },
                    }}
                  >
                    {tab}
                  </Box>
                );
              })}
            </div>
          )}

          <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
            {/* Summary stats */}
            <div style={{ display: "flex", gap: 4 }}>
              {[
                {
                  label: "Total",
                  value: 27,
                  color: theme.textSecondary,
                  bg: isLight ? "#f1f3f4" : theme.surface,
                  key: null,
                },
                {
                  label: "On Track",
                  value: 18,
                  color: theme.onTrack,
                  bg: theme.onTrackBg,
                  key: "on-track",
                },
                {
                  label: "Off Track",
                  value: 1,
                  color: theme.offTrack,
                  bg: theme.offTrackBg,

                  key: "off-track",
                },
                {
                  label: "Needs Attention",
                  value: 8,
                  color: theme.attention,
                  bg: theme.attentionBg,
                  key: "attention",
                },
              ].map((s) => {
                return (
                  <button
                    key={s.label}
                    style={{
                      textAlign: "center",
                      padding: "6px 5px",
                      borderRadius: 8,
                      background: s.bg,
                      minWidth: "75px",
                      maxWidth: "75px",
                      // border: `1.5px solid ${s.color}`,
                      // : `1px solid ${theme.border}`,
                      // cursor: "pointer",
                      transition: "all 0.15s ease",
                      // boxShadow: isActive ? `0 0 0 2px ${s.color}22` : "none",
                      outline: "none",
                    }}
                  >
                    <div
                      style={{
                        color: s.color,
                        fontSize: 20,
                        fontWeight: 700,
                        lineHeight: 1,
                        letterSpacing: "-0.02em",
                      }}
                    >
                      {s.value}
                    </div>
                    <div
                      style={{
                        color: theme.textTertiary,
                        // fontSize: 10,
                        marginTop: 3,
                        fontWeight: 500,
                        letterSpacing: "0.02em",
                        fontSize: "8px",
                      }}
                    >
                      {s.label}
                    </div>
                  </button>
                );
              })}
            </div>

            <Box sx={{ display: "flex", alignItems: "center" }}>
              <div
                style={{
                  padding: "5px 10px",
                  background: theme.tableHeaderBg,
                  borderRadius: 6,
                  color: "#ffffff",
                  fontSize: 11,
                  fontFamily: "var(--font-mono)",
                  border: `1px solid ${theme.chipActiveBorder}`,
                  fontWeight: 500,
                }}
              >
                Live ·{" "}
                {new Date().toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </div>
            </Box>
            <Avatar sx={{width:40, height:40}}></Avatar>
          </div>
        </div>
      </div>
    </>
  );
}
