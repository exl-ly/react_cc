import React, { useMemo, useRef, useState } from "react";

import { Search, LayoutGrid, List, RefreshCw } from "lucide-react";

import { ThemeProvider, useTheme } from "./../../theme-context";

import dashboardData from "../../data/dashboardData.json";
import { useNavigate } from "react-router-dom";
import { FastHeader } from "../fast-header";
import { INITIATIVES } from "../../data/initiatives";
import { FastHeaderNew } from "../fast-header-new";
import TransformationHealth from "./TransformationHealth";
import PillarSectionNew from "./PillarSectionNew";
import Footer from "./Footer";
import ChatRoundedIcon from "@mui/icons-material/ChatRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import SendRoundedIcon from "@mui/icons-material/SendRounded";
import {
  Modal,
  Card,
  Box,
  Typography,
  IconButton,
  TextField,
  Button,
  Avatar,
  Stack,
  Tooltip,
} from "@mui/material";
import PriorityMatrix from "./PriorityMatrix";
import { towerOptions } from "../../data/mockData";

const FastDashboardNew = () => {
  const data = dashboardData;
  const navigate = useNavigate();
  const { theme } = useTheme();
  const isLight = theme.mode === "light";

  const [isReady, setIsReady] = useState(false);
  const [selectedTowers, setSelectedTowers] = useState(towerOptions);

  const [activeLeader, setActiveLeader] = useState<string | null>(null);
  const [activePillar, setActivePillar] = useState<string | null>(null);
  const [activeStatus, setActiveStatus] = useState<string | null>(null);
  const [activeTower, setActiveTower] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grouped" | "flat">("grouped");
  //   const [showCockpitView, setShowCockpitView] = useState(false);
  const [hover, setHover] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const bottomRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const filtered = useMemo(() => {
    const result = INITIATIVES.filter((i) => {
      if (selectedTowers.length > 0 && !selectedTowers.includes(i.tower)) {
        return false;
      }
      if (activeLeader && i.leader !== activeLeader) return false;
      if (activePillar && i.pillar !== activePillar) return false;
      if (activeStatus && i.status !== activeStatus) return false;
      if (activeTower && i.tower !== activeTower) return false;
      if (activeCategory && i.category !== activeCategory) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          i.name.toLowerCase().includes(q) ||
          i.id.toLowerCase().includes(q) ||
          i.leader.toLowerCase().includes(q) ||
          i.statusNote.toLowerCase().includes(q)
        );
      }
      return true;
    });
    return result;
  }, [
    INITIATIVES,
    activeLeader,
    activePillar,
    activeStatus,
    selectedTowers,
    activeTower,
    activeCategory,
    searchQuery,
  ]);

  const toolbarBg = isLight ? "#ffffff" : "#0c1018";

  const buttonStyle = {
    display: isVisible ? "flex" : "none",
    position: "fixed",
    bottom: "60px",
    right: "25px",
    zIndex: 1000,
    cursor: "pointer",
    // Transparent charcoal tint by default, solid black on hover
    backgroundColor: isHovered ? "#000000" : "rgba(0, 0, 0, 0.4)",
    color: "#fff",
    border: "none",
    borderRadius: "40%",
    width: "40px",
    height: "40px",
    fontSize: "20px",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    // Added transition for the transparent effect to smoothly change into black
    transition: "background-color 0.3s ease",
  };

  const [openChat, setOpenChat] = useState(false);

  const chatButtonStyle = {
    position: "fixed",
    bottom: "18px",
    right: "24px",
    width: "30px",
    height: "30px",
    borderRadius: "50%",
    border: "none",
    background:
      "linear-gradient(135deg, rgb(1 47 107 / 83%) 0%, rgb(1 82 184 / 83%) 100%)",
    color: "#fff",
    cursor: "pointer",
    zIndex: 9999,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 10px 30px rgba(79,70,229,0.35)",
    transition: "all .3s ease",
    transform: isHovered ? "scale(1.08)" : "scale(1)",

    animation: isHovered ? "wave 1.5s infinite" : "none",
  };

  const [comment, setComment] = useState("");

  const [comments, setComments] = useState([
    {
      user: "Shiva",
      text: "Need immediate focus on Cloud Migration milestones.",
    },
    {
      user: "Sathish",
      text: "AI adoption metrics should be reviewed weekly.",
    },
  ]);

  const handlePost = () => {
    if (!comment.trim()) return;

    const newComment = {
      user: "You",
      text: comment,
    };

    setComments((prev) => [...prev, newComment]);

    // clear input
    setComment("");
  };

  const [healthCounts, setHealthCounts] = useState({
    overall: 0,
    focus: 0,
    accelerate: 0,
    scale: 0,
    transform: 0,
  });

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        background: theme.bg,
        color: theme.textPrimary,
        fontFamily: "var(--font-sans, Roboto, system-ui, sans-serif)",
        overflow: "hidden",
        transition: "background 0.2s, color 0.2s",
      }}
    >
      {/* <Overview /> */}
      {/* <button
        // onClick={onClickHandler}
        // onMouseEnter={() => setHover(true)}
        // onMouseLeave={() => setHover(false)}
        style={{
          color: "inherit",
          background: "rgb(202 201 241)",
          cursor: "pointer",
          transition: "color 0.2s ease",
          boxShadow: "0 1px 3px rgba(60,64,67,0.06)",
        }}
      ></button> */}

      <div>
        <FastHeaderNew
          initiatives={INITIATIVES}
          filteredInitiatives={filtered}
          activePillar={activePillar}
          onPillarFilter={setActivePillar}
          activeStatus={activeStatus}
          onStatusFilter={setActiveStatus}
          selectedTowers={selectedTowers}
          setSelectedTowers={setSelectedTowers}
          towerOptions={towerOptions}
        />
      </div>

      {/* <Box>
        <TransformationHealth counts={healthCounts} />
      </Box> */}

      <Box
        sx={{
          width: "100%",
          backgroundColor: "#fff",
          padding: "10px 10px",
        }}
      >
        <Card
          elevation={0}
          sx={{
            flex: 10,
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            p: 1,
            backgroundColor: "#fff",
            minHeight: 420,
          }}
        >
          <PriorityMatrix setHealthCounts={setHealthCounts} />
        </Card>
      </Box>

      {/* Floating Chat Button */}
      <Tooltip
        title="Comment Section"
        arrow
        slotProps={{
          tooltip: {
            sx: {
              fontSize: "8px",
            },
          },
        }}
      >
        <Box
          component="button"
          onClick={() => setOpenChat(true)}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          sx={chatButtonStyle}
        >
          <ChatRoundedIcon sx={{ fontSize: 18 }} />

          {/* Wave */}
          <Box
            sx={{
              position: "absolute",
              inset: -8,
              borderRadius: "50%",
              border: "2px solid rgba(99,102,241,.4)",
              animation: isHovered ? "pulse 1.4s infinite" : "none",

              "@keyframes pulse": {
                "0%": {
                  transform: "scale(1)",
                  opacity: 0.7,
                },
                "100%": {
                  transform: "scale(1.6)",
                  opacity: 0,
                },
              },
            }}
          />
        </Box>
      </Tooltip>

      {/* Chat Modal */}
      <Modal open={openChat} onClose={() => setOpenChat(false)}>
        <Card
          sx={{
            position: "absolute",
            bottom: 80,
            right: 30,
            width: 360,
            height: 500,
            borderRadius: 3,
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            outline: "none",
          }}
        >
          {/* Header */}
          <Box
            sx={{
              px: 1.5,
              py: 1,
              bgcolor: "#4F46E5",
              color: "#fff",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography fontWeight={700}>Comments</Typography>

            <IconButton
              size="small"
              onClick={() => setOpenChat(false)}
              sx={{ color: "#fff" }}
            >
              <CloseRoundedIcon />
            </IconButton>
          </Box>

          {/* Comment List */}
          <Box
            sx={{
              flex: 1,
              overflowY: "auto",
              p: 2,
              bgcolor: "#fafafa",
            }}
          >
            {comments.map((item, index) => (
              <Stack
                key={index}
                direction="row"
                spacing={1}
                mb={2}
                alignItems="flex-start"
              >
                <Avatar sx={{ width: 28, height: 28 }}>{item.user[0]}</Avatar>

                <Box
                  sx={{
                    bgcolor: "#fff",
                    p: 1,
                    borderRadius: 2,
                    boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                    flex: 1,
                  }}
                >
                  <Typography
                    sx={{
                      fontWeight: 700,
                      fontSize: "12px",
                    }}
                  >
                    {item.user}
                  </Typography>

                  <Typography
                    sx={{
                      fontSize: "12px",
                      color: "#475569",
                    }}
                  >
                    {item.text}
                  </Typography>
                </Box>
              </Stack>
            ))}
          </Box>

          {/* Input Area */}
          <Box
            sx={{
              borderTop: "1px solid #E2E8F0",
              p: 1,
              bgcolor: "#fff",
            }}
          >
            <TextField
              fullWidth
              multiline
              minRows={2}
              maxRows={4}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Write a comment..."
              size="small"
              sx={{
                "& .MuiOutlinedInput-root": {
                  borderRadius: 3,
                  fontSize: "13px",
                },
              }}
            />

            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                mt: 1,
              }}
            >
              <Button
                variant="contained"
                endIcon={<SendRoundedIcon />}
                disabled={!comment.trim()}
                onClick={handlePost}
                sx={{
                  borderRadius: 5,
                  textTransform: "none",
                }}
              >
                Post
              </Button>
            </Box>
          </Box>
        </Card>
      </Modal>
    </div>
  );
};

export default FastDashboardNew;
