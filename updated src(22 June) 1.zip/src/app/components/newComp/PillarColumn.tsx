import {
    Box,
    Typography,
    Divider,
  } from "@mui/material";
  
  import ReusableInitiativeCard from "./ReusableInitiativeCard";
  
  import { Pillar } from "../../data/pillarTypes";
  
  interface Props {
    pillar: Pillar;
  }
  
  export default function PillarColumn({
    pillar,
  }: Props) {
    return (
      <Box
        sx={{
          minWidth: 0,
          borderRadius: 1,
          bgcolor: "#fff",
          border: "1px solid #E2E8F0",
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            p: "10px",
            color: "#FFF",
            // background: `linear-gradient(135deg, ${pillar.color}, ${pillar.color}CC)`,
          }}
        >
          <Typography
            sx={{
              fontWeight: 700,
              fontSize: 14,
              letterSpacing: 1,
              color: "#010035"
            }}
          >
            {pillar.name}
          </Typography>
          <Divider
          sx={{
            my: 0.5,
            borderBottomWidth: 1.5,
            borderColor: "#010035",
          }}
        />
{/*   
          <Typography
            sx={{
              opacity: 0.85,
              fontSize: 12,
              mt: 0.5,
            }}
          >
            {pillar.initiatives.length} Initiatives
          </Typography> */}
        </Box>
  
        <Box
          sx={{
            p: 0.5,
            mt: -1,
          }}
        >
          {pillar.initiatives.map(
            (initiative) => (
              <ReusableInitiativeCard
                key={initiative.id}
                initiative={initiative}
              />
            )
          )}
        </Box>
      </Box>
    );
  }