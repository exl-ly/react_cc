import { Box, CircularProgress, Typography } from "@mui/material";

interface ScoreRingProps {
  value: number;
}

const getColor = (value: number) => {
  if (value >= 80) return "#16A34A";
  if (value >= 60) return "#F59E0B";
  return "#DC2626";
};

export default function ScoreRing({
  value,
}: ScoreRingProps) {
  return (
    <Box
      sx={{
        position: "relative",
        display: "inline-flex",
      }}
    >
      <CircularProgress
        variant="determinate"
        value={100}
        size={42}
        thickness={4}
        sx={{
          color: "#E2E8F0",
          position: "absolute",
        }}
      />

      <CircularProgress
        variant="determinate"
        value={value}
        size={42}
        thickness={4}
        sx={{
          color: getColor(value),
        }}
      />

      <Box
        sx={{
          inset: 0,
          position: "absolute",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Typography
          sx={{
            fontSize: 11,
            fontWeight: 700,
          }}
        >
          {value}
        </Typography>
      </Box>
    </Box>
  );
}