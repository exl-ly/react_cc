// import { Box } from "@mui/material";
// import { InitiativeV1 } from "../../data/typesTower";
// import InitiativeCardV1 from "./InitiativeCardV1";

// interface Props {
//   initiatives: InitiativeV1[];
// }

// export default function InitiativeCellV1({
//   initiatives,
//   selectedStatus,
// }: Props) {
//   return (
//     <Box
//       sx={{
//         minHeight: 0,
//         display: "flex",
//         flexDirection: "column",
//         gap: 0,
//         p: 0,
//       }}
//     >
//       {initiatives.map((item) => (
//         <InitiativeCardV1
//           key={item.id}
//           initiative={item}
//           selectedStatus={selectedStatus}
//         />
//       ))}
//     </Box>
//   );
// }

import { Box, Typography } from "@mui/material";
import InitiativeCardV1 from "./InitiativeCardV1";
import { Initiative } from "../../data/types";
import { useTheme } from "../../theme-context";

interface Props {
  initiatives: Initiative[];
}

export default function InitiativeCellV1({
  initiatives,
  selectedStatus,
  selectedTowers,
}: Props) {
  const { theme, toggle } = useTheme();

  const filteredInitiatives = initiatives.filter(
    (item) =>
      selectedTowers.includes(item.towerTeam) &&
      (item.status === selectedStatus || !selectedStatus) &&
      item.hasdata === true
  );
  return (
    <Box
      sx={{
        // minHeight: 30,
        display: "flex",
        flexDirection: "column",
        gap: 1,
        // p: 1,
      }}
    >
      {filteredInitiatives.length > 0 ? (
        filteredInitiatives.map((item) => (
          <InitiativeCardV1
            key={item.id}
            initiative={item}
            selectedStatus={selectedStatus}
            selectedTowers={selectedTowers}
          />
        ))
      ) : (
        <Box
          sx={{
            minHeight: 64,
            maxHeight: 66,
            padding: "4px 5px",

            // 1. Core Centering Properties
            display: "flex",
            alignItems: "center",
            justifyContent: "center",

            // border: "1px solid #E2E8F0",
            borderRadius: "5px",
            backgroundColor: "#fff",
            boxSizing: "border-box",
          }}
        >
          {/* 2. Direct Child without the unnecessary inner Box */}
          <Typography
            variant="body2"
            sx={{ fontSize: "10px", color: theme.textPrimary }}
          ></Typography>
        </Box>
      )}
    </Box>
  );
}
