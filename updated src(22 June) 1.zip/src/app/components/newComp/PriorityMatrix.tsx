import {
  Box,
  Typography,
  Paper,
  Switch,
  FormControlLabel,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  OutlinedInput,
  ListItemText,
  SelectChangeEvent,
  Chip,
  Button,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import IconButton from "@mui/material/IconButton";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import { initiatives, priorities, teams } from "../../data/newData";
import { useTheme } from "../../theme-context";
import PillarOverview from "./PillarOverview";
import {
  initiativesV1,
  prioritiesV1,
  teamsV1,
} from "../../data/newDataTowerView";

import InitiativeCell from "./InitiativeCell";
import { useState, useEffect } from "react";
import InitiativeCellV1 from "./InitiativeCellV1";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import FocusSection from "./FocusSection";
import AccelerateSection from "./AccelerateSection";
import ScaleSection from "./ScaleSection";
import TransformSection from "./TransformSection";

export default function PriorityMatrix() {
  const [isOn, setIsOn] = useState(true);
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState(null);
  const towerOptions = [
    "Product & Development",
    "AI",
    "Breakthrough",
    "Cross GPT",
    "Enterprise Technology",
    "GPT Strat Ops",
  ];
  const [selectedTowers, setSelectedTowers] = useState(towerOptions);
  const [selectedPriority, setSelectedPriority] = useState(null);

  // const statusItems = [
  //   { label: "On Track", color: "#10B981" },
  //   { label: "Needs Attention", color: "#F59E0B" },
  //   { label: "Off Track", color: "#EF4444" },
  //   { label: "Reset", color: "#9CA3AF" },
  // ];

  const isAllSelected = selectedTowers.length === towerOptions.length;

  const handleClearAll = () => {
    setSelectedTowers(towerOptions); // reset to ALL
  };

  const handleTowerChange = (event) => {
    const value = event.target.value;

    // Select All logic inside dropdown
    if (value.includes("ALL")) {
      setSelectedTowers(isAllSelected ? [] : towerOptions);
      return;
    }

    setSelectedTowers(typeof value === "string" ? value.split(",") : value);
  };

  const handleClear = () => {
    setSelectedTowers(towerOptions); // reset to ALL
  };

  const filteredData = () => {
    return initiatives.filter(
      (x) => selectedTowers.includes(x.towerTeam) || x.status === selectedStatus
    );
  };

  const getInitiatives = (priorityId: string, teamId: string) => {
    return initiatives.filter(
      (x) => x.priority === priorityId && x.team === teamId
    );
  };

  const getInitiativesV1 = (priorityId: string, teamId: string) => {
    return initiativesV1.filter(
      (x) => x.priority === priorityId && x.team === teamId
    );
  };

  // const teamColors = {
  //   Focus: "rgba(26, 115, 232, 0.125)",
  //   Accelerate: "rgba(123, 31, 162, 0.125)",
  //   Scale: "rgba(0, 151, 167, 0.125)",
  //   Transform: "rgba(230, 81, 0, 0.125)",
  // };

  const teamColors = {
    Focus: theme.tableHeaderBg,
    Accelerate: theme.tableHeaderBg,
    Scale: theme.tableHeaderBg,
    Transform: theme.tableHeaderBg,
  };

  const statusBg = {
    "On Track": {
      default: "rgba(30, 142, 62, 0.07)",
      hover: "rgba(30, 142, 62, 0.16)",
      active: "rgba(30, 142, 62, 0.24)",
    },
    "Off Track": {
      default: "rgba(217, 48, 37, 0.07)",
      hover: "rgba(217, 48, 37, 0.15)",
      active: "rgba(217, 48, 37, 0.22)",
    },
    "Needs Attention": {
      default: "rgba(242, 153, 0, 0.07)",
      hover: "rgba(242, 153, 0, 0.16)",
      active: "rgba(242, 153, 0, 0.24)",
    },
    Reset: {
      default: "rgba(107,114,128,0.07)",
      hover: "rgba(107,114,128,0.14)",
      active: "rgba(107,114,128,0.22)",
    },
  };

  const statusItems = [
    { label: "On Track", color: theme.onTrack },
    { label: "Off Track", color: theme.offTrack },
    { label: "Needs Attention", color: theme.attention },
    // { label: "Not Started", color: "#9CA3AF" },
    { label: "Reset", color: "#6B7280" }, // add reset
  ];

  const handleResetFilters = () => {
    setSelectedStatus(null);
    setSelectedTowers(towerOptions);
    setSelectedPriority(null);
  };

  // Filter your initiatives array dynamically based on the state
  const filteredInitiatives = selectedPriority
    ? initiatives.filter((i) => i.priority === selectedPriority)
    : initiatives;

  return (
    <Box sx={{ maxHeight: 400, overflow: "scroll" }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.8 }}>
        <Box sx={{display: "flex", gap: "5px"}}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "start",
            alignItems: "center",
          }}
        >
          <Typography
            fontWeight={700}
            sx={{
              fontSize: "12px",
              marginRight: "10px",
              color: theme.textPrimary,
            }}
          >
            {/* Initiatives By Priority */}
            Priority
          </Typography>
          {!isOn &&  <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 0.5,
          }}
        >
          <Button
            onClick={() =>
              setSelectedPriority(selectedPriority === "p1" ? null : "p1")
            }
            sx={{
              minWidth: 28,
              height: 20,
              px: 0.5,
              py: 0,
              fontSize: "10px",
              background: selectedPriority === "p1" ? "#333366" : "#b0b0b0", // Darker when active
              color: selectedPriority === "p1" ? "#fff" : "#333",
              "&:hover": { background: "#5a598c" },
            }}
          >
            P1
          </Button>
          <Button
            onClick={() =>
              setSelectedPriority(selectedPriority === "p2" ? null : "p2")
            }
            sx={{
              minWidth: 28,
              height: 20,
              px: 0.5,
              py: 0,
              fontSize: "10px",
              background: selectedPriority === "p2" ? "#333366" : "#b0b0b0",
              color: selectedPriority === "p2" ? "#fff" : "#333",
              "&:hover": { background: "#5a598c" },
            }}
          >
            P2
          </Button>
          <Button
            onClick={() =>
              setSelectedPriority(selectedPriority === "p3" ? null : "p3")
            }
            sx={{
              minWidth: 28,
              height: 20,
              px: 0.5,
              py: 0,
              fontSize: "10px",
              // fontWeight: 900,
              background: selectedPriority === "p3" ? "#333366" : "#b0b0b0",
              color: selectedPriority === "p3" ? "#fff" : "#333",
              "&:hover": { background: "#5a598c" },
            }}
          >
            P3
          </Button>
        </Box>}          
        </Box>
        <Box display="flex" alignItems="center" gap={0.5}>
          <Typography
            sx={{
              fontSize: "10px",
              fontWeight: !isOn ? 700 : 400,
              opacity: !isOn ? 1 : 0.5,
              transition: "all 0.2s ease",
              color: "rgb(1 47 107 / 83%)",
            }}
          >
            Progress View
          </Typography>

          <Switch
            checked={isOn}
            onChange={(e) => setIsOn(e.target.checked)}
            size="small"
            sx={{
              transform: "scale(0.75)",
              m: 0,

              "& .MuiSwitch-switchBase.Mui-checked": {
                color: "rgb(1 47 107 / 83%)",
              },

              "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                backgroundColor: "rgb(1 47 107 / 33%)",
                opacity: 1,
              },
            }}
          />

          <Typography
            sx={{
              fontSize: "10px",
              fontWeight: isOn ? 700 : 400,
              opacity: isOn ? 1 : 0.5,
              color: "rgb(1 47 107 / 83%)",
              transition: "all 0.2s ease",
            }}
          >
            Metrics View
          </Typography>
        </Box>
        </Box>

       
        {!isOn &&   <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 1,
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              gap: 0.5,
              alignItems: "center",
            }}
          >
            {/* External Label */}
            <Typography
              sx={{ fontSize: 10, fontWeight: 600, color: theme.textSecondary }}
            >
              Filter By Tower:
            </Typography>

            <FormControl sx={{ width: 200 }} size="small">
              <Box sx={{ position: "relative", width: 260 }}>
                {/* 🔥 Universal Close Icon */}
                {!isAllSelected && (
                  <IconButton
                    size="small"
                    onClick={handleClearAll}
                    sx={{
                      position: "absolute",
                      right: 90,
                      top: "50%",
                      transform: "translateY(-50%)",
                      zIndex: 2,
                    }}
                  >
                    <CloseIcon sx={{ fontSize: 12 }} />
                  </IconButton>
                )}

                <Select
                  multiple
                  open={open}
                  onOpen={() => setOpen(true)}
                  onClose={() => setOpen(false)}
                  IconComponent={() => (
                    <KeyboardArrowDownIcon
                      sx={{
                        position: "absolute",
                        right: 8,
                        color: "#d0271d",
                        transition: "transform 0.3s ease",
                        transform: open ? "rotate(180deg)" : "rotate(0deg)",
                      }}
                    />
                  )}
                  value={selectedTowers}
                  onChange={handleTowerChange}
                  displayEmpty
                  sx={{
                    width: "75%",
                    minHeight: 38,
                    borderRadius: 0,

                    // 🔥 space for close icon
                    pr: 4,
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#010035",
                      borderWidth: "1px",
                    },

                    "&:hover .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#010035",
                    },

                    "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#010035",
                      borderWidth: "1px", // prevents MUI's thicker focus border
                    },

                    ...(open && {
                      boxShadow: "0 0 4px 2px #ae2019",
                    }),

                    "& .MuiSelect-select": {
                      display: "flex",
                      flexWrap: "wrap", // 🔥 allow chips wrapping
                      gap: 0.5, // 🔥 spacing between chips
                      alignItems: "center",
                      overflow: "hidden",
                      whiteSpace: "normal",
                      py: 0.6,
                    },
                  }}
                  renderValue={() =>
                    isAllSelected ? (
                      <Typography
                        sx={{ fontSize: 12, color: theme.textPrimary }}
                      >
                        All
                      </Typography>
                    ) : (
                      <Box
                        sx={{
                          display: "flex",
                          flexWrap: "wrap",
                          backgroundColor: "#fff",
                          gap: 0.5, // 🔥 spacing between chips
                        }}
                      >
                        {selectedTowers.map((value) => (
                          <Chip
                            key={value}
                            label={value}
                            size="small"
                            onMouseDown={(e) => e.stopPropagation()}
                            onDelete={() =>
                              setSelectedTowers((prev) =>
                                prev.filter((item) => item !== value)
                              )
                            }
                            sx={{
                              height: 20,
                              fontSize: 10,
                              color: theme.textPrimary,
                            }}
                          />
                        ))}
                      </Box>
                    )
                  }
                >
                  {/* Select All */}
                  <MenuItem
                    value="ALL"
                    sx={{
                      "&:hover": {
                        backgroundColor: "#ffe5e7",
                      },
                      "&.Mui-selected": {
                        backgroundColor: "#ffe5e7",
                      },
                      "&.Mui-selected:hover": {
                        backgroundColor: "#ffe5e7",
                      },
                    }}
                  >
                    <Checkbox
                      checked={isAllSelected}
                      sx={{
                        color: theme.tableHeaderBg,
                        "&.Mui-checked": {
                          color: theme.tableHeaderBg,
                        },
                      }}
                    />
                    <ListItemText
                      primary="Select All"
                      primaryTypographyProps={{
                        fontSize: 10,
                        color: theme.textPrimary,
                      }}
                    />
                  </MenuItem>

                  {/* Options */}
                  {towerOptions.map((tower) => (
                    <MenuItem
                      key={tower}
                      value={tower}
                      sx={{
                        "&:hover": {
                          backgroundColor: "#ffe5e7",
                        },
                        "&.Mui-selected": {
                          backgroundColor: "#ffe5e7",
                        },
                        "&.Mui-selected:hover": {
                          backgroundColor: "#ffe5e7",
                        },
                      }}
                    >
                      <Checkbox
                        checked={selectedTowers.includes(tower)}
                        sx={{
                          color: theme.tableHeaderBg,
                          "&.Mui-checked": {
                            color: theme.tableHeaderBg,
                          },
                        }}
                      />
                      <ListItemText
                        primary={tower}
                        primaryTypographyProps={{
                          fontSize: 10,
                          color: theme.textPrimary,
                        }}
                      />
                    </MenuItem>
                  ))}
                </Select>
              </Box>
            </FormControl>
          </Box>
          {statusItems.map((item) => (
            <Box
              key={item.label}
              onClick={() =>
                item.label === "Reset"
                  ? handleResetFilters()
                  : setSelectedStatus(item.label)
              }
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                cursor: "pointer",
                px: "5px",
                py: 0.7,
                borderRadius: 2,
                transition: "all 0.2s ease",

                backgroundColor:
                  item.label === "Reset"
                    ? "rgba(107,114,128,0.04)"
                    : selectedStatus === item.label && statusBg[item.label]
                    ? statusBg[item.label].active
                    : statusBg[item.label]?.default || "transparent",

                border:
                  selectedStatus === item.label
                    ? `1px solid ${
                        item.label === "On Track"
                          ? "rgba(16, 185, 129, 0.6)"
                          : item.label === "Needs Attention"
                          ? "rgba(242, 153, 0, 0.6)"
                          : item.label === "Off Track"
                          ? "rgba(217, 48, 37, 0.6)"
                          : "rgba(107,114,128,0.6)"
                      }`
                    : "1px solid transparent",

                "&:hover": {
                  backgroundColor:
                    item.label === "Reset"
                      ? "rgba(107,114,128,0.15)"
                      : selectedStatus === item.label
                      ? statusBg[item.label].active
                      : statusBg[item.label]?.hover || "rgba(0,0,0,0.04)",

                  border:
                    selectedStatus === item.label
                      ? `1px solid ${
                          item.label === "On Track"
                            ? "rgba(16, 185, 129, 0.8)"
                            : item.label === "Needs Attention"
                            ? "rgba(242, 153, 0, 0.8)"
                            : item.label === "Off Track"
                            ? "rgba(217, 48, 37, 0.8)"
                            : "rgba(107,114,128,0.8)"
                        }`
                      : "1px solid transparent",
                },
              }}
            >
              {/* Icon / dot */}
              {item.label === "Reset" ? (
                <RestartAltIcon sx={{ fontSize: 12, color: "#6B7280" }} />
              ) : (
                <Box
                  sx={{
                    width: 6,
                    height: 6,
                    borderRadius: "50%",
                    bgcolor: item.color,
                  }}
                />
              )}

              <Typography
                variant="caption"
                sx={{
                  // width: "45px",
                  fontSize: 9,
                  fontWeight: selectedStatus === item.label ? 700 : 500,
                }}
              >
                {item.label}
              </Typography>
            </Box>
          ))}
        </Box>}
      </Box>
      {!isOn ? (
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: 1,
            alignItems: "start",
          }}
        >
          {teams.map((team) => (
            <Box
              key={team.id}
              sx={{ display: "flex", flexDirection: "column", gap: 1 }}
            >
              {/* Team Header INSIDE column */}
              <Paper
                sx={{
                  p: 0.5,
                  textAlign: "center",
                  bgcolor: teamColors[team.name] || "#757575",
                  color: "#fff",
                  borderRadius: 1,
                }}
              >
                <Typography fontWeight={700} sx={{ fontSize: "11px" }}>
                  {team.name}
                </Typography>
              </Paper>

              {/* Initiatives - CHANGED FROM initiatives TO filteredInitiatives */}
              {filteredInitiatives
                .filter((i) => i.team === team.id)
                .map((initiative) => (
                  <Paper key={initiative.id} sx={{ padding: "5px" }}>
                    <InitiativeCell
                      initiatives={[initiative]}
                      selectedStatus={selectedStatus}
                      selectedTowers={selectedTowers}
                    />
                  </Paper>
                ))}
            </Box>
          ))}
        </Box>
      ) : (
       <PillarOverview />
      )}
    </Box>
  );
}
