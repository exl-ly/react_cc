import {
    Box,
    Card,
    Divider,
    LinearProgress,
    Stack,
    Typography,
  } from "@mui/material";
  
  const data = [
    {
      title: "AI Adoption & Enablement",
      items: [
        { label: "AI Tools Adoption Progress (%)", value: 30, type: "progress", },       
        { label: "AI Training Coverage Progress (%)", value: 55, type: "progress", },
        { label: "AI Productivity Benefit (Cumulative %)", value: 30, type: "progress", },        
        
      ],
    },
    {
        title: "AI Platform & Infrastructure",
        items: [
          { label: "Platform Readiness Score", value: 80, type: "progress", },       
          { label: "AI Studio Readiness", value: 70, type: "progress", },        
          
        ],
      },
      {
        title: "AI Delivery & Execution",
        items: [
          { label: "Use cases delivered", value: "10/25", type: "number", },       
          { label: "Delivery Milestone Achievement (%)", value: 60, type: "progress", }, 
          { label: "On Time Delivery Rate (%)", value: 40, type: "progress", },       
          
        ],
      },
      {
        title: "Productvity & Opertaional Efficiency",
        items: [
          { label: "Contact Reduction", value: "120K/200K", type: "number", },       
          { label: "Delivery Milestone Achievement (%)", value: 60, type: "progress", }, 
          { label: "On Time Delivery Rate (%)", value: 40, type: "progress", },       
          
        ],
      },
    // {
    //   title: "AI Infrastructure Progress(Personalization Engine & Data Central)",
    //   items: [
    //     { label: "ROI & Investment Efficiency Progress (%)", value: 82, type: "progress", },
    //     // { label: "Data Readiness", value: 68 },
    //   ],
    // },
  ]; 

  const getProgressColor = (value: number) => {
    if (value < 40) return "#DC2626"; // Red
    if (value <= 70) return "#F59E0B"; // Amber
    return "#16A34A"; // Green
  };
  
  export default function AccelerateSection() {
    return (
      <Box sx={{ width: "100%" }}>
        {/* Header */}
        <Stack direction="row" spacing={0.5} alignItems="center">
          <Typography
            sx={{
              fontSize: "11px",
              fontWeight: 700,
              color: "#0A2E78",
              textTransform: "uppercase",
            }}
          >
            Accelerate
          </Typography>
  
          <Typography
            sx={{
              fontSize: "10px",
              fontWeight: 600,
              color: "#4B5563",
            }}
          >
            {/* (9 / 10 On Track) */}
          </Typography>
        </Stack>
  
        <Divider
          sx={{
            my: 0.5,
            borderBottomWidth: 1.5,
            borderColor: "#0A2E78",
          }}
        />
  
        <Stack spacing={0.75}>
          {data.map((section) => (
            <Card
              key={section.title}
              elevation={0}
              sx={{
                border: "1px solid #E5E7EB",
                borderRadius: 1,
                p: 1,
                width: "100%",
              }}
            >
              {/* Card Header */}
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                mb={0.5}
              >
                <Typography
                  sx={{
                    fontSize: "10px",
                    fontWeight: 700,
                  }}
                >
                  {section.title}
                </Typography>
  
                <Box
                  sx={{
                    width: 7,
                    height: 7,
                    borderRadius: "50%",
                    bgcolor: "#16A34A",
                  }}
                />
              </Stack>
  
              {/* Progress Rows */}
              {section.items.map((item, index) => (
                            <Box
                                key={`${item.label}-${index}`}
                                sx={{
                                    mb: index !== section.items.length - 1 ? 1.5 : 0,
                                }}
                            >
                                {item.type === "number" ? (
                                    <Stack
                                        direction="row"
                                        justifyContent="space-between"
                                        alignItems="center"
                                    >
                                        <Typography
                                            sx={{
                                                fontSize: "9px",
                                                color: "#374151",
                                                fontWeight: 600,
                                            }}
                                        >
                                            {item.label}
                                        </Typography>

                                        <Typography
                                            sx={{
                                                fontSize: "9px",
                                                fontWeight: 600,
                                                // color: "#111827",
                                            }}
                                        >
                                            {item.value}
                                        </Typography>
                                    </Stack>
                                ) : (
                                    <Stack
                                        direction="row"
                                        alignItems="center"
                                        spacing={1}
                                    >
                                        {/* Label */}
                                        <Typography
                                            sx={{
                                                width: "40%",
                                                fontSize: "9px",
                                                fontWeight: 600,
                                                color: "#374151",
                                                lineHeight: 1.2,
                                            }}
                                        >
                                            {item.label}
                                        </Typography>

                                        {/* Progress */}
                                        <LinearProgress
                                            variant="determinate"
                                            value={item.value}
                                            sx={{
                                                flex: 1,
                                                height: 4,
                                                borderRadius: 5,
                                                bgcolor: "#E5E7EB",

                                                "& .MuiLinearProgress-bar": {
                                                    borderRadius: 5,
                                                    bgcolor: getProgressColor(item.value),
                                                },
                                            }}
                                        />

                                        {/* Value */}
                                        <Typography
                                            sx={{
                                                minWidth: 32,
                                                textAlign: "right",
                                                fontSize: "9px",
                                                fontWeight: 600,
                                                // color: getProgressColor(item.value),
                                            }}
                                        >
                                            {item.value}%
                                        </Typography>
                                    </Stack>
                                )}
                            </Box>
                        ))}
            </Card>
          ))}
        </Stack>
      </Box>
    );
  }