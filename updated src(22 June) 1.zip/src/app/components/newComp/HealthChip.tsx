import { Chip } from "@mui/material";

interface HealthChipProps {
  health: "Healthy" | "Watch" | "Risk";
}

export default function HealthChip({
  health,
}: HealthChipProps) {
  const config = {
    Healthy: {
      bg: "#DCFCE7",
      color: "#166534",
    },

    Watch: {
      bg: "#FEF3C7",
      color: "#92400E",
    },

    Risk: {
      bg: "#FEE2E2",
      color: "#991B1B",
    },
  };

  return (
    <Chip
      label={health}
      size="small"
      sx={{
        height: 24,
        fontSize: 11,
        fontWeight: 600,
        bgcolor: config[health].bg,
        color: config[health].color,
      }}
    />
  );
}