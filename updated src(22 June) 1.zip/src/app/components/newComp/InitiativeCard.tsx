import { Card, Chip, Typography, Stack, Box, Tooltip } from "@mui/material";
import WarningIcon from "@mui/icons-material/Warning";
import { Initiative } from "../../data/types";
import CommentIcon from "@mui/icons-material/Comment";
import { useTheme } from "../../theme-context";

const towerColors = {
  Focus: "rgb(26, 115, 232)",
  Accelerate: "rgb(123, 31, 162)",
  Scale: "rgb(0, 151, 167)",
  Transform: "rgb(230, 81, 0)",
};

const towerBorders = {
  Focus: "1px solid rgba(26, 115, 232, 0.25)",
  Accelerate: "1px solid rgba(123, 31, 162, 0.25)",
  Scale: "1px solid rgba(0, 151, 167, 0.25)",
  Transform: "1px solid rgba(230, 81, 0, 0.25)",
};

const towerBGColors = {
  Focus: "rgba(26, 115, 232, 0.082)",
  Accelerate: "rgba(123, 31, 162, 0.082)",
  Scale: "rgba(0, 151, 167, 0.082)",
  Transform: "rgba(230, 81, 0, 0.082)",
};

interface Props {
  initiative: Initiative;
  selectedTowers: [];
}

export default function InitiativeCard({
  initiative,
  selectedStatus,
  selectedTowers,
}: Props) {
  const { theme, toggle } = useTheme();
  const getStatusColor = (status: string) => {
    switch (status) {
      case "On Track":
        return theme.onTrack;
      case "Needs Attention":
        return theme.attention;
      case "Off Track":
        return theme.offTrack;
      default:
        return "#9AA0A6"; // Not Started
    }
  };

 

  const showData = !selectedStatus || initiative.status === selectedStatus;
  const showOnlyFilteredTower = selectedTowers.includes(initiative.towerTeam);
  return (
    <>
      {/* {initiative.hasdata === true && showData && showOnlyFilteredTower ? ( */}
        <Stack
          direction="row"
          sx={{
            minHeight: 50,
            maxHeight: 67, // keep all cards same height
            borderRadius: 1,
            overflow: "hidden",
            border: "1px solid rgba(0, 0, 0, 0.12)",
          }}
        >
          {/* Content */}
          <Box
            sx={{
              flex: 1,
              padding: "4px 8px",
              display: "flex",
              flexDirection: "column",
              justifyContent: "start",
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "start",
                gap: 0.5,
                width: "100%",
              }}
            >
              <Typography
                variant="subtitle2"
                sx={{
                  fontWeight: 600,
                  fontSize: "10px",
                  lineHeight: 1.4,
                  mb: 1.5,
                  color: theme.textPrimary,
                }}
              >
                {initiative.name}
              </Typography>
              {initiative.error === true && (
                <Tooltip
                  title="Immediate attention required"
                  arrow
                  slotProps={{
                    tooltip: {
                      sx: {
                        fontSize: "8px",
                      },
                    },
                  }}
                >
                  <WarningIcon
                    sx={{
                      color: "#ef4444",
                      fontSize: "17px",
                      cursor: "pointer",
                      flexShrink: 0,
                    }}
                  />
                </Tooltip>
              )}
            </Box>

            {/* <Typography
              variant="caption"
              // color="text.primary"
              sx={{
                fontSize: "10px",
                lineHeight: 1.4,
                mb: 0.5,
              }}
            >
              Tower: {initiative?.towerTeam}
            </Typography> */}

            <Box>
              {/* Row 1 */}
              {/* <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                  mb: 1.5,
                }}
              >
                {[
                  { label: "Timeline", value: initiative.timeline, color: initiative.timelineStatus },
                  { label: "Budget", value: initiative.budget, color: initiative.budgetStatus },
                  { label: "Outcome", value: initiative.outcome, color: initiative.outcomeStatus },
                ].map((item) => (
                  <Box
                    key={item.label}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 0.5,
                    }}
                  >
                    <Typography
                      variant="caption"
                      // color="text.secondary"
                      sx={{
                        fontSize: "9px",
                        lineHeight: 1.1,
                        color: theme.textSecondary
                      }}
                    >
                      {item.label}: {item.value}
                    </Typography>

                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: "50%",
                        bgcolor: getStatusColor(item.color),
                      }}
                    />
                  </Box>
                ))}
              </Box> */}

              {/* Row 2 */}
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Typography
                  variant="caption"
                  // color="text.secondary"
                  sx={{
                    fontSize: "9px",
                    lineHeight: 1.1,
                    color: theme.textTertiary
                  }}
                >
                  Leader: {initiative.owner}
                </Typography>

                <CommentIcon sx={{ fontSize: "16px" }} />
              </Box>
            </Box>
            {/* </Box> */}
          </Box>

          {/* Status Border */}
          <Box
            sx={{
              width: 6,
              bgcolor: getStatusColor(initiative.status),
            }}
          />
        </Stack>      
    </>
  );
}
