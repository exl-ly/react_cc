// import { Box, Typography } from "@mui/material";
// import { useParams } from "react-router-dom";

// const TowerDetails = () => {
//   const { towerName } = useParams();

//   return (
//     <Box sx={{ p: 1 }}>
//       <Typography
//         sx={{
//           fontSize: "18px",
//           fontWeight: 600,
//           mb: 1,
//         }}
//       >
//         {towerName?.replace(/-/g, " ")}
//       </Typography>

//       {/* Your common tower UI goes here */}
//     </Box>
//   );
// };

// export default TowerDetails;
import React, { useMemo, useRef, useState } from "react";

import { Search, LayoutGrid, List, RefreshCw } from "lucide-react";

import { ThemeProvider, useTheme } from "./../../theme-context";

import dashboardData from "../../data/dashboardData.json";
import { useNavigate } from "react-router-dom";
import { FastHeader } from "../fast-header";
import { INITIATIVES } from "../../data/initiatives";
import { FastHeaderNew } from "../fast-header-new";
import TransformationHealth from "./TransformationHealth";
import PillarSectionNew from "./PillarSectionNew";
import Footer from "./Footer";
import ChatRoundedIcon from "@mui/icons-material/ChatRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import SendRoundedIcon from "@mui/icons-material/SendRounded";
import {
  Modal,
  Card,
  Box,
  Typography,
  IconButton,
  TextField,
  Button,
  Avatar,
  Stack,
  Tooltip,
} from "@mui/material";

const TowerDetails = () => {
  const data = dashboardData;
  const navigate = useNavigate();
  const { theme } = useTheme();
  const isLight = theme.mode === "light";

  const [activeLeader, setActiveLeader] = useState<string | null>(null);
  const [activePillar, setActivePillar] = useState<string | null>(null);
  const [activeStatus, setActiveStatus] = useState<string | null>(null);
  const [activeTower, setActiveTower] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grouped" | "flat">("grouped");
  //   const [showCockpitView, setShowCockpitView] = useState(false);
  const [hover, setHover] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const bottomRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const filtered = useMemo(
    () =>
      INITIATIVES.filter((i) => {
        if (activeLeader && i.leader !== activeLeader) return false;
        if (activePillar && i.pillar !== activePillar) return false;
        if (activeStatus && i.status !== activeStatus) return false;
        if (activeTower && i.tower !== activeTower) return false;
        if (activeCategory && i.category !== activeCategory) return false;
        if (searchQuery) {
          const q = searchQuery.toLowerCase();
          return (
            i.name.toLowerCase().includes(q) ||
            i.id.toLowerCase().includes(q) ||
            i.leader.toLowerCase().includes(q) ||
            i.statusNote.toLowerCase().includes(q)
          );
        }
        return true;
      }),
    [
      activeLeader,
      activePillar,
      activeStatus,
      activeTower,
      activeCategory,
      searchQuery,
    ]
  );

  const toolbarBg = isLight ? "#ffffff" : "#0c1018";

  const buttonStyle = {
    display: isVisible ? "flex" : "none",
    position: "fixed",
    bottom: "60px",
    right: "25px",
    zIndex: 1000,
    cursor: "pointer",
    // Transparent charcoal tint by default, solid black on hover
    backgroundColor: isHovered ? "#000000" : "rgba(0, 0, 0, 0.4)",
    color: "#fff",
    border: "none",
    borderRadius: "40%",
    width: "40px",
    height: "40px",
    fontSize: "20px",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    // Added transition for the transparent effect to smoothly change into black
    transition: "background-color 0.3s ease",
  };

  const [openChat, setOpenChat] = useState(false);

  const chatButtonStyle = {
    position: "fixed",
    bottom: "18px",
    right: "24px",
    width: "30px",
    height: "30px",
    borderRadius: "50%",
    border: "none",
    background:
      "linear-gradient(135deg, rgb(1 47 107 / 83%) 0%, rgb(1 82 184 / 83%) 100%)",
    color: "#fff",
    cursor: "pointer",
    zIndex: 9999,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 10px 30px rgba(79,70,229,0.35)",
    transition: "all .3s ease",
    transform: isHovered ? "scale(1.08)" : "scale(1)",

    animation: isHovered ? "wave 1.5s infinite" : "none",
  };

  const [comment, setComment] = useState("");

  const [comments, setComments] = useState([
    {
      user: "Shiva",
      text: "Need immediate focus on Cloud Migration milestones.",
    },
    {
      user: "Sathish",
      text: "AI adoption metrics should be reviewed weekly.",
    },
  ]);

  const handlePost = () => {
    if (!comment.trim()) return;

    const newComment = {
      user: "You",
      text: comment,
    };

    setComments((prev) => [...prev, newComment]);

    // clear input
    setComment("");
  };
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        background: theme.bg,
        color: theme.textPrimary,
        fontFamily: "var(--font-sans, Roboto, system-ui, sans-serif)",
        overflow: "hidden",
        transition: "background 0.2s, color 0.2s",
      }}
    >
      {/* <Overview /> */}
      {/* <button
        // onClick={onClickHandler}
        // onMouseEnter={() => setHover(true)}
        // onMouseLeave={() => setHover(false)}
        style={{
          color: "inherit",
          background: "rgb(202 201 241)",
          cursor: "pointer",
          transition: "color 0.2s ease",
          boxShadow: "0 1px 3px rgba(60,64,67,0.06)",
        }}
      ></button> */}

      <div>
        <FastHeaderNew
          initiatives={INITIATIVES}
          filteredInitiatives={filtered}
          activePillar={activePillar}
          onPillarFilter={setActivePillar}
          activeStatus={activeStatus}
          onStatusFilter={setActiveStatus}
        />
      </div>

      <Box>
        <TransformationHealth />
      </Box>

      <PillarSectionNew />
      <Footer />

      
    
    </div>
  );
};

export default TowerDetails;
