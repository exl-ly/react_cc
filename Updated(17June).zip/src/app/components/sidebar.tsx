import { useState, type ReactNode } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { LEADERS, INITIATIVES, CATEGORIES } from "../data/initiatives";
import type { Initiative } from "../data/initiatives";
import { useTheme } from "../theme-context";

interface SidebarProps {
  activeLeader: string | null;
  onLeaderChange: (l: string | null) => void;
  activePillar: string | null;
  onPillarChange: (p: string | null) => void;
  activeStatus: string | null;
  onStatusChange: (s: string | null) => void;
  activeTower: string | null;
  onTowerChange: (t: string | null) => void;
  activeCategory: string | null;
  onCategoryChange: (c: string | null) => void;
  filteredInitiatives: Initiative[];
}

const AVATAR_COLORS = [
  "#4285f4",
  "#7b1fa2",
  "#0097a7",
  "#e65100",
  "#1e8e3e",
  "#d93025",
];

const initials = (name: string) =>
  name
    .split(" ")
    .map((n) => n[0])
    .join("");
const avatarColor = (name: string) =>
  AVATAR_COLORS[LEADERS.indexOf(name as any) % AVATAR_COLORS.length];

export function Sidebar({
  activeLeader,
  onLeaderChange,
  activePillar,
  onPillarChange,
  activeStatus,
  onStatusChange,
  activeTower,
  onTowerChange,
  activeCategory,
  onCategoryChange,
  filteredInitiatives,
}: SidebarProps) {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";
  const [hoveredLeader, setHoveredLeader] = useState<string | null>(null);
  const [isLeadersExpanded, setIsLeadersExpanded] = useState(true);
  const [isTowersExpanded, setIsTowersExpanded] = useState(true);
  const [isCategoriesExpanded, setIsCategoriesExpanded] = useState(true);

  const PILLARS = [
    { key: "Fast", color: theme.pillarFast, label: "Focus" },
    { key: "Acceleration", color: theme.pillarAccel, label: "Acceleration" },
    { key: "Scale", color: theme.pillarScale, label: "Scale" },
    { key: "Transform", color: theme.pillarTrans, label: "Transformation" },
  ];

  const STATUSES = [
    { key: "on-track", label: "On Track", color: theme.onTrack },
    { key: "attention", label: "Needs Attention", color: theme.attention },
    { key: "off-track", label: "Off Track", color: theme.offTrack },
  ];

  const TOWERS = [
    { key: "Enterprise Technology", color: "#4285f4" },
    { key: "Product & Dev", color: "#34a853" },
    { key: "Breakthrough Business", color: "#fbbc04" },
    { key: "Cross GPT", color: "#42854f" },
    { key: "AI", color: "#42854f" },
  ];

  const base: React.CSSProperties = {
    width: 232,
    minWidth: 232,
    background: theme.sidebarBg,
    borderRight: `1px solid ${theme.sidebarBorder}`,
    display: "flex",
    flexDirection: "column",
    height: "100%",
    overflowY: "auto",
    scrollbarWidth: "none",
    boxShadow: isLight ? "2px 0 6px rgba(60,64,67,0.06)" : "none",
  };

  const filteredTowers = Object.entries(
    filteredInitiatives.reduce((acc, item) => {
      if (TOWERS.some((tower) => tower.key === item.tower)) {
        acc[item.tower] = (acc[item.tower] || 0) + 1;
      }
      return acc;
    }, {})
  ).map(([tower, count]) => ({
    tower,
    count,
    color: TOWERS.find((item) => item.key === tower)?.color,
  }));  

  const filteredCategories = Object.entries(
    filteredInitiatives.reduce((acc, item) => {
      if (CATEGORIES.includes(item.category)) {
        acc[item.category] = (acc[item.category] || 0) + 1;
      }
      return acc;
    }, {})
  ).map(([category, count]) => ({
    category,
    count,
  }));

  const filteredLeaders = Object.entries(
    filteredInitiatives.reduce((acc, item) => {
      if (LEADERS.includes(item.leader)) {
        acc[item.leader] = (acc[item.leader] || 0) + 1;
      }
      return acc;
    }, {})
  ).map(([leaderName, count]) => ({
    leaderName,
    count,
  }));  

  return (
    <div style={base}>
      <Section
        label="Towers"
        theme={theme}
        collapsible
        isExpanded={isTowersExpanded}
        onToggle={() => setIsTowersExpanded(!isTowersExpanded)}
      >
        <FilterChip
          active={activeTower === null}
          color={theme.textSecondary}
          theme={theme}         
          onClick={() => onTowerChange(null)}
        >
          All Towers
        </FilterChip>
        {isTowersExpanded &&
          filteredTowers.map((t) => (
            <FilterChip
              key={t.tower}
              active={activeTower === t.tower}
              color={theme.textSecondary}
              theme={theme}
              onClick={() =>
                onTowerChange(activeTower === t.tower ? null : t.tower)
              }
            >
              {t.tower}
              <span
                style={{
                  marginLeft: "auto",
                  color: theme.textTertiary,
                  fontSize: 11,
                }}
              >
                {filteredInitiatives.filter((i) => i.tower === t.tower).length}
              </span>
            </FilterChip>
          ))}
      </Section>

      <Divider theme={theme} />

      <Section
        label="Categories"
        theme={theme}
        collapsible
        isExpanded={isCategoriesExpanded}
        onToggle={() => setIsCategoriesExpanded(!isCategoriesExpanded)}
      >
        <FilterChip
          active={activeCategory === null}
          color={theme.textSecondary}
          theme={theme}
          onClick={() => onCategoryChange(null)}
        >
          All Categories
        </FilterChip>
        {isCategoriesExpanded &&
          filteredCategories.map((c) => (
            <FilterChip
              key={c.category}
              active={activeCategory === c.category}
              color={theme.textSecondary}
              theme={theme}
              onClick={() =>
                onCategoryChange(
                  activeCategory === c.category ? null : c.category
                )
              }
            >
              {c.category}
              <span
                style={{
                  marginLeft: "auto",
                  color: theme.textTertiary,
                  fontSize: 11,
                }}
              >
                {
                  filteredInitiatives.filter((i) => i.category === c.category)
                    .length
                }
              </span>
            </FilterChip>
          ))}
      </Section>

      <Divider theme={theme} />

      <Section
        label="Leaders"
        theme={theme}
        collapsible
        isExpanded={isLeadersExpanded}
        onToggle={() => setIsLeadersExpanded(!isLeadersExpanded)}
      >
        <LeaderChip
          active={activeLeader === null}
          onClick={() => onLeaderChange(null)}
          theme={theme}
        >
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              background: isLight ? "#e8eaed" : theme.elevated,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <span
              style={{
                color: theme.textTertiary,
                fontSize: 10,
                fontWeight: 700,
              }}
            >
              ALL
            </span>
          </div>
          <span
            style={{
              color: theme.textSecondary,
              fontSize: 12,
              fontWeight: 500,
            }}
          >
            All Leaders
          </span>
          <span
            style={{
              marginLeft: "auto",
              color: theme.textSecondary,
              fontSize: 11,
              fontWeight: 500,
            }}
          >
            {filteredInitiatives.length}
          </span>
        </LeaderChip>

        {isLeadersExpanded &&
          filteredLeaders.map((item) => {
            const isActive = activeLeader === item.leaderName;
            const stats = {
              count: filteredInitiatives.filter(
                (i) => i.leader === item.leaderName
              ).length,
              onTrack: filteredInitiatives.filter(
                (i) => i.leader === item.leaderName && i.status === "on-track"
              ).length,
              offTrack: filteredInitiatives.filter(
                (i) => i.leader === item.leaderName && i.status === "off-track"
              ).length,
              attention: filteredInitiatives.filter(
                (i) => i.leader === item.leaderName && i.status === "attention"
              ).length,
            };

            return (
              <button
                key={item.leaderName}
                onClick={() =>
                  onLeaderChange(isActive ? null : item.leaderName)
                }
                onMouseEnter={() => setHoveredLeader(item.leaderName)}
                onMouseLeave={() => setHoveredLeader(null)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  width: "100%",
                  padding: "7px 10px",
                  borderRadius: 8,
                  border: "none",
                  cursor: "pointer",                 
                  background:
                  isActive
                    ? "#ffe5e7"
                    : hoveredLeader === item.leaderName
                    ? "#ffe5e7"
                    : "transparent",
                  outline: isActive
                    ? `1px solid ${theme.textSecondary}`
                    : "none",
                  transition: "all 0.15s",
                  textAlign: "left",
                }}
              >
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: "50%",
                    background: avatarColor(item.leaderName),
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#fff",
                    fontSize: 11,
                    fontWeight: 700,
                    flexShrink: 0,
                    letterSpacing: "0.01em",
                  }}
                >
                  {initials(item.leaderName)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      color: isActive ? theme.textPrimary : theme.textSecondary,
                      fontSize: 12,
                      fontWeight: 500,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {item.leaderName}
                  </div>
                  <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
                    {stats.onTrack > 0 && (
                      <span
                        style={{
                          color: theme.onTrack,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.onTrack}↑
                      </span>
                    )}
                    {stats.attention > 0 && (
                      <span
                        style={{
                          color: theme.attention,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.attention}!
                      </span>
                    )}
                    {stats.offTrack > 0 && (
                      <span
                        style={{
                          color: theme.offTrack,
                          fontSize: 9,
                          fontWeight: 600,
                        }}
                      >
                        {stats.offTrack}↓
                      </span>
                    )}
                  </div>
                </div>
                <span
                  style={{
                    color: isActive ? theme.textPrimary : theme.textSecondary,
                    fontSize: 12,
                    fontWeight: 600,
                    flexShrink: 0,
                  }}
                >
                  {stats.count}
                </span>
              </button>
            );
          })}
      </Section>

      <Divider theme={theme} />
    </div>
  );
}

function Section({
  label,
  children,
  theme,
  collapsible,
  isExpanded,
  onToggle,
}: {
  label: string;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
  collapsible?: boolean;
  isExpanded?: boolean;
  onToggle?: () => void;
}) {
  return (
    <div style={{ padding: "12px 8px 8px" }}>
      <div
        onClick={collapsible ? onToggle : undefined}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 4,
          cursor: collapsible ? "pointer" : "default",
          marginBottom: 4,
          padding: "0 4px",
          userSelect: "none",
        }}
      >
        <div
          style={{
            color: theme.textTertiary,
            fontSize: 10,
            fontWeight: 700,
            letterSpacing: "0.1em",
          }}
        >
          {label.toUpperCase()}
        </div>
        {collapsible && (
          <div
            style={{
              color: theme.textTertiary,
              display: "flex",
              alignItems: "center",
            }}
          >
            {isExpanded ? (
              <ChevronDown size={12} color="#d0271d"/>
            ) : (
              <ChevronRight size={12} color="#d0271d"/>
            )}
          </div>
        )}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {children}
      </div>
    </div>
  );
}

function LeaderChip({
  active,
  onClick,
  children,
  theme,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];
}) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        width: "100%",
        padding: "7px 10px",
        borderRadius: 8,
        border: "none",
        cursor: "pointer",
        background: active ? "#ffe5e7" : "transparent",
        outline: active ? `1px solid ${theme.textSecondary}` : "none",
        transition: "all 0.15s",
        textAlign: "left",
      }}
    >
      {children}
    </button>
  );
}

function FilterChip({
  active,
  color,
  onClick,
  children,
  theme,
}: {
  active: boolean;
  color: string;
  onClick: () => void;
  children: ReactNode;
  theme: ReturnType<typeof useTheme>["theme"];  
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        width: "100%",
        padding: "6px 10px",
        borderRadius: 2,
        border: "none",
        cursor: "pointer",
        // background: active ? backgroundColor : "transparent",
        background: active ? "#ffe5e7": hovered ? "#ffe5e7" : "transparent",
        outline: active ? `1px solid ${theme.textSecondary}` : "none",
        color: active ? color : theme.textSecondary,
        fontSize: 12,
        fontWeight: active ? 500 : 400,
        transition: "all 0.15s",
        textAlign: "left",
      }}
    >
      {children}
    </button>
  );
}

function Divider({ theme }: { theme: ReturnType<typeof useTheme>["theme"] }) {
  return (
    <div style={{ height: 1, background: theme.divider, margin: "4px 0" }} />
  );
}
