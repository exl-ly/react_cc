import { Pillar } from "./pillarTypes";

export const pillarData: Pillar[] = [
  {
    id: "fast",
    name: "FOCUS",
    color: "#010035",

    initiatives: [
      {
        id: "fast-1",
        name: "Next Gen - Lyric",
        score: 78,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Next Gen Delivery Progress",
            type: "progress",
            value: 65,
          },

          {
            id: "m2",
            label: "Client NPS",
            type: "score",
            value: 40,
            trend: "(+4 last month)",
          },
         
          {
            id: "m5",
            label: "Customer Count / New Logos",
            type: "score",
            value: 22,
            trend: "(+6 YoY)",
          },

          {
            id: "m6",
            label: "Client Migration Progress",
            type: "progress",
            value: 48,
          },
        ],
      },
      {
        id: "fast-2",
        name: "Next Gen - WFN",
        score: 78,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Next Gen Delivery Progress",
            type: "progress",
            value: 40,
          },

          {
            id: "m2",
            label: "Client NPS",
            type: "score",
            value: 26,
            trend: "(+2 last month)",
          },
         
          {
            id: "m5",
            label: "Customer Count / New Logos",
            type: "score",
            value: 20,
            trend: "(+4 YoY)",
          },

          {
            id: "m6",
            label: "Client Migration Progress",
            type: "progress",
            value: 35,
          },
        ],
      },
      {
        id: "fast-3",
        name: "Next Gen - E-NG",
        score: 78,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Next Gen Delivery Progress",
            type: "progress",
            value: 10,
          },

          {
            id: "m2",
            label: "Client NPS",
            type: "score",
            value: 15,
            trend: "(+1 last month)",
          },
         
          {
            id: "m5",
            label: "Customer Count / New Logos",
            type: "score",
            value: 8,
            trend: "(+3 YoY)",
          },

          {
            id: "m6",
            label: "Client Migration Progress",
            type: "progress",
            value: 15,
          },
        ],
      },

      {
        id: "fast-4",
        name: "Deliver on BU & Functional Priorities (ESI, SBS, HRO, NAS , MAS/CAN, CoSO)",
        score: 71,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Execution Progress",
            type: "progress",
            value: 52,
          },

          {
            id: "m2",
            label: "Strategic Milestones Achieved",
            type: "milestone",
            current: 18,
            target: 25,
          },

          {
            id: "m3",
            label: "BU Health Score",
            type: "score",
            value: 72,
          },
        ],
      },

      {
        id: "fast-5",
        name: "Deliver on BU Priorities (Client 0)",
        score: 64,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Profile Activation Coverage (%)",
            type: "progress",
            value: 67,
          },

          {
            id: "m2",
            label: "Lyric 0 NPS",
            type: "score",
            value: 61,
          },

          {
            id: "m3",
            label: "Adoption & Usage (%)",
            type: "progress",
            value: 55,
          },
        ],
      },

      {
        id: "fast-6",
        name: "Other Key initiatives (PI Acceleration)",
        score: 82,
        health: "On Track",

        metrics: [
          {
            id: "m1",
            label: "Revenue Generated",
            type: "currency",
            current: "$18M",
            target: "$30M",
          },

          {
            id: "m2",
            label: "Market Coverage",
            type: "number",
            value: 76,
          },

          {
            id: "m3",
            label: "Strategic Milestones Achieved",
            type: "milestone",
            current: 12,
            target: 15,
          },
        ],
      },
    ],
  },

  {
    id: "accelerate",
    name: "ACCELERATE",
    color: "#7C3AED",

    initiatives: [
      {
        id: "acc-1",
        name: "AI Foundation",

        score: 81,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "AI Execution Progress % (Execution Progress and Data Central Progress)",
            type: "progress",
            value: 60,
          },
          {
            id: "m2",
            label: "Cost Savings Realization",
            type: "milestone",
            current: "$5M",
            target: "$19M"
          },

          {
            id: "m3",
            label: "Churn Rate Reduction",
            type: "progress",
            value: 35,
          },

          {
            id: "m4",
            label: "Handle Time Reduction",
            type: "currentTarget",
            current: "20 Hours Saved",
            target: "100 Hours",
          },
        ],
      },
      {
        id: "acc-2",
        name: "AI Outcome",

        score: 69,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Revenue Impact Improvement / Revenue Realization",
            type: "currentTarget",
            current: "Gross - $10M Net - $5M",
            target: "Gross - $30M Net - $15M", 
            // type: "number",
            // value: "Gross - 30 Net - 15",
          },
          {
            id: "m2",
            label: "Operational Efficiency Improvement (%)",
            type: "progress",
            value: 60,
          },

          {
            id: "m3",
            label: "Cost Saving",           
            type: "currentTarget",            
            current: "$40M",
            target: "$120M",            
          },         
        ],
      },

      {
        id: "acc-3",
        name: "AI Enablement",

        score: 69,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "AI Tools Access (%)",
            type: "progress",
            value: 58,
          },
          {
            id: "m2",
            label: "AI Tool adoption (%)",
            type: "progress",
            value: 58,
          },

          {
            id: "m3",
            label: "AI Training Coverage Progress (%)",
            type: "progress",
            value: 84,
          },


          // {
          //   id: "m2",
          //   label: "Milestones",
          //   type: "milestone",
          //   current: 14,
          //   target: 22,
          // },

          // {
          //   id: "m3",
          //   label: "Coverage",
          //   type: "progress",
          //   value: 62,
          // },
        ],
      },
      
      {
        id: "acc-4",
        name: "AI Delivery",

        score: 69,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Persona Coverage (%)",
            type: "progress",
            value: 58,
          },
          {
            id: "m2",
            label: "Agent Rollout Progress (%)",
            type: "progress",
            value: 58,
          },

          {
            id: "m3",
            label: "Persona agent adoption rate %",
            type: "progress",
            value: 84,
          },

        ],
      },
      {
        id: "acc-5",
        name: "AI Strategy",

        score: 69,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "AI BU roadmap execution %",
            type: "progress",
            value: 58,
          },
          {
            id: "m2",
            label: "Productivity Benefit %",
            type: "progress",
            value: 58,
          },

          {
            id: "m3",
            label: "White Papers published (Quarter/Year)",
            type: "number",
            value: 10,
          },
        
        ],
      },
      {
        id: "acc-6",
        name: "AI (E+Digital Employee)",

        score: 69,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Digital Employee Deployment (%)",
            type: "progress",
            value: 72,
          },
         
        ],
      },
      {
        id: "acc-7",
        name: "AI NG acceeleration",

        score: 69,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Migration & Implementation Progress (%)",
            type: "progress",
            value: 58,
          },
          {
            id: "m2",
            label: "Productivity & Speed Impact (%)",
            type: "progress",
            value: 58,
          },

          // {
          //   id: "m3",
          //   label: "White Papers published (Quarter/Year)",
          //   type: "number",
          //   value: 84,
          // },
        
        ],
      },
      {
        id: "acc-8",
        name: "TAM Expansion",

        score: 69,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Revenue Generated",
            type: "currency",
            current: "$30M",
            target: "$120M",
          },
          {
            id: "m2",
            label: "New Markets",
            type: "number",
            value: 40,
          },
         
        
        ],
      },
    ],
  },

  {
    id: "scale",
    name: "SCALE",
    color: "#0891B2",

    initiatives: [
      {
        id: "scale-1",
        name: "Breakthrough Revenue",

        score: 84,
        health: "On Track",

        metrics: [
          {
            id: "m1",
            label: "Breakthrough Overall Revenue",
            type: "progressWithTarget",
            value: 43,
            current: "$145M",
            target: "$340M",
          },
          {
            id: "m2",
            label: "Marketplace Revenue Growth",
            type: "currentTarget",
            current: "$45M",
            target: "$110M",
          },
          {
            id: "m3",
            label: "Data solutions Revenue Growth",
            type: "currentTarget",
            current: "$60M",
            target: "$157M",
          },
          {
            id: "m4",
            label: "Ventures Revenue Growth",
            type: "currentTarget",
            current: "$40M",
            target: "$73M",
          },      

        
        ],
      },     
    ],
  },

  {
    id: "transform",
    name: "TRANSFORM",
    color: "#EA580C",

    initiatives: [
      {
        id: "trans-1",
        name: "GPT Global Delivery Model",

        score: 73,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Resource Mix ratio",
            type: "currentTarget",
            current: "94:6",
            target: "90:10",
          },

          {
            id: "m2",
            label: "Geo Mix ratio",           
            type: "currentTarget",
            current: "56:9:35",
            target: "35:25:40",
          },

          {
            id: "m3",
            label: "Microsite exited",
            type: "number",
            value: "8 Sites / 20 Sites"
            // current: "$20M",
            // target: "$40M",  
          },
          {
            id: "m4",
            label: "Cost Realization",
            type: "milestone",
            current: "$20M",
            target: "$70M",            
          }, 
        ],
      },

      {
        id: "trans-2",
        name: "Vendor Management(TESM)",

        score: 67,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Saving Realization",
            type: "milestone",
            current: "$20M",
            target: "$140M",
            // type: "number",
            // value: "$140M",
           
          },

          {
            id: "m2",
            label: "Cost CAGR",
            type: "currentTarget",
            current: "7.8%",
            target: "3.7%",
          },
        ],
      },
      {
        id: "trans-3",
        name: "SDLC/ADLC",

        score: 67,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Saving Realization",
            type: "currentTarget",
            current: "$60M",
            target: "$150M", 
       
          },
          
        ],
      },
      {
        id: "trans-4",
        name: "Collaboration / Associate Experience",

        score: 67,
        health: "Needs Attention",

        metrics: [
          {
            id: "m2",
            label: "NPS Score",
            type: "currentTarget",
            current: "32",
            target: "40+",            
          },
          
        ],
      },
      {
        id: "trans-5",
        name: "Stakeholder Excellence",

        score: 67,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "NPS Score",
            type: "currentTarget",
            current: "32",
            target: "40+", 
          },
          {
            id: "m2",
            label: "Participation rate %",
            type: "progress",
            value: 87,            
          },

          {
            id: "m3",
            label: "Engagement level",
            type: "number",
            value: 83,           
          },
        ],
      },
      {
        id: "trans-6",
        name: "People Excellence (Workforce & Talent Strategy)",

        score: 67,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Internal mobility rate %",
            type: "progress",
            value: 20,            
          },
          {
            id: "m2",
            label: "myVoiceleadership score",
            type: "currentTarget",
            current: "17",
            target: ">= ADP Average", 
            // trend: "(+4 last month)",
          },         
        ],
      },
      {
        id: "trans-7",
        name: "Cloud Migration",

        score: 67,
        health: "Needs Attention",

        metrics: [          
          {
            id: "m1",
            label: "Cloud Migration Progress (%)",
            type: "progress",
            value: 13,            
          },

          {
            id: "m2",
            label: "Migration Adherence (%)",
            type: "progress",
            value: 92,           
          },
          {
            id: "m3",
            label: "Legacy Decommission Summary",
            type: "currentTarget",
            current: "7458",
            target: "41000",                
          },
        ],
      },
      {
        id: "trans-8",
        name: "IAM",

        score: 67,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "IAM Access Management",
            type: "currentTarget",
            current: "1000",
            target: "1920",                    
          },
          {
            id: "m2",
            label: "IAM Governance & IGA Progress (%)",
            type: "progress",
            value: 30,            
          },
          {
            id: "m3",
            label: "Privileged Access Management (PAM)",
            type: "currentTarget",
            current: "20",
            target: "46", 
            // type: "milestone",
            // current: "20",
            // target: "46",
            // trend: "(+4 last month)",
          },          

        ],
      },
      {
        id: "trans-9",
        name: "Risk and Resiliency",

        score: 67,
        health: "Needs Attention",

        metrics: [
          {
            id: "m1",
            label: "Client availability ",
            type: "progress",
            value: 99.99
            // current: "99.9921%",
            // target: "99.9999%",            
          },
          {
            id: "m2",
            label: "MTTD",
            type: "milestone",
            current: "5.55 YTD",
            target: "<=8.05 YTD(41.40 % YoY improvement)",            
          },
          {
            id: "m3",
            label: "MTTR",
            type: "milestone",
            current: "20.52 YTD",
            target: "<=19.45 YTD(10.21% YoY Improvement)",
          }, 
          {
            id: "m4",
            label: "Critical incident volume",
            type: "score",
            value: "22.5% YOY Reduction",
            // trend: "(+4 last month)",
          },           

        ],
      },
    ],
  },
];