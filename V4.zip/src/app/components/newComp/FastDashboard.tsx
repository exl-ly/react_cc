import React from "react";
import {
  Box,
  Card,
  Typography,
  Grid,
  Stack,
  Button,
  Chip,
  Divider,
  LinearProgress,
  Avatar,
} from "@mui/material";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";

import {
  CheckCircle,
  Error,
  Warning,
  Description,
  CalendarMonth,
  ChevronRight,
  WorkspacePremium,
  Star,
  Flag,
  GridView,
  Add,
} from "@mui/icons-material";

import RocketLaunchIcon from "@mui/icons-material/RocketLaunch";
import SpeedIcon from "@mui/icons-material/Speed";
import BarChartIcon from "@mui/icons-material/BarChart";
import SyncIcon from "@mui/icons-material/Sync";
import strimp from "../../../images/str-imp.png";

import dashboardData from "../../data/dashboardData.json";
import { useNavigate } from "react-router-dom";

const getIcon = (icon: string, color?: string) => {
  const sx = { color };

  switch (icon) {
    case "check":
      return <CheckCircle sx={sx} />;
    case "error":
      return <Error sx={sx} />;
    case "warning":
      return <Warning sx={sx} />;
    case "description":
      return <Description sx={sx} />;
    case "crown":
      return <WorkspacePremium sx={sx} />;
    case "star":
      return <Star sx={sx} />;
    case "flag":
      return <Flag sx={sx} />;
    case "grid":
      return <GridView sx={sx} />;
    case "add":
      return <Add sx={sx} />;
    default:
      return <CheckCircle sx={sx} />;
  }
};

const pillars = [
  {
    title: "FOCUS",
    value: 75,
    status: "On Track",
    focus: "Deliver on BU & Fuctional Priorities",
    color: "#d0271d",
    icon: <RocketLaunchIcon />,
  },
  {
    title: "ACCELERATE",
    value: 58,
    status: "At Risk",
    focus: "Product Portfolio Impact",
    color: "#d0271d",
    icon: <SpeedIcon />,
  },
  {
    title: "SCALE",
    value: 63,
    status: "On Track",
    focus: "GPT Led Growth Beds",
    color: "#d0271d",
    icon: <BarChartIcon />,
  },
  {
    title: "TRANSFORM",
    value: 40,
    status: "Off Track",
    focus: "GPT Operations & Engagement",
    color: "#d0271d",
    icon: <SyncIcon />,
  },
];

const cardStyle = {
  borderRadius: 3,
  boxShadow: "0 4px 16px rgba(0,0,0,0.06)",
  border: "1px solid #EEF1F5",
};

const green = "#009F78";
const red = "#C50032";
const orange = "#E65A1F";
const blue = "#1D5FD1";

const FastDashboard = () => {
  const data = dashboardData;
  const navigate = useNavigate();
  const getPillarIcon = (iconName) => {
    const icons = {
      people: <RocketLaunchIcon />,
      settings: <RocketLaunchIcon />,
      computer: <RocketLaunchIcon />,
      security: <RocketLaunchIcon />,
      business: <RocketLaunchIcon />,
      assessment: <RocketLaunchIcon />,
      groups: <RocketLaunchIcon />,
    };

    return icons[iconName] || <RocketLaunchIcon />;
  };
  return (
    <Box sx={{ bgcolor: "#F6F8FB", minHeight: "100vh", p: 1 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Box>
          <Typography variant="h4" fontWeight={900} sx={{ fontSize: "20px" }}>
            {data.header.title}
          </Typography>
          <Typography color="text.secondary" fontSize={12}>
            {data.header.subtitle}
          </Typography>
        </Box>

        <Button
          variant="outlined"
          startIcon={<CalendarMonth />}
          sx={{ bgcolor: "#fff", borderRadius: 2, textTransform: "none" }}
        >
          {data.header.dateRange}
        </Button>
      </Stack>

      <Grid container mt={2}>
        <Grid item xs={12} sx={{ width: "-webkit-fill-available" }}>
          <Box
            sx={{
              display: "grid",
              gap: 1,
              width: "100%",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, 1fr)",
                md: "repeat(3, 1fr)",
                lg: "repeat(5, minmax(0, 1fr))",
              },
              alignItems: "stretch",
            }}
          >
            {/* Overall Health Card */}
            <Card
              sx={{
                ...cardStyle,
                p: 1,
                height: "min-content",
                // minHeight: 150,
                boxSizing: "border-box",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
              }}
            >
              <Typography fontWeight={800} fontSize={12}>
                Overall Transformation Health
              </Typography>

              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                mt={1}
              >
                <Box>
                  <Typography fontWeight={900} fontSize={24}>
                    {data.overallHealth.percentage}%
                  </Typography>

                  <Typography color={orange} fontWeight={800} fontSize={10}>
                    {data.overallHealth.status}
                  </Typography>
                </Box>

                <Typography color={red} fontWeight={700} fontSize={10}>
                  ↓ {Math.abs(data.overallHealth.change)}%
                  <br />
                  vs last month
                </Typography>
              </Stack>

              <LinearProgress
                variant="determinate"
                value={data.overallHealth.percentage}
                sx={{
                  height: 8,
                  borderRadius: 10,
                  bgcolor: "#E8EDF3",
                  "& .MuiLinearProgress-bar": {
                    bgcolor: green,
                  },
                }}
              />
            </Card>

            {data.summaryCards.map((card) => (
              <Card
                key={card.title}
                sx={{
                  ...cardStyle,
                  p: 1,
                  height: "min-content",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                }}
              >
                <Stack direction="row" spacing={1} alignItems="center">
                  {getIcon(card.icon, card.color)}

                  <Typography
                    fontWeight={800}
                    fontSize={12}
                    sx={{
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      display: "-webkit-box",
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: "vertical",
                    }}
                  >
                    {card.title}
                  </Typography>
                </Stack>

                <Typography
                  fontWeight={900}
                  fontSize={24}
                  sx={{ marginTop: "12px" }}
                >
                  {card.value}
                </Typography>

                <Typography
                  fontWeight={700}
                  fontSize={10}
                  sx={{ color: card.color }}
                >
                  {card.subtitle}
                </Typography>
              </Card>
            ))}
          </Box>
        </Grid>
      </Grid>
      <Box
        sx={{
          display: "grid",
          gap: 2,
          width: "100%",
          gridTemplateColumns: {
            xs: "1fr", // Mobile
            md: "2fr 1fr", // Two equal columns
          },
          alignItems: "stretch",
          mt: "10px",
        }}
      >
        <Card sx={{ ...cardStyle, p: 2 }}>
          <Typography fontWeight={900} mb={3} sx={{ fontSize: "12px" }}>
            PILLAR HEALTH SNAPSHOT
          </Typography>

          <Box
            sx={{
              display: "grid",
              width: "100%",
              gap: 2,
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, minmax(0, 1fr))",
                md: "repeat(2, minmax(0, 1fr))",
                lg: "repeat(4, minmax(0, 1fr))",
              },
              alignItems: "stretch",
            }}
          >
            {data.pillars.map((pillar) => (
              <Card
                key={pillar.name}
                sx={{
                  p: 2,
                  height: "100%",
                  minHeight: 220,
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  boxShadow: "none",
                  border: "1px solid #E5E7EB",
                  borderRadius: 2,
                }}
              >
                <Avatar
                  sx={{
                    bgcolor: pillar.color,
                    width: 48,
                    height: 48,
                    mb: 1,
                  }}
                >
                  {getPillarIcon(pillar.icon)}
                </Avatar>

                <Typography fontWeight={900} fontSize={12}>
                  {pillar.name}
                </Typography>

                <Typography
                  variant="h4"
                  fontWeight={900}
                  mt={1}
                  sx={{ fontSize: "20px" }}
                >
                  {pillar.percentage}%
                </Typography>

                <Typography
                  sx={{ color: pillar.color }}
                  fontWeight={800}
                  fontSize={10}
                >
                  ● {pillar.status}
                </Typography>

                <Box
                  sx={{
                    height: 30,
                    borderBottom: `3px solid ${pillar.color}`,
                    opacity: 0.75,
                    my: 1,
                  }}
                />

                <Stack direction="column" spacing={0.5}>
                  <Typography fontSize={12} fontWeight={700}>
                    {pillar.initiatives} initiatives
                  </Typography>

                  <Typography fontSize={12} color={red} fontWeight={700}>
                    {pillar.risks} Risk
                  </Typography>
                </Stack>
              </Card>
            ))}
          </Box>
        </Card>

        <Card sx={{ ...cardStyle, p: 2 }}>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            mb={2}
          >
            <Typography fontWeight={900} sx={{ fontSize: "12px" }}>
              IMMEDIATE ATTENTION REQUIRED
            </Typography>

            <Typography
              color={blue}
              fontWeight={800}
              fontSize={14}
              sx={{ cursor: "pointer" }}
            >
              View all risks
            </Typography>
          </Stack>

          {data.attentionRequired.map((item, index) => (
            <Box key={item.title}>
              <Stack direction="row" alignItems="center" spacing={2} py={1.5}>
                <Error sx={{ color: red }} />

                <Box flex={1} minWidth={0}>
                  <Typography fontWeight={900} sx={{ fontSize: "12px" }}>
                    {item.title}
                  </Typography>

                  <Typography color="text.secondary" fontSize={10}>
                    {item.subtitle}
                  </Typography>
                </Box>

                <Chip
                  label={item.status}
                  size="small"
                  sx={{
                    color: red,
                    bgcolor: "#FFF0F4",
                    fontWeight: 800,
                  }}
                />

                <ChevronRight />
              </Stack>

              {index < data.attentionRequired.length - 1 && <Divider />}
            </Box>
          ))}
        </Card>
      </Box>

      <Box
        sx={{
          display: "grid",
          gap: 2,
          mt: 2,
          gridTemplateColumns: {
            xs: "1fr",
            lg: "2fr 1fr",
          },
        }}
      >
        <Card sx={{ ...cardStyle, p: 3 }}>
          <Typography fontWeight={900} mb={3} sx={{ fontSize: "12px" }}>
            INITIATIVES BY PRIORITY
          </Typography>

          <Grid item xs={12} sm={4}>
            {/* <Box>
                  <Box sx={{ color: blue }}>{getIcon(priority.icon, blue)}</Box>

                  <Typography fontWeight={900} sx={{ fontSize: "12px" }}>
                    {priority.title}
                  </Typography>

                  <Typography
                    color={blue}
                    fontWeight={700}
                    sx={{ fontSize: "10px" }}
                  >
                    {priority.level}
                  </Typography>

                  <Typography
                    variant="h4"
                    fontWeight={900}
                    mt={2}
                    sx={{ fontSize: "12px" }}
                  >
                    {priority.count}
                  </Typography>

                  <Typography color="text.secondary" fontSize={12}>
                    initiatives
                  </Typography>

                  <Stack
                    direction="row"
                    spacing={2}
                    mt={2}
                    sx={{ fontSize: "10px" }}
                  >
                    <Typography
                      color={green}
                      fontWeight={800}
                      sx={{ fontSize: "10px" }}
                    >
                      ● {priority.onTrack}
                    </Typography>
                    <Typography
                      color={red}
                      fontWeight={800}
                      sx={{ fontSize: "10px" }}
                    >
                      ● {priority.atRisk}
                    </Typography>
                    <Typography
                      color={orange}
                      fontWeight={800}
                      sx={{ fontSize: "10px" }}
                    >
                      ● {priority.offTrack}
                    </Typography>
                  </Stack>
                </Box> */}
            <img src={strimp} alt="str-imp" />
          </Grid>

          {/* <Typography color={blue} fontWeight={800} mt={3} textAlign="center">
            View all priorities <ChevronRight fontSize="small" />
          </Typography> */}
        </Card>

        <Card sx={{ ...cardStyle, p: 3, height: "100%" }}>
          <Typography fontWeight={900} mb={2} sx={{ fontSize: "12px" }}>
            RECENT UPDATES
          </Typography>

          {data.recentUpdates.map((update) => (
            <Stack direction="row" spacing={1.5} mb={2} key={update.title}>
              <Typography sx={{ color: update.color, fontSize: "12px" }}>
                ●
              </Typography>

              <Box flex={1}>
                <Typography fontWeight={900} fontSize={12}>
                  {update.title}
                </Typography>
                <Typography fontSize={12} color="text.secondary">
                  {update.description}
                </Typography>
              </Box>

              <Typography fontSize={12} color="text.secondary">
                {update.time}
              </Typography>
            </Stack>
          ))}
        </Card>
      </Box>

      <Card sx={{ ...cardStyle, mt: 2, p: 2 }}>
        <Stack direction="row" alignItems="center" spacing={2}>
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: 2,
              bgcolor: "#EEF4FF",
              color: blue,
              display: "grid",
              placeItems: "center",
            }}
          >
            <GridView />
          </Box>

          <Box flex={1}>
            <Typography fontWeight={900}>
              Explore the full strategic portfolio
            </Typography>
            <Typography color="text.secondary" fontSize={13}>
              Dive deeper into initiatives across all towers.
            </Typography>
          </Box>

          <Button
            variant="contained"
            endIcon={<ArrowForwardRoundedIcon />}
            onClick={() => navigate("/cockpit-view")}
            sx={{
              textTransform: "none",
              borderRadius: 1.5,
              px: 3,
              py: 0.5,
              fontWeight: 600,
              bgcolor: "#d0271d",
              "&:hover": {
                bgcolor: "#f90e00",
              },
            }}
          >
            Open Detailed View →
          </Button>
        </Stack>
      </Card>
    </Box>
  );
};

export default FastDashboard;
