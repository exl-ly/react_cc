export const initiativeData = {
    initiative: "GPT Global Delivery Model",
    status: "On Track",
    owner: "AI Transformation Office",
    healthScore: 78,
    startDate: "Jan 2026",
    targetDate: "Dec 2026",
    updatedDate: "16 Jun 2026",
  
    executiveSummary:
      "GPT Global Delivery Model initiative focuses on optimizing workforce distribution, reducing delivery costs, improving operational efficiency, and achieving strategic delivery transformation goals across regions.",
  
    quote:
      "We are on track to deliver significant cost savings through strategic resource mix optimization, geographic realignment and operational consolidation.",
  };
  
  export const summaryCards = [
    {
      title: "Total Savings Opportunity",
      value: "$40M",
      subtitle: "Potential by FY29",
    },
    {
      title: "Overall Execution Progress",
      value: "68%",
      subtitle: "Current Progress",
    },
    {
      title: "Resource Mix Progress",
      value: "62%",
      subtitle: "Target 85%",
    },
    {
      title: "Geo Mix Progress",
      value: "58%",
      subtitle: "Target 35/25/40",
    },
    {
      title: "Microsite Reduction",
      value: "70%",
      subtitle: "Target 0 Sites",
    },
  ];