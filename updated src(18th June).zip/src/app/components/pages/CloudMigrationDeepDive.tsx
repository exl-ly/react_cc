import React from "react";
import {
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Chip,
  Divider,
  Grid,
  LinearProgress,
  Stack,
  Typography,
  Paper,
  CardContent,
} from "@mui/material";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    CartesianGrid,
    BarChart,
    Bar,
    Legend,
  } from "recharts";

import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import CloudOutlinedIcon from "@mui/icons-material/CloudOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import FlagOutlinedIcon from "@mui/icons-material/FlagOutlined";
import MonitorHeartOutlinedIcon from "@mui/icons-material/MonitorHeartOutlined";

import AppsOutlinedIcon from "@mui/icons-material/AppsOutlined";
import CloudDoneOutlinedIcon from "@mui/icons-material/CloudDoneOutlined";
import ApartmentOutlinedIcon from "@mui/icons-material/ApartmentOutlined";
import CheckCircleOutlineOutlinedIcon from "@mui/icons-material/CheckCircleOutlineOutlined";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";

const kpis = [
  {
    title: "Total Applications",
    value: "1,094",
    subtitle: "Across 18 DCs",
    color: "#0A2E78",
    icon: <AppsOutlinedIcon />,
  },
  {
    title: "Applications Migrated",
    value: "280",
    subtitle: "26% of total",
    color: "#0A9B4B",
    icon: <CloudDoneOutlinedIcon />,
  },
  {
    title: "Active Data Centers",
    value: "18",
    subtitle: "On Track",
    color: "#0A2E78",
    icon: <ApartmentOutlinedIcon />,
  },
  {
    title: "Overall Migration Completion",
    value: "16%",
    subtitle: "Achieved by June 2026",
    color: "#0A2E78",
    icon: <CheckCircleOutlineOutlinedIcon />,
  },
];

const labelStyle = {
  fontSize: "12px",
  fontWeight: 500,
  color: "#0A2E78",
};

const valueStyle = {
  fontSize: "42px",
  fontWeight: 700,
  color: "#0A2E78",
};

const migrationProgressData = [
    { month: "Q1", planned: 20, actual: 16 },
    { month: "Q2", planned: 35, actual: 28 },
    { month: "Q3", planned: 50, actual: 42 },
    { month: "Q4", planned: 70, actual: 60 },
    { month: "Q5", planned: 90, actual: 80 },
  ];
  
  const buData = [
    {
      name: "Commercial",
      completed: 70,
      inProgress: 20,
      pending: 10,
    },
    {
      name: "Consumer",
      completed: 55,
      inProgress: 25,
      pending: 20,
    },
    {
      name: "Finance",
      completed: 40,
      inProgress: 30,
      pending: 30,
    },
    {
      name: "Operations",
      completed: 65,
      inProgress: 20,
      pending: 15,
    },
  ];
  const buRows = [
    {
      bu: "GETS",
      total: 500,
      red: 90,
      purple: 40,
      green: 50,
      gray: 90,
      blue: 20,
      pct: "14%",
    },
    {
      bu: "ESI",
      total: 210,
      red: 25,
      purple: 20,
      green: 40,
      gray: 70,
      blue: 25,
      pct: "19%",
    },
    {
      bu: "Nationals",
      total: 80,
      red: 40,
      purple: 10,
      green: 15,
      gray: 15,
      blue: 0,
      pct: "13%",
    },
    {
      bu: "Major & Canada",
      total: 70,
      red: 35,
      purple: 10,
      green: 10,
      gray: 15,
      blue: 0,
      pct: "21%",
    },
    {
      bu: "SR/MRFS",
      total: 60,
      red: 25,
      purple: 10,
      green: 5,
      gray: 10,
      blue: 10,
      pct: "8%",
    },
  ];
  const milestones = [
    {
      milestone: "Initial Application Migration",
      target: "Jun 2026",
      status: "Completed",
    },
    {
      milestone: "Migration Pipeline Established",
      target: "Jun 2026",
      status: "Completed",
    },
    {
      milestone: "Migration Factory Setup",
      target: "Dec 2026",
      status: "In Progress",
    },
    {
      milestone: "Regional Migration Model",
      target: "Jan 2027",
      status: "Planned",
    },
    {
      milestone: "FinOps Implementation",
      target: "Sep 2027",
      status: "Planned",
    },
  ];
  
  const risks = [
    {
      risk: "Legacy application dependencies",
      impact: "High",
      status: "Red",
      mitigation: "Dependency mapping & refactor plan",
    },
    {
      risk: "Application readiness delays",
      impact: "Medium",
      status: "Amber",
      mitigation: "Accelerated assessment",
    },
    {
      risk: "Resource constraints in BU teams",
      impact: "Medium",
      status: "Amber",
      mitigation: "Additional teams & capacity",
    },
    {
      risk: "Data migration complexity",
      impact: "Medium",
      status: "Green",
      mitigation: "Automation tooling",
    },
  ];
  const documents = [
    {
      icon: "📊",
      title: "Cloud Migration\nStrategy (PPT)",
    },
    {
      icon: "📗",
      title: "Application Inventory\n(XLSX)",
    },
    {
      icon: "📈",
      title: "Migration Factory\nDashboard",
    },
    {
      icon: "📘",
      title: "FinOps Assessment\n(DOCX)",
    },
    {
      icon: "📕",
      title: "Architecture Review\n(PDF)",
    },
    {
      icon: "🟢",
      title: "Steering Committee\nNotes",
    },
    {
      icon: "📄",
      title: "RAID Log",
    },
  ];

export default function CloudMigrationDeepDive() {
  return (
    <Box
    sx={{
        width: "100%",
        bgcolor: "#F5F7FB",
        px: 1.5,
        py: 1,
      }}
    >
      {/* ================================= */}
      {/* BREADCRUMB */}
      {/* ================================= */}

      <Breadcrumbs
        separator={<NavigateNextIcon fontSize="small" />}
        sx={{
          mb: 1,
          fontSize: 13,
        }}
      >
        <Typography
          sx={{
            fontSize: 13,
            fontWeight: 600,
            color: "#0A2E78",
          }}
        >
          Initiatives
        </Typography>

        <Typography
          sx={{
            fontSize: 13,
            fontWeight: 600,
            color: "#0A2E78",
          }}
        >
          Cloud Migration
        </Typography>

        <Typography
          sx={{
            fontSize: 13,
            fontWeight: 700,
            color: "#0A2E78",
          }}
        >
          Deep Dive
        </Typography>
      </Breadcrumbs>

      {/* ================================= */}
      {/* HEADER */}
          {/* ================================= */}
          <Card
  elevation={0}
  sx={{
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    px: 1.5,
    py: 0.75,
    mb: 1,
  }}
>
  <Grid container alignItems="center">
    <Grid size={{ xs: 12, md: 8 }}>
      <Stack direction="row" spacing={1.5} alignItems="center">
        <Avatar
          sx={{
            width: 32,
            height: 32,
            bgcolor: "#0A2E78",
          }}
        >
          <CloudOutlinedIcon sx={{ fontSize: 18 }} />
        </Avatar>

        <Box>
          <Stack direction="row" spacing={1} alignItems="center">
            <Typography
              sx={{
                fontSize: 16,
                fontWeight: 700,
                color: "#0A2E78",
                lineHeight: 1,
              }}
            >
              Cloud Migration
            </Typography>

            <Chip
              label=""
              size="small"
              sx={{
                bgcolor: "#F4A622",
                color: "#000",
                fontWeight: 700,
                height: 22,
                width: 22,
                fontSize: 10,
              }}
            />
          </Stack>

          <Typography
            sx={{
              fontSize: 10,
              mt: 0.25,
              color: "#475569",
              lineHeight: 1.3,
              maxWidth: "90%",
            }}
          >
            Migrating applications, infrastructure and data from legacy
            data centers to cloud to improve scalability, reduce costs and
            enhance performance.
          </Typography>
        </Box>
      </Stack>
    </Grid>

    <Grid size={{ xs: 12, md: 4 }}>
      <Stack
        direction="row"
        spacing={1}
        justifyContent="flex-end"
        alignItems="center"
      >
        <Typography
          sx={{
            fontSize: 11,
            fontWeight: 600,
            color: "#0A2E78",
          }}
        >
          Last Updated: 16 May 2026
        </Typography>

        <Button
          variant="outlined"
          startIcon={<ShareOutlinedIcon sx={{ fontSize: 14 }} />}
          size="small"
          sx={{
            minWidth: 75,
            height: 28,
            fontSize: 11,
            textTransform: "none",
            px: 1,
          }}
        >
          Share
        </Button>

        <Button
          variant="outlined"
          startIcon={<DownloadOutlinedIcon sx={{ fontSize: 14 }} />}
          size="small"
          sx={{
            minWidth: 80,
            height: 28,
            fontSize: 11,
            textTransform: "none",
            px: 1,
          }}
        >
          Export
        </Button>
      </Stack>
    </Grid>
  </Grid>
</Card>

      {/* ================================= */}
      {/* SUMMARY CARD */}
      {/* ================================= */}

          <Card
              elevation={0}
              sx={{
                  border: "1px solid #E2E8F0",
                  borderRadius: 1.5,
                  px: 1.5,
                  //    py: 1,
                  mb: 1,

              }}
          >
              <Grid
                  container
                  wrap="nowrap"
                  alignItems="center"
                  sx={{
                      minHeight: 70,
                      columnGap: 1,
                      width: "100%",
                  }}
              >
                  {/* Initiative Owner */}
                  <Grid
                      size={{ xs: 12 }}
                      sx={{
                          flex: 1.2,
                          minWidth: 0,
                      }}
                  >
                      <Stack spacing={0.25}>
                          <Stack direction="row" spacing={0.5} alignItems="center">
                              <PersonOutlineIcon color="primary" sx={{ fontSize: 16 }} />
                              <Typography sx={labelStyle}>Initiative Owner</Typography>
                          </Stack>

                          <Typography
                              sx={{
                                  fontSize: 12,
                                  fontWeight: 700,
                              }}
                          >
                              Prakash
                          </Typography>
                      </Stack>
                  </Grid>

                  {/* Pillar */}
                  <Grid
                      size={{ xs: 12 }}
                      sx={{
                          flex: 1,
                          minWidth: 0,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                      }}
                  >
                      <Divider
                          orientation="vertical"
                          flexItem
                          sx={{
                              borderColor: "rgba(0,0,0,0.15)",
                          }}
                      />

                      <Stack spacing={0.25}>
                          <Stack direction="row" spacing={0.5} alignItems="center">
                              <DashboardCustomizeOutlinedIcon
                                  color="primary"
                                  sx={{ fontSize: 16 }}
                              />
                              <Typography sx={labelStyle}>Pillar</Typography>
                          </Stack>

                          <Typography
                              sx={{
                                  fontSize: 12,
                                  fontWeight: 700,
                              }}
                          >
                              Transform
                          </Typography>
                      </Stack>
                  </Grid>

                  {/* Timeline */}
                  <Grid
                      size={{ xs: 12 }}
                      sx={{
                          flex: 1,
                          minWidth: 0,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                      }}
                  >
                      <Divider
                          orientation="vertical"
                          flexItem
                          sx={{
                              borderColor: "rgba(0,0,0,0.15)",
                          }}
                      />

                      <Stack spacing={0.25}>
                          <Stack direction="row" spacing={0.5} alignItems="center">
                              <CalendarMonthOutlinedIcon
                                  color="primary"
                                  sx={{ fontSize: 16 }}
                              />
                              <Typography sx={labelStyle}>Timeline</Typography>
                          </Stack>

                          <Typography
                              sx={{
                                  fontSize: 12,
                                  fontWeight: 700,
                              }}
                          >
                              FY26 - FY29
                          </Typography>

                          <Typography
                              sx={{
                                  fontSize: 10,
                                  color: "text.secondary",
                              }}
                          >
                              (4 Year Program)
                          </Typography>
                      </Stack>
                  </Grid>

                  {/* Current Phase */}
                  <Grid
                      size={{ xs: 12 }}
                      sx={{
                          flex: 1,
                          minWidth: 0,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                      }}
                  >
                      <Divider
                          orientation="vertical"
                          flexItem
                          sx={{
                              borderColor: "rgba(0,0,0,0.15)",
                          }}
                      />

                      <Stack spacing={0.25}>
                          <Stack direction="row" spacing={0.5} alignItems="center">
                              <FlagOutlinedIcon
                                  color="primary"
                                  sx={{ fontSize: 16 }}
                              />
                              <Typography sx={labelStyle}>Current Phase</Typography>
                          </Stack>

                          <Typography
                              sx={{
                                  fontSize: 12,
                                  fontWeight: 700,
                              }}
                          >
                              FY26
                          </Typography>

                          <Typography
                              sx={{
                                  fontSize: 10,
                                  color: "text.secondary",
                              }}
                          >
                              Foundation Phase
                          </Typography>
                      </Stack>
                  </Grid>

                  {/* Health */}
                  <Grid
                      size={{ xs: 12 }}
                      sx={{
                          flex: 0.8,
                          minWidth: 0,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                      }}
                  >
                      <Divider
                          orientation="vertical"
                          flexItem
                          sx={{
                              borderColor: "rgba(0,0,0,0.15)",
                          }}
                      />

                      <Stack spacing={0.25}>
                          <Stack direction="row" spacing={0.5} alignItems="center">
                              <MonitorHeartOutlinedIcon
                                  color="primary"
                                  sx={{ fontSize: 16 }}
                              />
                              <Typography sx={labelStyle}>Overall Health</Typography>
                          </Stack>

                          <Typography
                              sx={{
                                  fontSize: 14,
                                  fontWeight: 700,
                                  color: "#F4A622",
                                  lineHeight: 1,
                              }}
                          >
                              ●
                          </Typography>
                      </Stack>
                  </Grid>

                  {/* Key Takeaway */}
                  <Grid
                      size={{ xs: 12 }}
                      sx={{
                          flex: 3.5,
                          minWidth: 0,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                      }}
                  >
                      <Divider
                          orientation="vertical"
                          flexItem
                          sx={{
                              borderColor: "rgba(0,0,0,0.15)",
                          }}
                      />

                      <Stack spacing={0.25}>
                          <Typography sx={labelStyle}>
                              Key Takeaway
                          </Typography>

                          <Typography
                              sx={{
                                  fontSize: 11,
                                  color: "#383d5a",
                                  lineHeight: 1.25,
                              }}
                          >
                              Program is the Foundation Phase FY26. Migration factories and
                              tooling are established. Application migration is on track,
                              while decommissioning has items at risk.
                          </Typography>
                      </Stack>
                  </Grid>
              </Grid>

          </Card>

      {/* ================================= */}
      {/* KPI ROW */}
      {/* ================================= */}

          <Box
              sx={{
                  display: "grid",
                  gridTemplateColumns: "repeat(5, 1fr)",
                  gap: 1,
                  mt: 1,
              }}
          >
              {kpis.map((item) => (
                  <Card
                      key={item.title}
                      elevation={0}
                      sx={{
                          border: "1px solid #E2E8F0",
                          borderRadius: 1.5,
                          height: 92,
                          px: 1.5,
                          py: 1,
                          display: "flex",
                          flexDirection: "column",
                          justifyContent: "space-between",
                      }}
                  >
                      <Stack direction="row" spacing={1} alignItems="center">
                          <Avatar
                              sx={{
                                  width: 28,
                                  height: 28,
                                  bgcolor: "#F4F7FC",
                                  color: item.color,
                              }}
                          >
                              {item.icon}
                          </Avatar>

                          <Typography
                              sx={{
                                  fontSize: 11,
                                  fontWeight: 600,
                                  lineHeight: 1.2,
                                  color: "#0A2E78",
                              }}
                          >
                              {item.title}
                          </Typography>
                      </Stack>

                      <Typography
                          sx={{
                              fontSize: 22,
                              fontWeight: 700,
                              color: item.color,
                              lineHeight: 1,
                          }}
                      >
                          {item.value}
                      </Typography>

                      <Typography
                          sx={{
                              fontSize: 10,
                              color: "#64748B",
                          }}
                      >
                          {item.subtitle}
                      </Typography>
                  </Card>
              ))}
               <Card
  elevation={0}
  sx={{
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    height: 92,
    px: 1.5,
    py: 1,
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  }}
>
  {/* Header */}
  <Stack direction="row" spacing={1} alignItems="center">
    <Avatar
      sx={{
        width: 28,
        height: 28,
        bgcolor: "#F4F7FC",
        color: "#16A34A",
      }}
    >
      <AccessTimeOutlinedIcon sx={{ fontSize: 16 }} />
    </Avatar>

    <Box>
      <Typography
        sx={{
          fontSize: 11,
          fontWeight: 600,
          lineHeight: 1.2,
          color: "#0A2E78",
        }}
      >
        Migration Adherence
      </Typography>

      <Typography
        sx={{
          fontSize: 9,
          color: "#64748B",
          lineHeight: 1,
        }}
      >
        Planned vs Actual
      </Typography>
    </Box>
  </Stack>

  {/* Planned */}
  <Stack spacing={0.3}>
    <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
    >
      <Typography fontSize={10} color="#64748B">
        Planned
      </Typography>

      <Typography fontSize={10} fontWeight={700}>
        20%
      </Typography>
    </Stack>

    <LinearProgress
      variant="determinate"
      value={20}
      sx={{
        height: 6,
        borderRadius: 10,
      }}
    />
  </Stack>

  {/* Achieved */}
  <Stack spacing={0.3}>
    <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
    >
      <Typography fontSize={10} color="#64748B">
        Achieved
      </Typography>

      <Typography
        fontSize={10}
        fontWeight={700}
        color="#16A34A"
      >
        16%
      </Typography>
    </Stack>

    <LinearProgress
      color="success"
      variant="determinate"
      value={16}
      sx={{
        height: 6,
        borderRadius: 10,
      }}
    />
  </Stack>
</Card>
          </Box>

          {/* Charts */}
          <Box
  sx={{
    display: "grid",
    gridTemplateColumns: "1.1fr 1.15fr 1.25fr",
    gap: 1,
    mt: 1,
  }}
>
<Card
  elevation={0}
  sx={{
    height: 300,
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    p: 1.5,
  }}
>
  <Typography
    sx={{
      fontSize: 12,
      fontWeight: 700,
      color: "#0A2E78",
      mb: 0.5,
    }}
  >
    MIGRATION PROGRESS
    <Typography
      component="span"
      sx={{
        ml: 0.5,
        fontSize: 11,
        fontWeight: 600,
      }}
    >
      (Overall Application %)
    </Typography>
  </Typography>

  <Stack direction="row" spacing={2} mb={1}>
    <Stack direction="row" spacing={0.5}>
      <Box
        sx={{
          width: 20,
          borderTop: "2px dashed #2563EB",
          mt: 1,
        }}
      />
      <Typography fontSize={10}>
        Planned
      </Typography>
    </Stack>

    <Stack direction="row" spacing={0.5}>
      <Box
        sx={{
          width: 20,
          borderTop: "2px solid #16A34A",
          mt: 1,
        }}
      />
      <Typography fontSize={10}>
        Achieved
      </Typography>
    </Stack>
  </Stack>

  <ResponsiveContainer
    width="100%"
    height={220}
  >
    <LineChart data={migrationProgressData}>
      <XAxis
        dataKey="month"
        tick={{ fontSize: 10 }}
      />

      <YAxis
        tick={{ fontSize: 10 }}
        domain={[0, 100]}
      />

      <Tooltip />

      <Line
        type="monotone"
        dataKey="planned"
        stroke="#2563EB"
        strokeWidth={2}
      />

      <Line
        type="monotone"
        dataKey="actual"
        stroke="#16A34A"
        strokeWidth={2}
      />
    </LineChart>
  </ResponsiveContainer>
</Card>
<Card
  elevation={0}
  sx={{
    height: 300,
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    p: 1.5,
  }}
>
  <Typography
    sx={{
      fontSize: 12,
      fontWeight: 700,
      color: "#0A2E78",
      mb: 1,
    }}
  >
    MIGRATION BY BU
    <Typography
      component="span"
      sx={{
        ml: 0.5,
        fontSize: 11,
      }}
    >
      (# of Applications)
    </Typography>
  </Typography>

  <Box
    sx={{
      display: "grid",
      gridTemplateColumns: "95px 55px 1fr 50px",
      rowGap: 0.75,
      alignItems: "center",
    }}
  >
    <Typography fontSize={10} fontWeight={700}>
      BU
    </Typography>

    <Typography fontSize={10} fontWeight={700}>
      Total
    </Typography>

    <Typography fontSize={10} fontWeight={700}>
      Status
    </Typography>

    <Typography fontSize={10} fontWeight={700}>
      %
    </Typography>

    {buRows.map((row) => (
      <React.Fragment key={row.bu}>
        <Typography fontSize={10}>
          {row.bu}
        </Typography>

        <Typography fontSize={10}>
          {row.total}
        </Typography>

        <Stack
          direction="row"
          sx={{
            height: 18,
            borderRadius: 0.5,
            overflow: "hidden",
          }}
        >
          <Box
            sx={{
              width: row.red,
              bgcolor: "#DC2626",
            }}
          />

          <Box
            sx={{
              width: row.purple,
              bgcolor: "#7C3AED",
            }}
          />

          <Box
            sx={{
              width: row.green,
              bgcolor: "#16A34A",
            }}
          />

          <Box
            sx={{
              width: row.gray,
              bgcolor: "#9CA3AF",
            }}
          />

          <Box
            sx={{
              width: row.blue,
              bgcolor: "#2563EB",
            }}
          />
        </Stack>

        <Typography
          fontSize={10}
          fontWeight={700}
        >
          {row.pct}
        </Typography>
      </React.Fragment>
    ))}
  </Box>
</Card>
<Card
  elevation={0}
  sx={{
    height: 300,
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    p: 1.5,
  }}
>
  <Typography
    sx={{
      fontSize: 12,
      fontWeight: 700,
      color: "#0A2E78",
      mb: 2,
    }}
  >
    DECOMMISSIONING SUMMARY
    <Typography
      component="span"
      sx={{
        ml: 0.5,
        fontSize: 11,
      }}
    >
      (Servers)
    </Typography>
  </Typography>

  <Box
    sx={{
      display: "grid",
      gridTemplateColumns: "110px 1fr 1fr 1fr",
      gap: 1,
    }}
  >
    <Card
      variant="outlined"
      sx={{
        height: 150,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <Typography
        fontSize={11}
        align="center"
      >
        Total Server Inventory
      </Typography>

      <Typography
        sx={{
          fontSize: 34,
          fontWeight: 700,
          color: "#0A2E78",
        }}
      >
        41K
      </Typography>

      <Typography fontSize={11}>
        Total
      </Typography>
    </Card>

    <Card
      variant="outlined"
      sx={{
        height: 72,
        borderColor: "#86EFAC",
      }}
    >
      <CardContent>
        <Typography
          fontSize={28}
          fontWeight={700}
          color="#16A34A"
          align="center"
        >
          2,326
        </Typography>

        <Typography
          fontSize={11}
          align="center"
        >
          Complete
        </Typography>
      </CardContent>
    </Card>

    <Card
      variant="outlined"
      sx={{
        height: 72,
        borderColor: "#93C5FD",
      }}
    >
      <CardContent>
        <Typography
          fontSize={28}
          fontWeight={700}
          color="#2563EB"
          align="center"
        >
          7,458
        </Typography>

        <Typography
          fontSize={11}
          align="center"
        >
          On Track
        </Typography>
      </CardContent>
    </Card>

    <Card
      variant="outlined"
      sx={{
        height: 72,
        borderColor: "#FDBA74",
      }}
    >
      <CardContent>
        <Typography
          fontSize={28}
          fontWeight={700}
          color="#F59E0B"
          align="center"
        >
          1,075
        </Typography>

        <Typography
          fontSize={11}
          align="center"
        >
          At Risk
        </Typography>
      </CardContent>
    </Card>

    <Card
      variant="outlined"
      sx={{
        gridColumn: "2 / span 3",
        height: 58,
        borderColor: "#FCA5A5",
      }}
    >
      <Stack
        direction="row"
        justifyContent="center"
        alignItems="center"
        height="100%"
        spacing={2}
      >
        <Typography
          sx={{
            fontSize: 30,
            fontWeight: 700,
            color: "#DC2626",
          }}
        >
          22
        </Typography>

        <Typography
          fontSize={12}
          fontWeight={600}
        >
          Delayed
        </Typography>
      </Stack>
    </Card>
  </Box>
</Card>
          </Box>
          <Box
              sx={{
                  display: "grid",
                  gridTemplateColumns: "1.1fr 0.85fr 1fr",
                  gap: "10px",
                  mt: 1,
              }}
          >
            <Card
  elevation={0}
  sx={{
    height: 215,
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    p: 0.5,
  }}
>
  <Typography
    sx={{
      fontSize: 12,
      fontWeight: 700,
      color: "#0A2E78",
      mb: 1.5,
    }}
  >
    PROGRAM ROADMAP
  </Typography>

  <Box
    sx={{
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
    //   gap: 2,
      height: "100%",
    }}
  >
    {/* FY26 */}
    <Box>
      <Typography
        sx={{
          color: "#16A34A",
          fontSize: 12,
          fontWeight: 600,
        }}
      >
        FY26
      </Typography>

      <Typography
        sx={{
          color: "#16A34A",
          fontSize: 12,
          fontWeight: 600,
          mb: 1,
        }}
      >
        Foundation Phase
      </Typography>

      <Stack spacing={0.5}>
        {[
          "Initial application migration",
          "Migration pipelines & Tooling",
          "Migration factory established",
          "Regional migration model established",
        ].map((item) => (
          <Typography
            key={item}
            sx={{
              fontSize: 10,
            }}
          >
            ○ {item}
          </Typography>
        ))}
      </Stack>

      <Typography
        sx={{
          mt: 1,
          color: "#16A34A",
          fontSize: 12,
          fontWeight: 700,
        }}
      >
        Status: On Track
      </Typography>
    </Box>

    {/* FY27 */}

    <Box>
      <Typography
        sx={{
          color: "#2563EB",
          fontSize: 12,
          fontWeight: 600,
        }}
      >
        FY27
      </Typography>

      <Typography
        sx={{
          color: "#2563EB",
          fontSize: 12,
          fontWeight: 600,
          mb: 1,
        }}
      >
        Expansion Phase
      </Typography>

      <Stack spacing={0.5}>
        {[
          "Majority applications migrated",
          "DC decommissioning initiated",
          "FinOps implementation",
          "Enhance Performance & scalability",
        ].map((item) => (
          <Typography
            key={item}
            sx={{ fontSize: 10 }}
          >
            ○ {item}
          </Typography>
        ))}
      </Stack>

      <Typography
        sx={{
          mt: 1,
          color: "#2563EB",
          fontSize: 12,
          fontWeight: 700,
        }}
      >
        Status: Planned
      </Typography>
    </Box>

    {/* FY28-29 */}

    <Box>
      <Typography
        sx={{
          color: "#7C3AED",
          fontSize: 12,
          fontWeight: 600,
        }}
      >
        FY28-FY29
      </Typography>

      <Typography
        sx={{
          color: "#7C3AED",
          fontSize: 12,
          fontWeight: 600,
          mb: 1,
        }}
      >
        Maturity Phase
      </Typography>

      <Stack spacing={0.5}>
        {[          
          "Full Data Center Shutdown",
          "Cloud Cost optimization",
          "Standardize operting model",
          "Full migration of application & workloads",
        ].map((item) => (
          <Typography
            key={item}
            sx={{ fontSize: 10 }}
          >
            ○ {item}
          </Typography>
        ))}
      </Stack>

      <Typography
        sx={{
          mt: 1,
          color: "#7C3AED",
          fontSize: 12,
          fontWeight: 700,
        }}
      >
        Status: Future
      </Typography>
    </Box>
  </Box>
</Card>
<Card
  elevation={0}
  sx={{
    height: 215,
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    // p: 1.5,
    p: "5px"
  }}
>
  <Typography
    sx={{
      fontSize: 12,
      fontWeight: 700,
      color: "#0A2E78",
      mt: "8px",
    }}
  >
    MILESTONE TRACKER
  </Typography>

  <Table size="small" sx={{
    "& .MuiTableCell-root": {
      fontSize: "10px",
      color: "#0A2E78",
    //   py: 0.5, // optional: reduce row height
    },
  }}>
    <TableHead>
      <TableRow>
        <TableCell>Milestone</TableCell>
        <TableCell>Target</TableCell>
        <TableCell>Status</TableCell>
      </TableRow>
    </TableHead>

    <TableBody>
      {milestones.map((row) => (
        <TableRow key={row.milestone}>
          <TableCell>{row.milestone}</TableCell>

          <TableCell>{row.target}</TableCell>

          <TableCell>{row.status}</TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
</Card>
<Card
  elevation={0}
  sx={{
    height: 215,
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    p: "5px"
  }}
>
  <Typography
    sx={{
      fontSize: 12,
      fontWeight: 700,
      color: "#0A2E78",
      mt: "8px",
    }}
  >
    RISKS & ISSUES
  </Typography>

  <Table size="small"  sx={{
    "& .MuiTableCell-root": {
      fontSize: "10px",
      color: "#0A2E78",
      py: 0.5, // optional: reduce row height
    },
  }}>
    <TableHead>
      <TableRow>
        <TableCell>Risk / Issue</TableCell>
        <TableCell>Impact</TableCell>
        <TableCell>Status</TableCell>
        <TableCell>Mitigation</TableCell>
      </TableRow>
    </TableHead>

    <TableBody>
      {risks.map((risk) => (
        <TableRow key={risk.risk}>
          <TableCell>{risk.risk}</TableCell>

          <TableCell>{risk.impact}</TableCell>

          <TableCell>{risk.status}</TableCell>

          <TableCell>{risk.mitigation}</TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
</Card>
          </Box>
          <Card
  elevation={0}
  sx={{
    mt: 1,
    border: "1px solid #E2E8F0",
    borderRadius: 1.5,
    p: 1.5,
  }}
>
  <Typography
    sx={{
      fontSize: 12,
      fontWeight: 700,
      color: "#0A2E78",
      mb: 1,
    }}
  >
    KEY DOCUMENTS & LINKS
  </Typography>

  <Box
    sx={{
      display: "grid",
      gridTemplateColumns: "repeat(7, 1fr)",
      gap: 1,
    }}
  >
    {documents.map((doc) => (
      <Card
        key={doc.title}
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1,
        //   height: 82,
          px: 1,
          py: 1,
          cursor: "pointer",

          "&:hover": {
            bgcolor: "#F8FAFC",
          },
        }}
      >
        <Stack
          direction="row"
          spacing={1}
          alignItems="flex-start"
        >
          <Typography
            sx={{
              fontSize: 24,
              lineHeight: 1,
            }}
          >
            {doc.icon}
          </Typography>

          <Box>
            <Typography
              sx={{
                fontSize: 11,
                fontWeight: 500,
                color: "#0A2E78",
                whiteSpace: "pre-line",
                lineHeight: 1.3,
              }}
            >
              {doc.title}
            </Typography>

            <Typography
              sx={{
                fontSize: 10,
                color: "#2563EB",
                mt: 0.5,
                fontWeight: 500,
              }}
            >
              View
            </Typography>
          </Box>
        </Stack>
      </Card>
    ))}
  </Box>
</Card>
    </Box>
  );
}