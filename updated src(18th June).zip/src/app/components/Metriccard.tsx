import { LineChart, Line, ResponsiveContainer } from "recharts";
import { Rocket, Gauge, BarChart3, RefreshCw } from "lucide-react";

interface MetricCardProps {
  title: string;
  percentage: number;
  status: "On Track" | "At Risk" | "Off Track";
  keyFocus: string;
  color: string;
  chartData: number[];
  icon: "rocket" | "gauge" | "chart" | "refresh";
}

const iconMap = {
  rocket: Rocket,
  gauge: Gauge,
  chart: BarChart3,
  refresh: RefreshCw,
};

const statusColors = {
  "On Track": { dot: "#10b981", bg: "#d1fae5" },
  "At Risk": { dot: "red", bg: "#fef3c7" },
  "Off Track": { dot: "rgb(245, 158, 11)", bg: "#f3e8ff" },
};

export function MetricCard({
  title,
  percentage,
  status,
  keyFocus,
  color,
  chartData,
  icon,
}: MetricCardProps) {
  const Icon = iconMap[icon];
  const statusColor = statusColors[status];

  const data = chartData.map((value, index) => ({ value, index }));

  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 min-w-[280px]">
      <div
        className="mb-1"
        style={{ display: "flex", justifyContent: "space-between" }}
      >
        <div className="flex items-center gap-2">
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center`}
            style={{ backgroundColor: color }}
          >
            <Icon className="w-3 h-3 text-white" />
          </div>
          <div>
            <div
              className="text-xs font-semibold uppercase tracking-wider"
              style={{ color }}
            >
              {title}
            </div>
            <div className="text-2xl font-bold mt-1">{percentage}%</div>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-1">
          <div
            className="w-2 h-2 rounded-full"
            style={{ backgroundColor: statusColor.dot }}
          ></div>
          <span className="text-sm font-medium text-gray-700">{status}</span>
        </div>
      </div>

      {/* <div className="h-20 mb-3">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <Line
              type="monotone"
              dataKey="value"
              stroke={color}
              strokeWidth={2}
              dot={{ fill: color, r: 3 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div> */}

      <div className="text-xs text-gray-600">
        <span className="font-semibold" style={{ color }}>
          Key Focus:
        </span>{" "}
        {keyFocus}
      </div>
    </div>
  );
}
