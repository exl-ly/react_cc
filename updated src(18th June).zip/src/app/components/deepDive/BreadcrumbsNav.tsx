import { Breadcrumbs, Link, Typography } from "@mui/material";

const BreadcrumbsNav = () => {
  return (
    <Breadcrumbs
      separator="›"
      sx={{
        mb: 1,
        fontSize: "12px"
       }}
    >
      <Link
        underline="hover"
        color="inherit"
        sx={{ cursor: "pointer" }}
      >
        Dashboard
      </Link>

      <Link
        underline="hover"
        color="inherit"
        sx={{ cursor: "pointer" }}
      >
        Initiatives
      </Link>

      <Typography
        color="text.primary"
        fontWeight={600}
      >
        GPT Global Delivery Model
      </Typography>
    </Breadcrumbs>
  );
};

export default BreadcrumbsNav;