import {
    Grid,
    Paper,
    Typography,
  } from "@mui/material";
  
  import { summaryCards } from "../../data/gptGlobalDeliveryModelMock";
  
  const KpiSummarySection = () => {
    return (
      <Grid
        container
        spacing={2}
        mb={3}
      >
        {summaryCards.map((card) => (
          <Grid
            key={card.title}
            size={{
              xs: 12,
              sm: 6,
              md: 4,
              lg: 2.4,
            }}
          >
            <Paper
              elevation={0}
              sx={{
                p: 1,
                borderRadius: "12px",
                border: "1px solid #E5E7EB",
                height: 100,
              }}
            >
              <Typography
                variant="body2"
                color="text.secondary"
              >
                {card.title}
              </Typography>
  
              <Typography
                sx={{
                  fontSize: "22px",
                  fontWeight: 700
                 }}
                // fontWeight={700}
                mt={1}
              >
                {card.value}
              </Typography>
  
              <Typography
                variant="caption"
                color="text.secondary"
              >
                {card.subtitle}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    );
  };
  
  export default KpiSummarySection;