import {
    Box,
    Chip,
    Paper,
    Stack,
    Typography,
    Button,
  } from "@mui/material";
  
  import DownloadIcon from "@mui/icons-material/Download";
  import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
  
  import { initiativeData } from "../../data/gptGlobalDeliveryModelMock";
  
  const InitiativeHeader = () => {
    return (
      <Paper
        elevation={0}
        sx={{
          p: 1,
          borderRadius: "16px",
          border: "1px solid #E5E7EB",
          mb: 1,
        }}
      >
        <Stack
          direction={{
            xs: "column",
            md: "row",
          }}
          justifyContent="space-between"
          spacing={3}
        >
          <Box>
            <Typography
              sx={{
                fontSize: "22px",
                fontWeight: 700
              }}
            >
              {initiativeData.initiative}
            </Typography>
  
            <Chip
              size="small"
              sx={{
                height: 22,
                fontSize: "11px",
                mb: 1
              }}
            />
  
            <Stack
              direction={{
                xs: "column",
                sm: "row",
                md: "row"
              }}
              spacing={2}
            >
              <Box sx={{ display: "flex", gap: 2}}>
                <Typography
                  fontSize="11px"
                  color="text.secondary"
                >
                  Owner
                </Typography>
  
                <Typography fontWeight={500}
fontSize="13px">
                  {initiativeData.owner}
                </Typography>
              </Box>
  
              <Box>
                <Typography
                 fontSize="11px"
                  color="text.secondary"
                >
                  Health Score
                </Typography>
  
                <Typography fontWeight={500}
fontSize="13px">
                  {initiativeData.healthScore}%
                </Typography>
              </Box>
  
              <Box>
                <Typography
                  fontSize="11px"
                  color="text.secondary"
                >
                  Start Date
                </Typography>
  
                <Typography fontWeight={500}
fontSize="13px">
                  {initiativeData.startDate}
                </Typography>
              </Box>
  
              <Box>
                <Typography
                  fontSize="11px"
                  color="text.secondary"
                >
                  Target Date
                </Typography>
  
                <Typography fontWeight={500}
fontSize="13px">
                  {initiativeData.targetDate}
                </Typography>
              </Box>
            </Stack>
          </Box>
  
          <Stack
            direction="row"
            spacing={2}
            alignItems="flex-start"
          >
            <Button
              startIcon={<DownloadIcon />}
              size="small"
              sx={{
                minWidth: 110,
                height: 32
               }}
            >
              Export Excel
            </Button>
  
            <Button
              startIcon={<PictureAsPdfIcon />}
              size="small"
              sx={{
                minWidth: 110,
                height: 32
               }}
            >
              Export PDF
            </Button>
          </Stack>
        </Stack>
      </Paper>
    );
  };
  
  export default InitiativeHeader;