import {
  Box,
  Typography,
  Paper,
  Switch,
  FormControlLabel,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  OutlinedInput,
  ListItemText,
  SelectChangeEvent,
  Chip,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import IconButton from "@mui/material/IconButton";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import { initiatives, priorities, teams } from "../../data/newData";
import { useTheme } from "../../theme-context";
import {
  initiativesV1,
  prioritiesV1,
  teamsV1,
} from "../../data/newDataTowerView";

import InitiativeCell from "./InitiativeCell";
import { useState, useEffect } from "react";
import InitiativeCellV1 from "./InitiativeCellV1";
import RestartAltIcon from "@mui/icons-material/RestartAlt";

export default function PriorityMatrix() {
  const [isOn, setIsOn] = useState(true);
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState(null);
  const towerOptions = [
    "Product & Development",
    "AI",
    "Breakthrough",
    "Cross GPT",
    "Enterprise Technology",
    "GPT Strat Ops"
  ];
  const [selectedTowers, setSelectedTowers] = useState(towerOptions);

  // const statusItems = [
  //   { label: "On Track", color: "#10B981" },
  //   { label: "Needs Attention", color: "#F59E0B" },
  //   { label: "Off Track", color: "#EF4444" },
  //   { label: "Reset", color: "#9CA3AF" },
  // ];

  const isAllSelected = selectedTowers.length === towerOptions.length;

  const handleClearAll = () => {
    setSelectedTowers(towerOptions); // reset to ALL
  };

  const handleTowerChange = (event) => {
    const value = event.target.value;

    // Select All logic inside dropdown
    if (value.includes("ALL")) {
      setSelectedTowers(isAllSelected ? [] : towerOptions);
      return;
    }

    setSelectedTowers(typeof value === "string" ? value.split(",") : value);
  };

  const handleClear = () => {
    setSelectedTowers(towerOptions); // reset to ALL
  };

  const filteredData = () => {
    return initiatives.filter((x) => (selectedTowers.includes(x.towerTeam) || x.status === selectedStatus ) )
  }

  const getInitiatives = (priorityId: string, teamId: string) => {
    return initiatives.filter(
      (x) => (x.priority === priorityId && x.team === teamId)
    );
  };

  const getInitiativesV1 = (priorityId: string, teamId: string) => {
    return initiativesV1.filter(
      (x) => x.priority === priorityId && x.team === teamId
    );
  };

  // const teamColors = {
  //   Focus: "rgba(26, 115, 232, 0.125)",
  //   Accelerate: "rgba(123, 31, 162, 0.125)",
  //   Scale: "rgba(0, 151, 167, 0.125)",
  //   Transform: "rgba(230, 81, 0, 0.125)",
  // };

  const teamColors = {
    Focus: theme.tableHeaderBg,
    Accelerate: theme.tableHeaderBg,
    Scale: theme.tableHeaderBg,
    Transform: theme.tableHeaderBg,
  };

  const statusBg = {
    "On Track": {
      default: "rgba(30, 142, 62, 0.07)",
      hover: "rgba(30, 142, 62, 0.16)",
      active: "rgba(30, 142, 62, 0.24)",
    },
    "Off Track": {
      default: "rgba(217, 48, 37, 0.07)",
      hover: "rgba(217, 48, 37, 0.15)",
      active: "rgba(217, 48, 37, 0.22)",
    },
    "Needs Attention": {
      default: "rgba(242, 153, 0, 0.07)",
      hover: "rgba(242, 153, 0, 0.16)",
      active: "rgba(242, 153, 0, 0.24)",
    },
    Reset: {
      default: "rgba(107,114,128,0.07)",
      hover: "rgba(107,114,128,0.14)",
      active: "rgba(107,114,128,0.22)",
    },
  };

  const statusItems = [
    { label: "On Track", color: theme.onTrack },
    { label: "Off Track", color: theme.offTrack },
    { label: "Needs Attention", color: theme.attention },
    // { label: "Not Started", color: "#9CA3AF" },
    { label: "Reset", color: "#6B7280" }, // add reset
  ];

  const handleResetFilters = () => {
    setSelectedStatus(null);
    setSelectedTowers(towerOptions);
  };

  return (
    <Box sx={{ maxHeight: 400, overflow: "scroll" }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.8 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography
            fontWeight={700}
            sx={{
              fontSize: "12px",
              marginRight: "60px",
              color: theme.textPrimary,
            }}
          >
            Initiatives By Priority
          </Typography>

          <Box display="flex" alignItems="center" gap={0.5}>
            <Typography
              sx={{
                fontSize: "10px",
                fontWeight: !isOn ? 700 : 400,
                opacity: !isOn ? 1 : 0.5,
                transition: "all 0.2s ease",
                color: "rgb(1 47 107 / 83%)",
              }}
            >
              Progress View
            </Typography>

            <Switch
              checked={isOn}
              onChange={(e) => setIsOn(e.target.checked)}
              size="small"
              sx={{
                transform: "scale(0.75)",
                m: 0,

                "& .MuiSwitch-switchBase.Mui-checked": {
                  color: "rgb(1 47 107 / 83%)",
                },

                "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                  backgroundColor: "rgb(1 47 107 / 33%)",
                  opacity: 1,
                },
              }}
            />

            <Typography
              sx={{
                fontSize: "10px",
                fontWeight: isOn ? 700 : 400,
                opacity: isOn ? 1 : 0.5,
                color: "rgb(1 47 107 / 83%)",
                transition: "all 0.2s ease",
              }}
            >
              Metrics View
            </Typography>
          </Box>
        </Box>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 2,
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              gap: 0.5,
              alignItems: "center",
            }}
          >
            {/* External Label */}
            <Typography
              sx={{ fontSize: 10, fontWeight: 600, color: theme.textSecondary }}
            >
              Filter By Tower:
            </Typography>

            <FormControl sx={{ width: 260 }} size="small">
              <Box sx={{ position: "relative", width: 260 }}>
                {/* 🔥 Universal Close Icon */}
                {!isAllSelected && (
                  <IconButton
                    size="small"
                    onClick={handleClearAll}
                    sx={{
                      position: "absolute",
                      right: 20,
                      top: "50%",
                      transform: "translateY(-50%)",
                      zIndex: 2,
                    }}
                  >
                    <CloseIcon sx={{ fontSize: 14 }} />
                  </IconButton>
                )}

                <Select
                  multiple
                  open={open}
                  onOpen={() => setOpen(true)}
                  onClose={() => setOpen(false)}                  
                  IconComponent={() => (
                    <KeyboardArrowDownIcon
                      sx={{
                        position: "absolute",
                        right: 8,
                        color: "#d0271d", 
                        transition: "transform 0.3s ease",
                        transform: open ? "rotate(180deg)" : "rotate(0deg)",
                      }}
                    />
                  )}
                  value={selectedTowers}
                  onChange={handleTowerChange}
                  displayEmpty
                  sx={{
                    width: "100%",
                    minHeight: 38,
                    borderRadius: 0,

                    // 🔥 space for close icon
                    pr: 4,
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#010035",
                      borderWidth: "1px",
                    },
                  
                    "&:hover .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#010035",
                    },
                  
                    "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                      borderColor: "#010035",
                      borderWidth: "1px", // prevents MUI's thicker focus border
                    },
                  
                    ...(open && {
                      boxShadow: "0 0 4px 2px #ae2019",
                    }),

                    "& .MuiSelect-select": {
                      display: "flex",
                      flexWrap: "wrap", // 🔥 allow chips wrapping
                      gap: 0.5, // 🔥 spacing between chips
                      alignItems: "center",
                      overflow: "hidden",
                      whiteSpace: "normal",
                      py: 0.6,
                    },
                  }}
                  renderValue={() =>
                    isAllSelected ? (
                      <Typography sx={{ fontSize: 12, color: theme.textPrimary }}>
                        All
                      </Typography>
                    ) : (
                      <Box
                        sx={{
                          display: "flex",
                          flexWrap: "wrap",
                          backgroundColor: "#fff",
                          gap: 0.5, // 🔥 spacing between chips
                        }}
                      >
                        {selectedTowers.map((value) => (
                          <Chip
                            key={value}
                            label={value}
                            size="small"
                            onMouseDown={(e) => e.stopPropagation()}
                            onDelete={() =>
                              setSelectedTowers((prev) =>
                                prev.filter((item) => item !== value)
                              )
                            }
                            sx={{
                              height: 20,
                              fontSize: 10,
                              color: theme.textPrimary
                            }}
                          />
                        ))}
                      </Box>
                    )
                  }
                >
                  {/* Select All */}
                  <MenuItem value="ALL" sx={{
                      "&:hover": {
                        backgroundColor: "#ffe5e7",
                      },
                      "&.Mui-selected": {
                        backgroundColor: "#ffe5e7",
                      },
                      "&.Mui-selected:hover": {
                        backgroundColor: "#ffe5e7",
                      },
                    }}>
                    <Checkbox checked={isAllSelected} sx={{
                        color: theme.tableHeaderBg,
                        "&.Mui-checked": {
                          color: theme.tableHeaderBg,
                        },
                      }} />
                    <ListItemText
                      primary="Select All"
                      primaryTypographyProps={{ fontSize: 10, color: theme.textPrimary }}
                    />
                  </MenuItem>

                  {/* Options */}
                  {towerOptions.map((tower) => (
                    <MenuItem key={tower} value={tower} sx={{
                      "&:hover": {
                        backgroundColor: "#ffe5e7",
                      },
                      "&.Mui-selected": {
                        backgroundColor: "#ffe5e7",
                      },
                      "&.Mui-selected:hover": {
                        backgroundColor: "#ffe5e7",
                      },
                    }}>
                      <Checkbox checked={selectedTowers.includes(tower)} sx={{
                        color: theme.tableHeaderBg,
                        "&.Mui-checked": {
                          color: theme.tableHeaderBg,
                        },
                      }} />
                      <ListItemText
                        primary={tower}
                        primaryTypographyProps={{ fontSize: 10, color: theme.textPrimary }}
                      />
                    </MenuItem>
                  ))}
                </Select>
              </Box>
            </FormControl>
          </Box>
          {statusItems.map((item) => (
            <Box
              key={item.label}
              onClick={() =>
                item.label === "Reset"
                  ? handleResetFilters()
                  : setSelectedStatus(item.label)
              }
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
                cursor: "pointer",
                px: 1.2,
                py: 0.7,
                borderRadius: 2,
                transition: "all 0.2s ease",

                backgroundColor:
                  item.label === "Reset"
                    ? "rgba(107,114,128,0.04)"
                    : selectedStatus === item.label && statusBg[item.label]
                    ? statusBg[item.label].active
                    : statusBg[item.label]?.default || "transparent",

                border:
                  selectedStatus === item.label
                    ? `1px solid ${
                        item.label === "On Track"
                          ? "rgba(16, 185, 129, 0.6)"
                          : item.label === "Needs Attention"
                          ? "rgba(242, 153, 0, 0.6)"
                          : item.label === "Off Track"
                          ? "rgba(217, 48, 37, 0.6)"
                          : "rgba(107,114,128,0.6)"
                      }`
                    : "1px solid transparent",

                "&:hover": {
                  backgroundColor:
                    item.label === "Reset"
                      ? "rgba(107,114,128,0.15)"
                      : selectedStatus === item.label
                      ? statusBg[item.label].active
                      : statusBg[item.label]?.hover || "rgba(0,0,0,0.04)",

                  border:
                    selectedStatus === item.label
                      ? `1px solid ${
                          item.label === "On Track"
                            ? "rgba(16, 185, 129, 0.8)"
                            : item.label === "Needs Attention"
                            ? "rgba(242, 153, 0, 0.8)"
                            : item.label === "Off Track"
                            ? "rgba(217, 48, 37, 0.8)"
                            : "rgba(107,114,128,0.8)"
                        }`
                      : "1px solid transparent",
                },
              }}
            >
              {/* Icon / dot */}
              {item.label === "Reset" ? (
                <RestartAltIcon sx={{ fontSize: 14, color: "#6B7280" }} />
              ) : (
                <Box
                  sx={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    bgcolor: item.color,
                  }}
                />
              )}

              <Typography
                variant="caption"
                sx={{
                  fontSize: 10,
                  fontWeight: selectedStatus === item.label ? 700 : 500,
                }}
              >
                {item.label}
              </Typography>
            </Box>
          ))}
        </Box>
      </Box>

      {!isOn ? (
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "25px repeat(4, 1fr)",
          gap: 1,
        }}
      >
        <Box />

        {/* Team Headers */}
        {teams.map((team) => (
          <Paper
            key={team.id}
            sx={{
              p: 0.2,
              textAlign: "center",
              bgcolor: teamColors[team.name] || "#757575",
              color: "#fff",
              borderRadius: 1,
            }}
          >
            <Typography
              fontWeight={700}
              sx={{
                fontSize: "11px",
                color: "#fff",
                minHeight: "22px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                textAlign: "center",
              }}
            >
              {team.name}
            </Typography>
          </Paper>
        ))}

        {/* Priority Rows */}
        {priorities.map((priority) => (
          <>
            <Box
              key={priority.id}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "end",
                border: "1px solid #ddd",
                background:
                  priority.name === "Priority 1"
                    ? "#333366"
                    : priority.name === "Priority 2"
                    ? "#666699"
                    : "#9999CC",
                color: priority.name === "Priority 3" ? "#fff" : "#fff",
                minHeight: "fit-content",
                writingMode: "vertical-rl",
                transform: "rotate(180deg)",
                width: "fit-content",
                padding: "3px",
                borderRadius: "4px",
              }}
            >
              <Typography fontWeight={700} sx={{ fontSize: "10px" }}>
                {priority.name}
              </Typography>
            </Box>

            {teams.map((team) => (
              <Paper
                key={priority.id + team.id}
                // variant="outlined"
                sx={{
                  minHeight: "fit-content",
                  padding: "5px",
                }}
              >
                <InitiativeCell
                  initiatives={getInitiatives(priority.id, team.id)}
                  selectedStatus={selectedStatus}
                  selectedTowers={selectedTowers}
                />
              </Paper>
            ))}
          </>
        ))}
      </Box>
      ) : (
        <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "25px repeat(4, 1fr)",
          gap: 1,
        }}
      >
        <Box />

        {/* Team Headers */}
        {teams.map((team) => (
          <Paper
            key={team.id}
            sx={{
              p: 0.2,
              textAlign: "center",
              bgcolor: teamColors[team.name] || "#757575",
              color: "#fff",
              borderRadius: 1,
            }}
          >
            <Typography
              fontWeight={700}
              sx={{
                fontSize: "11px",
                color: "#fff",
                minHeight: "22px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                textAlign: "center",
              }}
            >
              {team.name}
            </Typography>
          </Paper>
        ))}

        {/* Priority Rows */}
        {priorities.map((priority) => (
          <>
            <Box
              key={priority.id}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "end",
                border: "1px solid #ddd",
                background:
                  priority.name === "Priority 1"
                    ? "#333366"
                    : priority.name === "Priority 2"
                    ? "#666699"
                    : "#9999CC",
                color: priority.name === "Priority 3" ? "#fff" : "#fff",
                minHeight: "fit-content",
                writingMode: "vertical-rl",
                transform: "rotate(180deg)",
                width: "fit-content",
                padding: "3px",
                borderRadius: "4px",
              }}
            >
              <Typography fontWeight={700} sx={{ fontSize: "10px" }}>
                {priority.name}
              </Typography>
            </Box>

            {teams.map((team) => (
              <Paper
                key={priority.id + team.id}
                // variant="outlined"
                sx={{
                  minHeight: "fit-content",
                  padding: "5px",
                }}
              >
                <InitiativeCellV1
                  initiatives={getInitiatives(priority.id, team.id)}
                  selectedStatus={selectedStatus}
                  selectedTowers={selectedTowers}
                />
              </Paper>
            ))}
          </>
        ))}
      </Box>

      )}
    </Box>
  );
}
