import React, { useMemo, useRef, useState, useEffect } from "react";
import { styled, useTheme } from "@mui/material/styles";
import { useNavigate, useLocation } from "react-router-dom";

import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import CssBaseline from "@mui/material/CssBaseline";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import FastDashboardNew from "./FastDashboardNew";
import TowerDetails from "./TowerDetails";
import { FastHeaderNew } from "../fast-header-new";
import dashboardData from "../../data/dashboardData.json";
import { INITIATIVES } from "../../data/initiatives";
import towersData from "../../data/towerData.json";
import DashboardIcon from "@mui/icons-material/Dashboard"; // Dashboard Icon

import ApartmentIcon from "@mui/icons-material/Apartment";

const drawerWidth = 100;

const Main = styled("main", {
    shouldForwardProp: (prop) => prop !== "open",
})<{ open?: boolean }>(({ theme }) => ({
    flexGrow: 1,
    minWidth: 0,
    overflow: "hidden",

    transition: theme.transitions.create(["width"], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
    }),
}));

const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== "open",
})<{ open?: boolean }>(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,

    transition: theme.transitions.create(["width", "margin"], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),

    ...(open && {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,

        transition: theme.transitions.create(["width", "margin"], {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }),
}));

const DrawerHeader = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    justifyContent: "flex-end",
}));

export default function MainDashboard() {
    const theme = useTheme();
    const [open, setOpen] = React.useState(false);

    const data = dashboardData;
    const navigate = useNavigate();
    const location = useLocation();

    const isDashboardRoute = location.pathname === "/";
    // const { theme } = useTheme();
    //   const isLight = theme.mode === "light";

    const [activeLeader, setActiveLeader] = useState<string | null>(null);
    const [activePillar, setActivePillar] = useState<string | null>(null);
    const [activeStatus, setActiveStatus] = useState<string | null>(null);
    const [activeTower, setActiveTower] = useState<string | null>(null);
    const [activeCategory, setActiveCategory] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [viewMode, setViewMode] = useState<"grouped" | "flat">("grouped");
    //   const [showCockpitView, setShowCockpitView] = useState(false);
    const [hover, setHover] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
    const bottomRef = useRef(null);
    const [isVisible, setIsVisible] = useState(false);
    const [isHovered, setIsHovered] = useState(false);

    const filtered = useMemo(
        () =>
            INITIATIVES.filter((i) => {
                if (activeLeader && i.leader !== activeLeader) return false;
                if (activePillar && i.pillar !== activePillar) return false;
                if (activeStatus && i.status !== activeStatus) return false;
                if (activeTower && i.tower !== activeTower) return false;
                if (activeCategory && i.category !== activeCategory) return false;
                if (searchQuery) {
                    const q = searchQuery.toLowerCase();
                    return (
                        i.name.toLowerCase().includes(q) ||
                        i.id.toLowerCase().includes(q) ||
                        i.leader.toLowerCase().includes(q) ||
                        i.statusNote.toLowerCase().includes(q)
                    );
                }
                return true;
            }),
        [
            activeLeader,
            activePillar,
            activeStatus,
            activeTower,
            activeCategory,
            searchQuery,
        ]
    );

    //   const toolbarBg = isLight ? "#ffffff" : "#0c1018";

    const buttonStyle = {
        display: isVisible ? "flex" : "none",
        position: "fixed",
        bottom: "60px",
        right: "25px",
        zIndex: 1000,
        cursor: "pointer",
        // Transparent charcoal tint by default, solid black on hover
        backgroundColor: isHovered ? "#000000" : "rgba(0, 0, 0, 0.4)",
        color: "#fff",
        border: "none",
        borderRadius: "40%",
        width: "40px",
        height: "40px",
        fontSize: "20px",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
        // Added transition for the transparent effect to smoothly change into black
        transition: "background-color 0.3s ease",
    };

    const [openChat, setOpenChat] = useState(false);
    const [selectedTower, setSelectedTower] = useState(towersData[0]);

    const dashboardItem = towersData.find((item) => item.id === "TWR-000");
    const regularTowers = towersData.filter((item) => item.id !== "TWR-000");

    const chatButtonStyle = {
        position: "fixed",
        bottom: "18px",
        right: "24px",
        width: "30px",
        height: "30px",
        borderRadius: "50%",
        border: "none",
        background:
            "linear-gradient(135deg, rgb(1 47 107 / 83%) 0%, rgb(1 82 184 / 83%) 100%)",
        color: "#fff",
        cursor: "pointer",
        zIndex: 9999,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: "0 10px 30px rgba(79,70,229,0.35)",
        transition: "all .3s ease",
        transform: isHovered ? "scale(1.08)" : "scale(1)",

        animation: isHovered ? "wave 1.5s infinite" : "none",
    };

    const [comment, setComment] = useState("");

    const [comments, setComments] = useState([
        {
            user: "Shiva",
            text: "Need immediate focus on Cloud Migration milestones.",
        },
        {
            user: "Sathish",
            text: "AI adoption metrics should be reviewed weekly.",
        },
    ]);

    const handlePost = () => {
        if (!comment.trim()) return;

        const newComment = {
            user: "You",
            text: comment,
        };

        setComments((prev) => [...prev, newComment]);

        // clear input
        setComment("");
    };

    useEffect(() => {
        if (location.pathname === "/") {
            setSelectedTower(dashboardItem);
            return;
        }

        const towerName = decodeURIComponent(
            location.pathname.slice(1)
        );

        const matchedTower = regularTowers.find(
            (tower) =>
                tower.name.toLowerCase().replace(/\s+/g, "-") === towerName
        );

        if (matchedTower) {
            setSelectedTower(matchedTower);
        }
    }, [location.pathname]);

    const handleDrawerOpen = () => {
        setOpen(true);
    };

    const handleDrawerClose = () => {
        setOpen(false);
    };

    return (
        <>

            {/* <FastHeaderNew
          initiatives={INITIATIVES}
          filteredInitiatives={filtered}
          activePillar={activePillar}
          onPillarFilter={setActivePillar}
          activeStatus={activeStatus}
          onStatusFilter={setActiveStatus}
        /> */}


            <Box sx={{ display: "flex" }}>
                <CssBaseline />

                {/* {!isDashboardRoute && (
  <AppBar position="fixed" open={open}>
    <Toolbar
      sx={{
        backgroundColor: "#ffffff",
        color: "text.primary",
        boxShadow: 1,
      }}
    >
      <IconButton
        color="inherit"
        aria-label="open drawer"
        onClick={handleDrawerOpen}
        edge="start"
        sx={[
          {
            mr: 2,
          },
          open && { display: "none" },
        ]}
      >
        <MenuIcon />
      </IconButton>

      <Box sx={{ flexGrow: 1 }}>
        <FastHeaderNew
          initiatives={INITIATIVES}
          filteredInitiatives={filtered}
          activePillar={activePillar}
          onPillarFilter={setActivePillar}
          activeStatus={activeStatus}
          onStatusFilter={setActiveStatus}
        />
      </Box>
    </Toolbar>
  </AppBar>
)} */}
                <Box
                    sx={{
                        position: "fixed",
                        top: 8,
                        left: 8,
                        zIndex: 2000,
                    }}
                >
                    {!open && (
                        <IconButton
                            onClick={handleDrawerOpen}
                            sx={{
                                backgroundColor: "#fff",
                                boxShadow: 1,
                                "&:hover": {
                                    backgroundColor: "#f5f5f5",
                                },
                            }}
                        >
                            <MenuIcon />
                        </IconButton>
                    )}
                </Box>
                <Box sx={{ display: "flex" }}>
                    <Drawer
                        variant="persistent"
                        open={open}
                        sx={{
                            width: open ? drawerWidth : 0,
                            flexShrink: 0,
                            "& .MuiDrawer-paper": {
                                width: drawerWidth,
                                boxSizing: "border-box",
                            },
                        }}
                    >
                        {/* Compact Header */}
                        <Box
                            sx={{
                                display: "flex",
                                justifyContent: "center",
                                py: 0.5,
                            }}
                        >
                            <IconButton
                                size="small"
                                onClick={handleDrawerClose}
                                sx={{
                                    bgcolor: "#f5f5f5",
                                }}
                            >
                                {theme?.direction === "ltr" ? (
                                    <ChevronLeftIcon fontSize="small" />
                                ) : (
                                    <ChevronRightIcon fontSize="small" />
                                )}
                            </IconButton>
                        </Box>

                        <Divider />

                        {/* Dashboard */}
                        {dashboardItem && (
                            <List dense disablePadding>
                                <ListItem disablePadding>
                                    <ListItemButton
                                        onClick={() => {
                                            setSelectedTower(dashboardItem);
                                            navigate("/");
                                        }}
                                        selected={selectedTower?.id === dashboardItem.id}
                                        sx={{
                                            minHeight: 40,
                                            px: 1,
                                            py: 0.25,
                                        }}
                                    >
                                        <ListItemIcon
                                            sx={{
                                                minWidth: 24,
                                            }}
                                        >
                                            <DashboardIcon sx={{ fontSize: 16 }} />
                                        </ListItemIcon>

                                        <ListItemText
                                            primary={dashboardItem.name}
                                            primaryTypographyProps={{
                                                fontSize: 11,
                                                fontWeight: 600,
                                            }}
                                        />
                                    </ListItemButton>
                                </ListItem>
                            </List>
                        )}

                        <Divider />

                        <Typography
                            sx={{
                                px: 1,
                                py: 1,
                                fontSize: "11px",
                                fontWeight: 700,
                                color: "#1E3A5F",
                                letterSpacing: "0.5px",
                            }}
                        >
                            TOWERS
                        </Typography>

                        <List dense disablePadding>
                            {regularTowers.map((tower) => (
                                <ListItem key={tower.id} disablePadding>
                                    <ListItemButton
                                        onClick={() => {
                                            setSelectedTower(tower);

                                            navigate(
                                                `/${tower.name
                                                    .toLowerCase()
                                                    .replace(/\s+/g, "-")}`
                                            );
                                        }}
                                        selected={selectedTower?.id === tower.id}
                                        sx={{
                                            minHeight: 32,
                                            px: 1,
                                            py: 0.25,
                                        }}
                                    >
                                        <ListItemIcon
                                            sx={{
                                                minWidth: 24,
                                            }}
                                        >
                                            <ApartmentIcon sx={{ fontSize: 14 }} />
                                        </ListItemIcon>

                                        <ListItemText
                                            primary={tower.name}
                                            primaryTypographyProps={{
                                                fontSize: 11,
                                                fontWeight: 500,
                                                lineHeight: 1.1,
                                            }}
                                        />
                                    </ListItemButton>
                                </ListItem>
                            ))}
                        </List>
                    </Drawer>

                    {/* Right Side View */}
                </Box>

                <Main
                    sx={{
                        flexGrow: 1,
                        width: open
                            ? `calc(100% - ${drawerWidth}px)`
                            : "100%",
                    }}
                >
                    <Box
                        sx={{
                            width: "100%",
                            //   height: "100vh",
                            overflow: "auto",
                            p: 0,
                            m: 0,
                        }}
                    >
                        {isDashboardRoute ? (
                            <FastDashboardNew />
                        ) : (
                            <TowerDetails />
                        )}
                    </Box>
                </Main>
            </Box>
        </>
    );
}
