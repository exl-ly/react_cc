import {
  Box,
  Paper,
  Typography,
  Stack,
  Checkbox,
  FormControlLabel,
  Divider,
  Select,
  MenuItem,
  Button,
  Card,
  LinearProgress,
} from "@mui/material";

import { useMemo, useState } from "react";
import { pillarData } from "../../data/pillarData";
import { useTheme } from "../../theme-context";

export default function Dashboard() {
  // ================= LOCAL STATE =================
  const [selectedPriorities, setSelectedPriorities] = useState<string[]>([]);
  const [selectedpillar, setSelectedpillar] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const { theme, toggle } = useTheme();

  // ================= FILTER HANDLERS =================
  const handlePriorityChange = (priority: string) => {
    setSelectedPriorities((prev) =>
      prev.includes(priority)
        ? prev.filter((p) => p !== priority)
        : [...prev, priority]
    );
  };

  const handleReset = () => {
    setSelectedPriorities([]);
    setSelectedpillar("");
    setSelectedStatus("");
  };

  // ================= FILTERED DATA =================
  const filteredpillars = useMemo(() => {
    return pillarData.map((pillar) => ({
      name: pillar.name,
      color: pillar.color,
      initiatives: pillar.initiatives
        .filter((init) =>
          selectedStatus ? init.health === selectedStatus : true
        )
        .map((init) => ({
          title: init.name,
          status: init.health,
          // items: init.initiatives.map((m) => ({
          //   label: m.label,
          //   value: m.value,
          //   progress: m.type === "progress" ? m.value : undefined,
          // })),
        })),
    }));
  }, [selectedpillar, selectedStatus]);

  // ================= PRIORITIES (STATIC EXAMPLE) =================
  const priorities = ["High", "Medium", "Low"];

  const getProgressColor = (value: string) => {
    if (value === "On Track") return "#18B96E";
    if (value === "Needs Attention") return "#f29900";
    return "#d93025";
  };

  const getProgressBgColor = (value: string) => {
    if (value === "On Track") return "rgba(30, 142, 62, 0.09)";
    if (value === "Needs Attention") return "rgba(242, 153, 0, 0.09)";
    return "rgba(217, 48, 37, 0.08)";
  };

  const getProgressBarColor = (value = 0) => {
    if (value >= 75) return "#16A34A";
    if (value >= 50) return "#F59E0B";
    return "#DC2626";
  };

  const teamColors = {
    Focus: theme.tableHeaderBg,
    Accelerate: theme.tableHeaderBg,
    Scale: theme.tableHeaderBg,
    Transform: theme.tableHeaderBg,
  };

  return (
    <Box
      sx={{
        // bgcolor: "#f5f7fb",
        display: "flex",
        overflow: "hidden",
      }}
    >
      {/* ================= LEFT FILTER ================= */}

      {/* ================= RIGHT CONTENT ================= */}
      {/* <Box sx={{ flex: 1, p: 1, overflow: "hidden", bgcolor: "#f5f7fb" }}> */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 1,
          height: "max-content",
        }}
      >
        {pillarData.map((pillar) => (
          //Replaced Card with Box
          <Box
            key={pillar.name}
            sx={
              {
                // border: "1px solid #DCE3EC",
                // borderRadius: 2,
                // bgcolor: "#f5f7fb",
                // height: "max-content",
              }
            }
          >
            {/* <Box sx={{ height: 3, bgcolor: pillar.color }} /> */}

            <Box p={1}>
              <Paper
                sx={{
                  p: 0.5,
                  textAlign: "center",
                  bgcolor: teamColors[pillar.name] || "#757575",
                  color: "#fff",
                  borderRadius: 1,
                  mb: 1.25,
                }}
              >
                <Typography fontWeight={700} sx={{ fontSize: "11px" }}>
                  {pillar.name}
                </Typography>
              </Paper>

              <Stack spacing={1}>
                {pillar.initiatives.map((initiative) => (
                  <Box key={initiative.id}>
                    <Paper
                      sx={{
                        p: 1,
                        border: "1px solid #E4E7EC",
                        bgcolor: "#fff",
                        borderRadius: 1.5,
                        height: "fit-content",
                        background: getProgressBgColor(initiative.health),
                      }}
                    >
                      {/* HEADER */}
                      <Box
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          gap: 1,
                          mb: 1,
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 10,
                            fontWeight: 700,
                            color: "#010035",
                            lineHeight: 1.2,
                            flex: 1,
                          }}
                        >
                          {initiative.name}
                        </Typography>

                        <Box
                          sx={{
                            width: 8,
                            height: 8,
                            borderRadius: "50%",
                            flexShrink: 0,
                            bgcolor: getProgressColor(initiative.health),
                          }}
                        />
                      </Box>

                      {/* METRICS */}
                      <Box
                        sx={{
                          display: "flex",
                          flexWrap: "wrap",
                          gap: 0.75,
                        }}
                      >
                        {initiative.metrics.map((metric) => (
                          <Box
                            key={metric.id}
                            sx={{
                              width: metric.cardWidth
                                ? "100%"
                                : "calc(50% - 3px)",

                              p: 0.75,
                              borderRadius: 1,
                              border: "1px solid #E2E8F0",
                              bgcolor: "#FFF",

                              display: "flex",
                              flexDirection: "column",
                              gap: 0.5,

                              boxSizing: "border-box",
                            }}
                          >
                            {/* LABEL */}
                            <Typography
                              sx={{
                                fontSize: 9,
                                color: "#010035",
                                fontWeight: 600,
                                lineHeight: 1.2,

                                display: "-webkit-box",
                                WebkitLineClamp: 2,
                                WebkitBoxOrient: "vertical",
                                overflow: "hidden",
                              }}
                            >
                              {metric.label}
                            </Typography>

                            {/* PROGRESS */}
                            {metric.type === "progress" && (
                              <Box
                                sx={{
                                  position: "relative",
                                  pt: 1.5,
                                }}
                              >
                                {/* VALUE */}
                                <Typography
                                  sx={{
                                    position: "absolute",
                                    left: `${
                                      metric.value ?? metric.progress ?? 0
                                    }%`,
                                    transform: "translateX(-50%)",
                                    top: -2,

                                    fontSize: 8,
                                    fontWeight: 700,

                                    color: getProgressBarColor(
                                      metric.value ?? metric.progress ?? 0
                                    ),

                                    maxWidth: 40,
                                    textAlign: "center",
                                  }}
                                >
                                  {metric.value ?? metric.progress ?? 0}%
                                </Typography>

                                <LinearProgress
                                  variant="determinate"
                                  value={metric.value ?? metric.progress ?? 0}
                                  sx={{
                                    height: 5,
                                    borderRadius: 10,
                                    bgcolor: "#E5E7EB",

                                    "& .MuiLinearProgress-bar": {
                                      borderRadius: 10,
                                      bgcolor: getProgressBarColor(
                                        metric.value ?? metric.progress ?? 0
                                      ),
                                    },
                                  }}
                                />

                                {/* SCALE */}
                                <Box
                                  sx={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    mt: 0.4,
                                  }}
                                >
                                  <Typography
                                    sx={{
                                      fontSize: 8,
                                      color: "#64748B",
                                    }}
                                  >
                                    0
                                  </Typography>

                                  <Typography
                                    sx={{
                                      fontSize: 8,
                                      color: "#64748B",
                                    }}
                                  >
                                    100%
                                  </Typography>
                                </Box>
                              </Box>
                            )}

                            {/* SCORE */}
                            {metric.type === "score" && (
                              <>
                                <Typography
                                  sx={{
                                    fontSize: 10,
                                    fontWeight: 700,
                                    color: "#383D5A",
                                  }}
                                >
                                  {metric.value}
                                </Typography>

                                {metric.trend && (
                                  <Typography
                                    sx={{
                                      fontSize: 8,
                                      color: "#16A34A",
                                      fontWeight: 600,
                                    }}
                                  >
                                    {metric.trend}
                                  </Typography>
                                )}
                              </>
                            )}

                            {/* NUMBER */}
                            {metric.type === "number" && (
                              <Typography
                                sx={{
                                  fontSize: 10,
                                  fontWeight: 700,
                                  color: "#383D5A",
                                }}
                              >
                                {metric.value}
                              </Typography>
                            )}

                            {/* CURRENT / TARGET */}
                            {[
                              "milestone",
                              "currency",
                              "currentTarget",
                            ].includes(metric.type) && (
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "flex-start",
                                  justifyContent: "space-between",
                                  columnGap: 1.5,
                                  flexWrap: "wrap",
                                }}
                              >
                                <Box
                                  sx={{
                                    flex: 1,
                                    minWidth: 0,
                                  }}
                                >
                                  <Typography
                                    sx={{
                                      fontSize: 8,
                                      color: "#64748B",
                                    }}
                                  >
                                    Current
                                  </Typography>

                                  <Typography
                                    sx={{
                                      fontSize: 9,
                                      fontWeight: 700,
                                      lineHeight: 1.2,
                                      wordBreak: "break-word",
                                    }}
                                  >
                                    {metric.current}
                                  </Typography>
                                </Box>

                                <Box
                                  sx={{
                                    flex: 1,
                                    minWidth: 0,
                                    textAlign: "right",
                                  }}
                                >
                                  <Typography
                                    sx={{
                                      fontSize: 8,
                                      color: "#64748B",
                                    }}
                                  >
                                    Target
                                  </Typography>

                                  <Typography
                                    sx={{
                                      fontSize: 9,
                                      fontWeight: 700,
                                      lineHeight: 1.2,
                                      wordBreak: "break-word",
                                    }}
                                  >
                                    {metric.target}
                                  </Typography>
                                </Box>
                              </Box>
                            )}
                          </Box>
                        ))}
                      </Box>
                    </Paper>
                  </Box>
                ))}
              </Stack>
            </Box>
          </Box>
        ))}
      </Box>
      {/* </Card> */}
    </Box>
    // </Box>
  );
}
