import { Box, Typography } from "@mui/material";
import InitiativeCard from "./InitiativeCard";
import { Initiative } from "../../data/types";
import { useTheme } from "../../theme-context";
import { useMemo } from "react";

interface Props {
  initiatives: Initiative[];
}

export default function InitiativeCell({
  initiatives,
  selectedStatus,
  selectedTowers,
  selectedPriorities,
}: Props) {
  const { theme, toggle } = useTheme();

  const filteredInitiatives = useMemo(() => {
    return initiatives.filter((item) => {
      const towerMatch =
        selectedTowers.length === 0 || selectedTowers.includes(item.towerTeam);

      const statusMatch = !selectedStatus || item.status === selectedStatus;

      return towerMatch && statusMatch && item.hasdata;
    });
  }, [initiatives, selectedTowers, selectedStatus]);

  // 🔥 Don't render section if empty
  if (!filteredInitiatives.length) {
    return null;
  }

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: 1,
      }}
    >
      {filteredInitiatives.map((item) => (
        <InitiativeCard
          key={item.id}
          initiative={item}
          selectedStatus={selectedStatus}
          selectedTowers={selectedTowers}
          selectedPriorities={selectedPriorities}
        />
      ))}
    </Box>
  );
}
