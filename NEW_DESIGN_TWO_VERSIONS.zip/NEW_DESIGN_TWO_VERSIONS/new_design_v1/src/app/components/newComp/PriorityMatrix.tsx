import {
  Box,
  Typography,
  Paper,
  Switch,
  FormControlLabel,
} from "@mui/material";

import { initiatives, priorities, teams } from "../../data/newData";
import {
  initiativesV1,
  prioritiesV1,
  teamsV1,
} from "../../data/newDataTowerView";

import InitiativeCell from "./InitiativeCell";
import { useState } from "react";
import InitiativeCellV1 from "./InitiativeCellV1";

export default function PriorityMatrix() {
  const [isOn, setIsOn] = useState(false);

  const getInitiatives = (priorityId: string, teamId: string) => {
    return initiatives.filter(
      (x) => x.priority === priorityId && x.team === teamId
    );
  };

  const getInitiativesV1 = (priorityId: string, teamId: string) => {
    return initiativesV1.filter(
      (x) => x.priority === priorityId && x.team === teamId
    );
  };

  // const teamColors = {
  //   Focus: "rgba(26, 115, 232, 0.125)",
  //   Accelerate: "rgba(123, 31, 162, 0.125)",
  //   Scale: "rgba(0, 151, 167, 0.125)",
  //   Transform: "rgba(230, 81, 0, 0.125)",
  // };

  const teamColors = {
    Focus: "rgb(1 47 107 / 83%)",
    Accelerate: "rgb(1 47 107 / 83%)",
    Scale: "rgb(1 47 107 / 83%)",
    Transform: "rgb(1 47 107 / 83%)",
  };

  return (
    <>
      <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.8 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography
            fontWeight={700}
            sx={{
              fontSize: "10px",
              marginRight: "20px",
            }}
          >
            Initiatives By Priority
          </Typography>

          <Box display="flex" alignItems="center" gap={0.5}>
            <Typography
              sx={{
                fontSize: "10px",
                fontWeight: !isOn ? 700 : 400,
                opacity: !isOn ? 1 : 0.5,
                transition: "all 0.2s ease",
                color: "rgb(1 47 107 / 83%)",
              }}
            >
              FAST View
            </Typography>

            <Switch
              checked={isOn}
              onChange={(e) => setIsOn(e.target.checked)}
              size="small"
              sx={{
                transform: "scale(0.75)",
                m: 0,

                "& .MuiSwitch-switchBase.Mui-checked": {
                  color: "rgb(1 47 107 / 83%)",
                },

                "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                  backgroundColor: "rgb(1 47 107 / 33%)",
                  opacity: 1,
                },
              }}
            />

            <Typography
              sx={{
                fontSize: "10px",
                fontWeight: isOn ? 700 : 400,
                opacity: isOn ? 1 : 0.5,
                color: "rgb(1 47 107 / 83%)",
                transition: "all 0.2s ease",
              }}
            >
              Tower View
            </Typography>
          </Box>
        </Box>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 2,
          }}
        >
          {[
            { label: "On Track", color: "#10B981" },
            { label: "Needs Attention", color: "#F59E0B" },
            { label: "Off Track", color: "#EF4444" },
            { label: "Not Started", color: "#9CA3AF" },
          ].map((item) => (
            <Box
              key={item.label}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
              }}
            >
              <Box
                sx={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  bgcolor: item.color,
                }}
              />
              <Typography variant="caption" fontSize={10}>
                {item.label}
              </Typography>
            </Box>
          ))}
        </Box>
      </Box>

      {isOn ? (
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "25px repeat(5, 1fr)",
            gap: 1,
          }}
        >
          {/* Empty Corner */}
          {/* <Paper
        sx={{
          p: 2,
          textAlign: "center",
          bgcolor: "#f5f7fb",
        }}
      ></Paper> */}

          <Box />

          {/* Team Headers */}
          {teamsV1.map((team) => (
            <Paper
              key={team.id}
              sx={{
                p: 0,
                textAlign: "center",
                bgcolor: "rgb(1 47 107 / 83%)",
              }}
            >
              <Typography
                fontWeight={700}
                sx={{
                  fontSize: "10px",
                  color: "#fff",
                  minHeight: "18px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  textAlign: "center",
                }}
              >
                {team.name}
              </Typography>

              {/* <Typography
                variant="body2"
                color="text.secondary"
                sx={{ fontSize: "8px", color: "white" }}
              >
                {team.leader}
              </Typography> */}
            </Paper>
          ))}

          {/* Priority Rows */}
          {prioritiesV1.map((priority) => (
            <>
              <Box
                key={priority.id}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: "1px solid #ddd",
                  background:
                    priority.name === "Priority 1"
                      ? "rgb(0 69 158 / 95%)"
                      : priority.name === "Priority 2"
                      ? "rgb(0 69 158 / 65%)"
                      : "rgb(0 69 158 / 35%)",
                  color: priority.name === "Priority 3" ? "#fff" : "#fff",
                  minHeight: "fit-content",
                  writingMode: "vertical-rl",
                  transform: "rotate(180deg)",
                  width: "fit-content",
                  padding: "3px",
                  borderRadius: "4px",
                }}
              >
                <Typography fontWeight={700} sx={{ fontSize: "8px" }}>
                  {priority.name}
                </Typography>
              </Box>

              {teamsV1.map((team) => (
                <>
                  <InitiativeCellV1
                    initiatives={getInitiativesV1(priority.id, team.id)}
                  />
                </>
              ))}
            </>
          ))}
        </Box>
      ) : (
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "25px repeat(4, 1fr)",
            gap: 1,
          }}
        >
          <Box />

          {/* Team Headers */}
          {teams.map((team) => (
            <Paper
              key={team.id}
              sx={{
                p: 0.2,
                textAlign: "center",
                bgcolor: teamColors[team.name] || "#757575",
                color: "#fff",
                borderRadius: 1,
              }}
            >
              <Typography
                fontWeight={700}
                sx={{
                  fontSize: "10px",
                  color: "#fff",
                  minHeight: "15px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  textAlign: "center",
                }}
              >
                {team.name}
              </Typography>
            </Paper>
          ))}

          {/* Priority Rows */}
          {priorities.map((priority) => (
            <>
              <Box
                key={priority.id}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: "1px solid #ddd",
                  background:
                    priority.name === "Priority 1"
                      ? "rgb(0 69 158 / 95%)"
                      : priority.name === "Priority 2"
                      ? "rgb(0 69 158 / 65%)"
                      : "rgb(0 69 158 / 35%)",
                  color: priority.name === "Priority 3" ? "#fff" : "#fff",
                  minHeight: "fit-content",
                  writingMode: "vertical-rl",
                  transform: "rotate(180deg)",
                  width: "fit-content",
                  padding: "3px",
                  borderRadius: "4px",
                }}
              >
                <Typography fontWeight={700} sx={{ fontSize: "8px" }}>
                  {priority.name}
                </Typography>
              </Box>

              {teams.map((team) => (
                <Paper
                  key={priority.id + team.id}
                  variant="outlined"
                  sx={{
                    minHeight: "fit-content",
                  }}
                >
                  <InitiativeCell
                    initiatives={getInitiatives(priority.id, team.id)}
                  />
                </Paper>
              ))}
            </>
          ))}
        </Box>
      )}
    </>
  );
}
