import React from "react";
import { Box, Typography, Paper, Stack, Avatar } from "@mui/material";

import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import WarningIcon from "@mui/icons-material/Warning";
import ErrorIcon from "@mui/icons-material/Error";
import AppsIcon from "@mui/icons-material/Apps";
import BoltIcon from "@mui/icons-material/Bolt";
import GroupsIcon from "@mui/icons-material/Groups";
import SettingsSuggestIcon from "@mui/icons-material/SettingsSuggest";
import MemoryIcon from "@mui/icons-material/Memory";

import healthData from "../../data/dashboard-new.json";
import LinearProgress from "@mui/material/LinearProgress";

const icons: Record<string, React.ReactNode> = {
  "Total Initiatives": <AppsIcon sx={{ fontSize: 14 }} />,
  "On Track": <CheckCircleIcon sx={{ fontSize: 14 }} />,
  "At Risk": <WarningIcon sx={{ fontSize: 14 }} />,
  "Off Track": <ErrorIcon sx={{ fontSize: 14 }} />,

  FAST: <BoltIcon sx={{ fontSize: 14 }} />,
  People: <GroupsIcon sx={{ fontSize: 14 }} />,
  Process: <SettingsSuggestIcon sx={{ fontSize: 14 }} />,
  Technology: <MemoryIcon sx={{ fontSize: 14 }} />,
};

const TransformationHealth = () => {
  const { overallHealth, cards } = healthData;
  const pillarCards = ["Focus", "Accelerate", "Scale", "Transform"];
  return (
    <Paper
      elevation={0}
      sx={{
        width: "100%",
        borderRadius: 2,
        // border: "1px solid #E5E7EB",
        // overflow: "hidden",
        background: "#fff",
        padding: "10px",
      }}
    >
      <Box
        sx={{
          display: "flex",
          gap: 1,
          alignItems: "stretch",
          width: "100%",
        }}
      >
        {/* Overall Health Card */}
        <Box
          sx={{
            p: 1,
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            bgcolor: "#fff",
            height: 85,
            width: 165,
          }}
        >
          <Typography fontWeight={700} fontSize={8} color="#64748B" mb={1}>
            {overallHealth.title}
          </Typography>

          <Stack direction="row" spacing={1} alignItems="center">
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: "50%",
                background: `conic-gradient(
          #00A78E 0deg ${overallHealth.percentage * 3.6}deg,
          #EEF1F6 ${overallHealth.percentage * 3.6}deg 360deg
        )`,
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Box
                sx={{
                  width: 30,
                  height: 30,
                  borderRadius: "50%",
                  bgcolor: "#fff",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Typography fontSize={10} fontWeight={800}>
                  {overallHealth.percentage}%
                </Typography>
              </Box>
            </Box>

            <Box>
              <Typography fontSize={8} fontWeight={700} color="#F26A21">
                {overallHealth.status}
              </Typography>

              <Typography fontSize={7} color="#E40046">
                ▼ {overallHealth.trend}
              </Typography>
            </Box>
          </Stack>
        </Box>

        {/* KPI Cards */}
        {cards.map((card) => (
          <Box
            key={card.label}
            sx={{
              p: 1,
              border: "1px solid #E5E7EB",
              borderRadius: 2,
              bgcolor: "#fff",

              flex: pillarCards.includes(card.label) ? 1.2 : 0.8,
              minWidth: pillarCards.includes(card.label) ? 110 : 120,
              height: 85,
            }}
          >
            <Stack direction="row" spacing={0.5} alignItems="center">
              <Avatar
                sx={{
                  width: 16,
                  height: 16,
                  bgcolor: card.color,
                  "& svg": {
                    fontSize: 10,
                  },
                }}
              >
                {icons[card.label]}
              </Avatar>

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Typography fontSize={10} fontWeight={700}>
                  {card.label}
                </Typography>

                <Typography
                  fontSize={8}
                  fontWeight={700}
                  sx={{ color: "#7a7a7a9c" }}
                >
                  {card.totStats}
                </Typography>
              </Box>
            </Stack>

            <Typography
              fontSize={20}
              fontWeight={700}
              noWrap
              sx={{
                textAlign: "left",
                marginTop: card.value === null ? "7px" : "15px",
              }}
            >
              {card.value}
            </Typography>

            {card.stats && (
              <Box mt={0.5}>
                {card.stats.map((stat) => {
                  const total =
                    card.stats?.reduce((sum, item) => sum + item.value, 0) || 0;

                  const percentage = (stat.value / total) * 100;

                  return (
                    <Box
                      key={stat.label}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        gap: 0.5,
                        mb: 0.4,
                      }}
                    >
                      {/* Label */}
                      <Typography
                        sx={{
                          fontSize: "8px",
                          fontWeight: 600,
                          minWidth: 40,
                          color: "#475569",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {stat.label}
                      </Typography>

                      {/* Progress */}
                      {/* <LinearProgress
                        variant="determinate"
                        value={percentage}
                        sx={{
                          flex: 1,
                          height: 5,
                          borderRadius: 5,
                          backgroundColor: "#E2E8F0",

                          "& .MuiLinearProgress-bar": {
                            backgroundColor: stat.color,
                            borderRadius: 5,
                          },
                        }}
                      /> */}

                      {/* Value */}
                      <Typography
                        sx={{
                          fontSize: "8px",
                          fontWeight: 700,
                          color: stat.color,
                          minWidth: 12,
                          textAlign: "right",
                        }}
                      >
                        {stat.value}
                      </Typography>
                    </Box>
                  );
                })}
              </Box>
            )}
          </Box>
        ))}
      </Box>
    </Paper>
  );
};

export default TransformationHealth;
