import { Sun, Moon } from "lucide-react";
import type { Initiative } from "../data/initiatives";
import { useTheme } from "../theme-context";
import {
  Box,
  Button,
  FormControlLabel,
  Switch,
  Tooltip,
  Typography,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import { useNavigate } from "react-router-dom";

interface FastHeaderProps {
  initiatives: Initiative[];
  filteredInitiatives: Initiative[];
  activePillar?: string | null;
  onPillarFilter?: (pillar: string | null) => void;
  activeStatus?: string | null;
  onStatusFilter?: (status: string | null) => void;
}

const FAST_PILLARS = [
  {
    key: "Focus",
    letter: "F",
    full: "Focus",
    sub: "BU & Functional Priorities",
    pillarKey: "pillarFast" as const,
  },
  {
    key: "Acceleration",
    letter: "A",
    full: "Accelerate",
    sub: "Product Portfolio Impact",
    pillarKey: "pillarAccel" as const,
  },
  {
    key: "Scale",
    letter: "S",
    full: "Scale",
    sub: "GPT Led Growth Bets",
    pillarKey: "pillarScale" as const,
  },
  {
    key: "Transform",
    letter: "T",
    full: "Transform",
    sub: "GPT Operations & Engagement",
    pillarKey: "pillarTrans" as const,
  },
];

export function FastHeaderNew() {
  const { theme, toggle } = useTheme();

  const navigate = useNavigate();

  const isLight = theme.mode === "light";

  return (
    <>
      <div
        style={{
          background: theme.surface,
          borderBottom: `1px solid ${theme.border}`,
        }}
      >
        {/* Top bar */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "10px 8px 10px",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {/* ADP-style logo bar */}
            <div style={{ display: "flex", alignItems: "center", gap: 2 }}>
              {["#4285f4", "#ea4335", "#fbbc04", "#34a853"].map((c, i) => (
                <div
                  key={i}
                  style={{
                    width: 4,
                    height: 28,
                    background: c,
                    borderRadius: 2,
                  }}
                />
              ))}
            </div>

            <div>
              <div
                style={{
                  color: theme.textPrimary,
                  fontSize: 15,
                  fontWeight: 500,
                  letterSpacing: "0.01em",
                  lineHeight: 1.3,
                }}
              >
                Command Center - Overview
              </div>
              <div
                style={{
                  color: theme.textTertiary,
                  fontSize: 11,
                  marginTop: 1,
                  letterSpacing: "0.02em",
                }}
              >
                Strategic Initiative Dashboard · FY2026
              </div>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
            {/* Summary stats */}

            <Box sx={{ display: "flex", alignItems: "center" }}>
              <div
                style={{
                  padding: "5px 10px",
                  background: theme.brandPrimaryBg,
                  borderRadius: 6,
                  color: theme.brandPrimaryText,
                  fontSize: 11,
                  fontFamily: "var(--font-mono)",
                  //   border: `1px solid ${theme.chipActiveBorder}`,
                  fontWeight: 500,
                }}
              >
                Live ·{" "}
                {new Date().toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </div>
            </Box>
          </div>
        </div>
      </div>
    </>
  );
}
