import React from "react";
import {
  Box,
  Card,
  Avatar,
  Chip,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Stack,
} from "@mui/material";

import CloudQueueIcon from "@mui/icons-material/CloudQueue";
import PsychologyIcon from "@mui/icons-material/Psychology";
import ShieldOutlinedIcon from "@mui/icons-material/ShieldOutlined";
import BusinessIcon from "@mui/icons-material/Business";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import AnalyticsIcon from "@mui/icons-material/Analytics";

type Capability = {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  owner: string;
  role: string;
  avatar: string;
  businessUnit: string;
  buIcon: React.ReactNode;
  status: string;
  statusColor: "success" | "warning" | "error";
  issue: string;
};

const data: Capability[] = [
  {
    title: "Cloud Migration",
    subtitle: "Enterprise Technology",
    icon: <CloudQueueIcon sx={{ fontSize: 10 }} />,
    owner: "Prakash",
    role: "Transform",
    avatar: "",
    businessUnit: "Technology",
    buIcon: <BusinessIcon sx={{ fontSize: 12 }} />,
    status: "Needs Attention",
    statusColor: "warning",
    issue: "Vendor delay affecting migration timeline.",
  },
  {
    title: "Breakthrough Business Revenue - Data",
    subtitle: "Breakthrough",
    icon: <PsychologyIcon sx={{ fontSize: 10 }} />,
    owner: "Oz",
    role: "Scale",
    avatar: "",
    businessUnit: "Operations",
    buIcon: <TrendingUpIcon sx={{ fontSize: 12 }} />,
    status: "Needs Attention",
    statusColor: "warning",
    issue: "Training adoption lower than expected.",
  },
];

const LeadershipTable: React.FC = () => {
  return (
    <>
      <TableContainer>
        <Table
          size="small"
          sx={{
            tableLayout: "fixed",
            "& .MuiTableCell-root": {
              fontSize: "8px",
              padding: "4px",
              borderBottom: "1px solid #eef2f7",
              verticalAlign: "top",
            },
          }}
        >
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 800, width: "25%" }}>
                Capability
              </TableCell>
              <TableCell sx={{ fontWeight: 800, width: "18%" }}>
                Leader
              </TableCell>
              <TableCell sx={{ fontWeight: 800, width: "12%" }}>
                Status
              </TableCell>
              <TableCell sx={{ fontWeight: 800, width: "30%" }}>
                Issue
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {data.map((item) => (
              <TableRow key={item.title}>
                {/* Capability */}
                <TableCell>
                  <Stack direction="row" spacing={0.5}>
                    <Box>
                      <Typography
                        sx={{
                          fontSize: "8px",
                          fontWeight: 700,
                          lineHeight: 1.2,
                        }}
                      >
                        {item.title}
                      </Typography>

                      <Typography
                        sx={{
                          fontSize: "7px",
                          color: "#64748b",
                          lineHeight: 1.2,
                        }}
                      >
                        {item.subtitle}
                      </Typography>
                    </Box>
                  </Stack>
                </TableCell>

                {/* Leader */}
                <TableCell>
                  <Stack direction="row" spacing={0.5}>
                    <Avatar
                      src={item.avatar}
                      sx={{
                        width: 15,
                        height: 15,
                      }}
                    />

                    <Box>
                      <Typography
                        sx={{
                          fontSize: "8px",
                          fontWeight: 700,
                          lineHeight: 1.2,
                        }}
                      >
                        {item.owner}
                      </Typography>

                      <Typography
                        sx={{
                          fontSize: "7px",
                          color: "#64748b",
                          lineHeight: 1.2,
                        }}
                      >
                        {item.role}
                      </Typography>
                    </Box>
                  </Stack>
                </TableCell>

                {/* Status */}
                <TableCell>
                  <Chip
                    label={item.status}
                    color={item.statusColor}
                    size="small"
                    sx={{
                      height: 16,
                      "& .MuiChip-label": {
                        px: 0.5,
                        fontSize: "7px",
                        fontWeight: 700,
                      },
                    }}
                  />
                </TableCell>

                {/* Issue */}
                <TableCell>
                  <Typography
                    sx={{
                      fontSize: "8px",
                      lineHeight: 1.3,
                      color: "#475569",
                    }}
                  >
                    {item.issue}
                  </Typography>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
};

export default LeadershipTable;
