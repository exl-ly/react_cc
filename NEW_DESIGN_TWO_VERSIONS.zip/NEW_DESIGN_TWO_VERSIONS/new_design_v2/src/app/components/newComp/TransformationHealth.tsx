import React from "react";
import { Box, Typography, Paper, Stack, Avatar, Card } from "@mui/material";

import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import WarningIcon from "@mui/icons-material/Warning";
import ErrorIcon from "@mui/icons-material/Error";
import AppsIcon from "@mui/icons-material/Apps";
import BoltIcon from "@mui/icons-material/Bolt";
import GroupsIcon from "@mui/icons-material/Groups";
import SettingsSuggestIcon from "@mui/icons-material/SettingsSuggest";
import MemoryIcon from "@mui/icons-material/Memory";

import healthData from "../../data/dashboard-new.json";
import LeadershipTable from "./LeadershipTable";
import LinearProgress from "@mui/material/LinearProgress";

const icons: Record<string, React.ReactNode> = {
  "Total Initiatives": <AppsIcon sx={{ fontSize: 14 }} />,
  "On Track": <CheckCircleIcon sx={{ fontSize: 14 }} />,
  "At Risk": <WarningIcon sx={{ fontSize: 14 }} />,
  "Off Track": <ErrorIcon sx={{ fontSize: 14 }} />,

  FAST: <BoltIcon sx={{ fontSize: 14 }} />,
  People: <GroupsIcon sx={{ fontSize: 14 }} />,
  Process: <SettingsSuggestIcon sx={{ fontSize: 14 }} />,
  Technology: <MemoryIcon sx={{ fontSize: 14 }} />,
};

const TransformationHealth = () => {
  const { overallHealth, cards, pillars } = healthData;
  const pillarCards = ["Focus", "Accelerate", "Scale", "Transform"];
  return (
    <Paper
      elevation={0}
      sx={{
        width: "100%",
        borderRadius: 2,
        // border: "1px solid #E5E7EB",
        // overflow: "hidden",
        background: "#fff",
        padding: "8px 10px",
      }}
    >
      <Box
        sx={{
          display: "flex",
          gap: 1,
          alignItems: "stretch",
          width: "100%",
        }}
      >
        {/* Overall Health Card */}
        <Box
          sx={{
            p: 0.5,
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            bgcolor: "#fff",
            height: 50,
            width: 195,
          }}
        >
          <Typography fontWeight={700} fontSize={8} color="#64748B" mb={0.5}>
            {overallHealth.title}
          </Typography>

          <Stack direction="row" spacing={1} alignItems="center">
            <Box
              sx={{
                width: 25,
                height: 25,
                borderRadius: "50%",
                background: `conic-gradient(
          #00A78E 0deg ${overallHealth.percentage * 3.6}deg,
          #EEF1F6 ${overallHealth.percentage * 3.6}deg 360deg
        )`,
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Box
                sx={{
                  width: 18,
                  height: 18,
                  borderRadius: "50%",
                  bgcolor: "#fff",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Typography fontSize={8} fontWeight={800}>
                  {overallHealth.percentage}%
                </Typography>
              </Box>
            </Box>

            <Box>
              <Typography fontSize={8} fontWeight={700} color="#F26A21">
                {overallHealth.status}
              </Typography>

              <Typography fontSize={8} color="#E40046">
                ▼ {overallHealth.trend}
              </Typography>
            </Box>
          </Stack>
        </Box>

        {/* KPI Cards */}
        {cards.map((card) => (
          <Box
            key={card.label}
            sx={{
              p: 1,
              border: "1px solid #E5E7EB",
              borderRadius: 2,
              bgcolor: "#fff",

              flex: pillarCards.includes(card.label) ? 1.2 : 0.8,
              minWidth: pillarCards.includes(card.label) ? 90 : 110,
              height: 50,
            }}
          >
            {/* <Stack direction="row" spacing={0.5} alignItems="center">
              <Avatar
                sx={{
                  width: 16,
                  height: 16,
                  bgcolor: card.color,
                  "& svg": {
                    fontSize: 10,
                  },
                }}
              >
                {icons[card.label]}
              </Avatar>

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Typography fontSize={10} fontWeight={700}>
                  {card.label}
                </Typography>

                <Typography
                  fontSize={8}
                  fontWeight={700}
                  sx={{ color: "#7a7a7a9c" }}
                >
                  {card.totStats}
                </Typography>
              </Box>
            </Stack> */}

            {/* <Typography
              fontSize={20}
              fontWeight={700}
              noWrap
              sx={{
                textAlign: "left",
                marginTop: card.value === null ? "7px" : "15px",
              }}
            >
              {card.value}
            </Typography> */}
            <Stack direction="row" spacing={1} alignItems="center">
              <Avatar
                sx={{
                  width: 30,
                  height: 30,
                  alignItems: "center",
                  bgcolor: `${card.color}20`,
                  color: card.color,
                  "& svg": {
                    fontSize: 25,
                  },
                }}
              >
                {icons[card.label]}
              </Avatar>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Typography
                  sx={{
                    fontSize: 12,
                    fontWeight: 600,
                    lineHeight: 1.2,
                  }}
                >
                  {card.label}
                </Typography>

                <Typography
                  sx={{
                    fontSize: 24,
                    fontWeight: 700,
                    lineHeight: 1.2,
                  }}
                >
                  {card.value}
                </Typography>
              </Box>

              {card.totStats && (
                <Typography
                  sx={{
                    fontSize: 11,
                    color: "#9CA3AF",
                    mt: 0.25,
                  }}
                >
                  {card.totStats}
                </Typography>
              )}
            </Stack>

            {card.stats && (
              <Box mt={0.5}>
                {card.stats.map((stat) => {
                  const total =
                    card.stats?.reduce((sum, item) => sum + item.value, 0) || 0;

                  const percentage = (stat.value / total) * 100;

                  return (
                    <Box
                      key={stat.label}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        gap: 0.5,
                        mb: 0.4,
                      }}
                    >
                      {/* Label */}
                      <Typography
                        sx={{
                          fontSize: "8px",
                          fontWeight: 600,
                          minWidth: 40,
                          color: "#475569",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {stat.label}
                      </Typography>

                      {/* Progress */}
                      {/* <LinearProgress
                        variant="determinate"
                        value={percentage}
                        sx={{
                          flex: 1,
                          height: 5,
                          borderRadius: 5,
                          backgroundColor: "#E2E8F0",

                          "& .MuiLinearProgress-bar": {
                            backgroundColor: stat.color,
                            borderRadius: 5,
                          },
                        }}
                      /> */}

                      {/* Value */}
                      <Typography
                        sx={{
                          fontSize: "8px",
                          fontWeight: 700,
                          color: stat.color,
                          minWidth: 12,
                          textAlign: "right",
                        }}
                      >
                        {stat.value}
                      </Typography>
                    </Box>
                  );
                })}
              </Box>
            )}
          </Box>
        ))}
      </Box>
      <Box
        sx={{
          mt: 1,
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "1fr 1fr",
          },
          gap: 1,
          width: "100%",
        }}
      >
        <Paper
          elevation={0}
          sx={{
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            p: 0.5,
            // minHeight: 250,
          }}
        >
          <Typography
            sx={{
              fontSize: 10,
              fontWeight: 700,
              mb: 0.5,
            }}
          >
            Fast Pillars
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 1,
            }}
          >
            {pillars.map((pillar) => (
              <Box
                key={pillar.label}
                sx={{
                  p: 1,
                  border: "1px solid #E5E7EB",
                  borderRadius: 2,
                  bgcolor: "#fff",

                  flex: pillarCards.includes(pillar.label) ? 1.2 : 0.8,
                  minWidth: pillarCards.includes(pillar.label) ? 90 : 110,
                  height: 85,
                }}
              >
                <Stack direction="row" spacing={0.5} alignItems="center">
                  <Avatar
                    sx={{
                      width: 16,
                      height: 16,
                      bgcolor: pillar.color,
                      "& svg": {
                        fontSize: 10,
                      },
                    }}
                  >
                    {icons[pillar.label]}
                  </Avatar>

                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      width: "100%",
                    }}
                  >
                    <Typography fontSize={10} fontWeight={700}>
                      {pillar.label}
                    </Typography>

                    <Typography
                      fontSize={8}
                      fontWeight={700}
                      sx={{ color: "#7a7a7a9c" }}
                    >
                      {pillar.totStats}
                    </Typography>
                  </Box>
                </Stack>

                <Typography
                  fontSize={20}
                  fontWeight={700}
                  noWrap
                  sx={{
                    textAlign: "left",
                    marginTop: pillar.value === null ? "7px" : "15px",
                  }}
                >
                  {pillar.value}
                </Typography>

                {pillar.stats && (
                  <Box mt={0.5}>
                    {pillar.stats.map((stat) => {
                      const total =
                        pillar.stats?.reduce(
                          (sum, item) => sum + item.value,
                          0
                        ) || 0;

                      const percentage = (stat.value / total) * 100;

                      return (
                        <Box
                          key={stat.label}
                          sx={{
                            display: "flex",
                            justifyContent: "space-between",
                            gap: 0.5,
                            mb: 0.4,
                          }}
                        >
                          {/* Label */}
                          <Typography
                            sx={{
                              fontSize: "8px",
                              fontWeight: 600,
                              minWidth: 40,
                              color: "#475569",
                              whiteSpace: "nowrap",
                            }}
                          >
                            {stat.label}
                          </Typography>

                          {/* Value */}
                          <Typography
                            sx={{
                              fontSize: "8px",
                              fontWeight: 700,
                              color: stat.color,
                              minWidth: 12,
                              textAlign: "right",
                            }}
                          >
                            {stat.value}
                          </Typography>
                        </Box>
                      );
                    })}
                  </Box>
                )}
              </Box>
            ))}
          </Box>
        </Paper>

        <Paper
          elevation={0}
          sx={{
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            p: 0.5,
            // minHeight: 250,
          }}
        >
          <Typography
            variant="subtitle2"
            fontWeight={700}
            // mb={1}
            sx={{ fontSize: "10px" }}
          >
            Leadership Attention Needed
          </Typography>

          <LeadershipTable />
        </Paper>
      </Box>
    </Paper>
  );
};

export default TransformationHealth;
