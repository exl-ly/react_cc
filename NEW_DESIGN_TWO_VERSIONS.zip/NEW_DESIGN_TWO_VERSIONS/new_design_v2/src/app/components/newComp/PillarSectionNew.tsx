import React from "react";
import { Box, Card, Typography } from "@mui/material";
import PriorityMatrix from "./PriorityMatrix";
import LeadershipTable from "./LeadershipTable";

const PillarSectionNew = () => {
  return (
    <Box
      sx={{
        width: "100%",
        backgroundColor: "#fff",
        padding: "0 10px",
      }}
    >
      <Box
        sx={{
          display: {
            xs: "block",
            md: "flex",
          },
          gap: 0.5,
          width: "100%",
        }}
      >
        {/* Left Card - 70% */}
        <Card
          elevation={0}
          sx={{
            flex: 6.5,
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            padding: "2px 5px",
            backgroundColor: "#fff",
            // minHeight: 300,
          }}
        >
          <PriorityMatrix />

          {/* <Typography color="text.secondary">
            Add your charts, tables, initiatives, or dashboard content here.
          </Typography> */}
        </Card>

        {/* Right Card - 30% */}
        {/* <Card
          elevation={0}
          sx={{
            flex: 3.5,
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            p: 1,
            backgroundColor: "#fff",
            minHeight: 300,
            mt: {
              xs: 2,
              md: 0,
            },
          }}
        >
          <Typography
            variant="subtitle2"
            fontWeight={700}
            mb={1}
            sx={{ fontSize: "10px" }}
          >
            Leadership Attention Needed
          </Typography>

          <LeadershipTable />

          
        </Card> */}
      </Box>
    </Box>
  );
};

export default PillarSectionNew;
