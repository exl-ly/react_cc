import { useState, useMemo, useRef, useEffect } from "react";
import { Search, LayoutGrid, List, RefreshCw } from "lucide-react";
import { ThemeProvider, useTheme } from "./theme-context";
import { FastHeader } from "./components/fast-header";
import { Sidebar } from "./components/sidebar";
import { InitiativeTable } from "./components/initiative-table";
import { INITIATIVES } from "./data/initiatives";
import Overview from "./components/overview";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CockpitView from "./components/CockpitView";
import NewDashboard from "./components/newComp/NewDashboard";
import FastDashboard from "./components/newComp/FastDashboard";
import FastDashboardNew from "./components/newComp/FastDashboardNew";
import InitiativeDeepDive from "./components/newComp/InitiativeDeepDive";
import TowerDetails from "./components/newComp/TowerDetails";
import GPTGlobalDeliveryModel from "./components/pages/GPTGlobalDeliveryModel";
import MainDashboard from "./components/newComp/MainDashboard";

export default function App() {
  return (
    // <ThemeProvider>
    //   <Portal />
    // </ThemeProvider>
    <BrowserRouter>
      <Routes>
        <Route path="/new" element={<FastDashboard />} />
        <Route path="/" element={<FastDashboardNew />} />
        {/* <Route path="/" element={<MainDashboard />} /> */}
        {/* <Route path="/:towerName" element={<MainDashboard  />} /> */}

        <Route path="/cockpit-view" element={<CockpitView />} />
        <Route path="/:initiativeName" element={<GPTGlobalDeliveryModel />} />
      </Routes>
    </BrowserRouter>
  );
}

function Portal() {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";

  const [activeLeader, setActiveLeader] = useState<string | null>(null);
  const [activePillar, setActivePillar] = useState<string | null>(null);
  const [activeStatus, setActiveStatus] = useState<string | null>(null);
  const [activeTower, setActiveTower] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grouped" | "flat">("grouped");
  const [showCockpitView, setShowCockpitView] = useState(false);
  const [hover, setHover] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const bottomRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const filtered = useMemo(
    () =>
      INITIATIVES.filter((i) => {
        if (activeLeader && i.leader !== activeLeader) return false;
        if (activePillar && i.pillar !== activePillar) return false;
        if (activeStatus && i.status !== activeStatus) return false;
        if (activeTower && i.tower !== activeTower) return false;
        if (activeCategory && i.category !== activeCategory) return false;
        if (searchQuery) {
          const q = searchQuery.toLowerCase();
          return (
            i.name.toLowerCase().includes(q) ||
            i.id.toLowerCase().includes(q) ||
            i.leader.toLowerCase().includes(q) ||
            i.statusNote.toLowerCase().includes(q)
          );
        }
        return true;
      }),
    [
      activeLeader,
      activePillar,
      activeStatus,
      activeTower,
      activeCategory,
      searchQuery,
    ]
  );

  const hasFilters =
    activeLeader ||
    activePillar ||
    activeStatus ||
    activeTower ||
    activeCategory ||
    searchQuery;

  const toolbarBg = isLight ? "#ffffff" : "#0c1018";
  const footerBg = isLight ? "#ffffff" : "#0c1018";

  const onClickHandler = () => {
    setShowCockpitView((prev) => !prev);
    setIsOpen(true);
  };

  useEffect(() => {
    if (isOpen && bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [isOpen, showCockpitView]);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 100) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);
    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);

  const buttonStyle = {
    display: isVisible ? "flex" : "none",
    position: "fixed",
    bottom: "20px",
    right: "25px",
    zIndex: 1000,
    cursor: "pointer",
    // Transparent charcoal tint by default, solid black on hover
    backgroundColor: isHovered ? "#000000" : "rgba(0, 0, 0, 0.4)",
    color: "#fff",
    border: "none",
    borderRadius: "40%",
    width: "40px",
    height: "40px",
    fontSize: "20px",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    // Added transition for the transparent effect to smoothly change into black
    transition: "background-color 0.3s ease",
  };
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        background: theme.bg,
        color: theme.textPrimary,
        fontFamily: "var(--font-sans, Roboto, system-ui, sans-serif)",
        overflow: "hidden",
        transition: "background 0.2s, color 0.2s",
      }}
    >
      <Overview />
      <button
        onClick={onClickHandler}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        style={{
          color: hover ? "#ffffff" : "inherit",
          background: hover ? "rgb(171 169 240)" : "rgb(202 201 241)",
          cursor: "pointer",
          transition: "color 0.2s ease",
          boxShadow: "0 1px 3px rgba(60,64,67,0.06)",
        }}
      >
        {showCockpitView ? "Close Cockpit View" : "Show Cockpit View"}
      </button>
      {showCockpitView && (
        <div ref={bottomRef}>
          <FastHeader
            initiatives={INITIATIVES}
            filteredInitiatives={filtered}
            activePillar={activePillar}
            onPillarFilter={setActivePillar}
            activeStatus={activeStatus}
            onStatusFilter={setActiveStatus}
          />

          <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
            <div
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
              }}
            >
              {/* Toolbar */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "8px 16px",
                  background: toolbarBg,
                  borderBottom: `1px solid ${theme.border}`,
                  flexShrink: 0,
                  boxShadow: isLight ? "0 1px 3px rgba(60,64,67,0.06)" : "none",
                }}
              >
                {/* Search */}
                <div style={{ position: "relative", flex: 1, maxWidth: 340 }}>
                  <Search
                    size={13}
                    color={theme.textTertiary}
                    style={{
                      position: "absolute",
                      left: 10,
                      top: "50%",
                      transform: "translateY(-50%)",
                    }}
                  />
                  <input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search initiatives, leaders, notes..."
                    style={{
                      width: "100%",
                      background: isLight ? "#f1f3f4" : "#161b28",
                      border: `1px solid ${theme.border}`,
                      borderRadius: 20,
                      padding: "6px 12px 6px 32px",
                      color: theme.textPrimary,
                      fontSize: 12,
                      outline: "none",
                      boxSizing: "border-box",
                      fontFamily: "inherit",
                    }}
                  />
                </div>

                {/* Active filter chips */}
                <div
                  style={{ display: "flex", gap: 6, flex: 1, flexWrap: "wrap" }}
                >
                  {activeTower && (
                    <FTag
                      label={`Tower: ${activeTower}`}
                      onRemove={() => setActiveTower(null)}
                      theme={theme}
                    />
                  )}
                  {activeCategory && (
                    <FTag
                      label={`Category: ${activeCategory}`}
                      onRemove={() => setActiveCategory(null)}
                      theme={theme}
                    />
                  )}
                  {activeLeader && (
                    <FTag
                      label={`Leader: ${activeLeader}`}
                      onRemove={() => setActiveLeader(null)}
                      theme={theme}
                    />
                  )}
                  {activePillar && (
                    <FTag
                      label={`Pillar: ${activePillar}`}
                      onRemove={() => setActivePillar(null)}
                      theme={theme}
                    />
                  )}
                  {activeStatus && (
                    <FTag
                      label={`Status: ${activeStatus}`}
                      onRemove={() => setActiveStatus(null)}
                      theme={theme}
                    />
                  )}
                  {hasFilters && (
                    <button
                      onClick={() => {
                        setActiveLeader(null);
                        setActivePillar(null);
                        setActiveStatus(null);
                        setActiveTower(null);
                        setActiveCategory(null);
                        setSearchQuery("");
                      }}
                      style={{
                        background: "none",
                        border: "none",
                        color: theme.textTertiary,
                        fontSize: 11,
                        cursor: "pointer",
                        padding: "2px 6px",
                        display: "flex",
                        alignItems: "center",
                        gap: 4,
                        fontFamily: "inherit",
                      }}
                    >
                      <RefreshCw size={10} /> Clear all
                    </button>
                  )}
                </div>

                <div
                  style={{
                    color: theme.textTertiary,
                    fontSize: 11,
                    whiteSpace: "nowrap",
                  }}
                >
                  <span style={{ color: theme.brandPrimary, fontWeight: 600 }}>
                    {filtered.length}
                  </span>{" "}
                  of {INITIATIVES.length} initiatives
                </div>

                {/* View toggle */}
                <div
                  style={{
                    display: "flex",
                    background: isLight ? "#f1f3f4" : "#161b28",
                    border: `1px solid ${theme.border}`,
                    borderRadius: 8,
                    overflow: "hidden",
                  }}
                >
                  {(["grouped", "flat"] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setViewMode(mode)}
                      title={
                        mode === "grouped" ? "Group by pillar" : "Flat list"
                      }
                      style={{
                        background:
                          viewMode === mode
                            ? theme.brandPrimaryBg
                            : "transparent",
                        border: "none",
                        padding: "5px 10px",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        color:
                          viewMode === mode
                            ? theme.brandPrimary
                            : theme.textTertiary,
                        transition: "all 0.15s",
                      }}
                    >
                      {mode === "grouped" ? (
                        <LayoutGrid size={13} />
                      ) : (
                        <List size={13} />
                      )}
                    </button>
                  ))}
                </div>
              </div>
              {/* Table */}
              <div
                style={{
                  flex: 1,
                  overflowY: "auto",
                  scrollbarWidth: "thin",
                  scrollbarColor: `${theme.border} transparent`,
                }}
              >
                <InitiativeTable
                  initiatives={filtered}
                  groupByPillar={viewMode === "grouped" && !activePillar}
                />
                <button
                  aria-label="Go to top"
                  style={buttonStyle}
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                  onClick={() =>
                    window.scrollTo({ top: 0, behavior: "smooth" })
                  }
                >
                  ↑
                </button>
              </div>

              {/* Footer */}
              <div
                style={{
                  padding: "6px 20px",
                  background: footerBg,
                  borderTop: `1px solid ${theme.divider}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  flexShrink: 0,
                }}
              >
                {/* <div style={{ display: "flex", gap: 18 }}>
              {[
                { label: "On Track", color: theme.onTrack, count: INITIATIVES.filter((i) => i.status === "on-track").length },
                { label: "Needs Attention", color: theme.attention, count: INITIATIVES.filter((i) => i.status === "attention").length },
                { label: "Off Track", color: theme.offTrack, count: INITIATIVES.filter((i) => i.status === "off-track").length },
              ].map((s) => (
                <div key={s.label} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <div style={{ width: 7, height: 7, borderRadius: "50%", background: s.color }} />
                  <span style={{ color: theme.textTertiary, fontSize: 10 }}>
                    <span style={{ color: s.color, fontWeight: 700 }}>{s.count}</span> {s.label}
                  </span>
                </div>
              ))}
            </div> */}
                <div
                  style={{
                    color: theme.textTertiary,
                    fontSize: 10,
                    fontFamily: "var(--font-mono, monospace)",
                    opacity: 0.6,
                  }}
                >
                  FY2026 Strategic Portfolio · Confidential
                </div>
              </div>
            </div>
            <Sidebar
              activeLeader={activeLeader}
              onLeaderChange={setActiveLeader}
              activePillar={activePillar}
              onPillarChange={setActivePillar}
              activeStatus={activeStatus}
              onStatusChange={setActiveStatus}
              activeTower={activeTower}
              onTowerChange={setActiveTower}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
              filteredInitiatives={filtered}
            />
          </div>
        </div>
      )}
    </div>
  );
}

function FTag({
  label,
  onRemove,
  theme,
}: {
  label: string;
  onRemove: () => void;
  theme: ReturnType<typeof useTheme>["theme"];
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 4,
        padding: "3px 8px",
        background: theme.brandPrimaryBg,
        border: `1px solid ${theme.chipActiveBorder}`,
        borderRadius: 12,
        color: theme.brandPrimary,
        fontSize: 11,
        fontWeight: 500,
      }}
    >
      {label}
      <button
        onClick={onRemove}
        style={{
          background: "none",
          border: "none",
          cursor: "pointer",
          color: theme.brandPrimary,
          padding: 0,
          lineHeight: 1,
          fontSize: 14,
          display: "flex",
          alignItems: "center",
        }}
      >
        ×
      </button>
    </div>
  );
}
