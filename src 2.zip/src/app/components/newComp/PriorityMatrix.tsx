import {
  Box,
  Typography,
  Paper,
  Switch,
  FormControlLabel,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  OutlinedInput,
  ListItemText,
  SelectChangeEvent,
  Chip,
  Button,
  Card,
  Stack,
  Tooltip,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import IconButton from "@mui/material/IconButton";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import { initiatives, priorities, teams } from "../../data/newData";
import { useTheme } from "../../theme-context";
import PillarOverview from "./PillarOverview";
import {
  initiativesV1,
  prioritiesV1,
  teamsV1,
} from "../../data/newDataTowerView";

import InitiativeCell from "./InitiativeCell";
import { useState, useEffect, useMemo } from "react";
import InitiativeCellV1 from "./InitiativeCellV1";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import FocusSection from "./FocusSection";
import AccelerateSection from "./AccelerateSection";
import ScaleSection from "./ScaleSection";
import TransformSection from "./TransformSection";
import Dashboard from "../version-01/InitiativeDashboard";

interface PriorityMatrixProps {
  filteredInitiatives?: any[];
  selectedTowers?: string[];
  setSelectedTowers?: (
    towers: string[] | ((prev: string[]) => string[])
  ) => void;
}

export default function PriorityMatrix({ setHealthCounts }) {
  const [isOn, setIsOn] = useState(false);
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState(null);
  const towerOptions = [
    "Product & Development",
    "AI",
    "Breakthrough",
    "Cross GPT",
    "Enterprise Technology",
    "GPT Strat Ops",
    "Product Management & Ventures"
  ];
  const [selectedTowers, setSelectedTowers] = useState(towerOptions);
  const [selectedPriority, setSelectedPriority] = useState(null);
  const [selectedPriorities, setSelectedPriorities] = useState<string[]>([]);

  type Props = {
    setHealthCounts: React.Dispatch<
      React.SetStateAction<{
        overall: number;
        focus: number;
        accelerate: number;
        scale: number;
        transform: number;
      }>
    >;
  };

  // const statusItems = [
  //   { label: "On Track", color: "#10B981" },
  //   { label: "Needs Attention", color: "#F59E0B" },
  //   { label: "Off Track", color: "#EF4444" },
  //   { label: "Reset", color: "#9CA3AF" },
  // ];

  const isAllSelected = selectedTowers.length === towerOptions.length;

  const handleClearAll = () => {
    setSelectedTowers([]);
  };

  const handleTowerChange = (event) => {
    const value = event.target.value;

    // Select All logic inside dropdown
    if (value.includes("ALL")) {
      setSelectedTowers(isAllSelected ? [] : [...towerOptions]);
      return;
    }

    setSelectedTowers(typeof value === "string" ? value.split(",") : value);
  };

  const handleClear = () => {
    setSelectedTowers(towerOptions); // reset to ALL
  };

  const filteredData = () => {
    return initiatives.filter(
      (x) => selectedTowers.includes(x.towerTeam) || x.status === selectedStatus
    );
  };

  const getInitiatives = (priorityId: string, teamId: string) => {
    return initiatives.filter(
      (x) => x.priority === priorityId && x.team === teamId
    );
  };

  const getInitiativesV1 = (priorityId: string, teamId: string) => {
    return initiativesV1.filter(
      (x) => x.priority === priorityId && x.team === teamId
    );
  };

  // const teamColors = {
  //   Focus: "rgba(26, 115, 232, 0.125)",
  //   Accelerate: "rgba(123, 31, 162, 0.125)",
  //   Scale: "rgba(0, 151, 167, 0.125)",
  //   Transform: "rgba(230, 81, 0, 0.125)",
  // };

  const teamColors = {
    Focus: theme.tableHeaderBg,
    Accelerate: theme.tableHeaderBg,
    Scale: theme.tableHeaderBg,
    Transform: theme.tableHeaderBg,
  };

  const statusBg = {
    "On Track": {
      default: "rgba(30, 142, 62, 0.07)",
      hover: "rgba(30, 142, 62, 0.16)",
      active: "rgba(30, 142, 62, 0.24)",
    },
    "Off Track": {
      default: "rgba(217, 48, 37, 0.07)",
      hover: "rgba(217, 48, 37, 0.15)",
      active: "rgba(217, 48, 37, 0.22)",
    },
    "Needs Attention": {
      default: "rgba(242, 153, 0, 0.07)",
      hover: "rgba(242, 153, 0, 0.16)",
      active: "rgba(242, 153, 0, 0.24)",
    },
    Reset: {
      default: "rgba(107,114,128,0.07)",
      hover: "rgba(107,114,128,0.14)",
      active: "rgba(107,114,128,0.22)",
    },
  };

  const statusItems = [
    { label: "On Track", color: theme.onTrack },
    { label: "Off Track", color: theme.offTrack },
    { label: "Needs Attention", color: theme.attention },
    // { label: "Not Started", color: "#9CA3AF" },
    { label: "Reset", color: "#6B7280" }, // add reset
  ];

  const handleResetFilters = () => {
    setSelectedStatus(null);
    setSelectedTowers(towerOptions);
    setSelectedPriority(null);
    setSelectedPriorities([]);
  };

  // Filter your initiatives array dynamically based on the state
  // const filteredInitiatives = useMemo(() => {
  //   return initiatives.filter((item) => {
  //     const towerMatch =
  //       selectedTowers.length === 0 || selectedTowers.includes(item.towerTeam);

  //     const statusMatch = !selectedStatus || item.status === selectedStatus;

  //     const priorityMatch =
  //       selectedPriorities.length === 0 ||
  //       selectedPriorities.includes(item.priority);

  //     return towerMatch && statusMatch && priorityMatch && item.hasdata;
  //   });
  // }, [initiatives, selectedTowers, selectedStatus, selectedPriorities]);

  const filteredInitiatives = useMemo(() => {
    return initiatives.filter((item) => {
      const towerMatch = selectedTowers.includes(item.towerTeam);

      const statusMatch = !selectedStatus || item.status === selectedStatus;

      const priorityMatch =
        selectedPriorities.length === 0 ||
        selectedPriorities.includes(item.priority);

      return towerMatch && statusMatch && priorityMatch && item.hasdata;
    });
  }, [initiatives, selectedTowers, selectedStatus, selectedPriorities]);

  const handlePriorityChange = (priority: string) => {
    setSelectedPriorities((prev) =>
      prev.includes(priority)
        ? prev.filter((p) => p !== priority)
        : [...prev, priority]
    );
  };

  // Count based on currently visible cards (after all filters)
  const teamCounts = teams.reduce((acc, team) => {
    const count = filteredInitiatives.filter(
      (i) =>
        i.team === team.id && (!selectedStatus || i.status === selectedStatus)
    ).length;

    acc[team.name] = count;
    return acc;
  }, {} as Record<string, number>);

  // Total visible count
  const totalVisible = Object.values(teamCounts).reduce(
    (sum, count) => sum + count,
    0
  );

  // Health text
  const overallHealth =
    selectedStatus || (totalVisible > 0 ? "On Track" : "NA");

  useEffect(() => {
    const counts = teams.reduce(
      (acc, team) => {
        const visible = filteredInitiatives.filter(
          (i) =>
            i.team === team.id &&
            (!selectedStatus || i.status === selectedStatus)
        );

        acc.overall += visible.length;

        // Match your team names
        if (team.name === "Focus") acc.focus = visible.length;
        if (team.name === "Accelerate") acc.accelerate = visible.length;
        if (team.name === "Scale") acc.scale = visible.length;
        if (team.name === "Transform") acc.transform = visible.length;

        return acc;
      },
      {
        overall: 0,
        focus: 0,
        accelerate: 0,
        scale: 0,
        transform: 0,
      }
    );

    setHealthCounts(counts);
  }, [
    filteredInitiatives,
    selectedStatus,
    selectedTowers,
    selectedPriorities,
    teams,
  ]);

  const groupedInitiatives = useMemo(() => {
    return {
      Focus: filteredInitiatives.filter((i) => i.category === "Focus"),
      Accelerate: filteredInitiatives.filter(
        (i) => i.category === "Accelerate"
      ),
      Scale: filteredInitiatives.filter((i) => i.category === "Scale"),
      Transform: filteredInitiatives.filter((i) => i.category === "Transform"),
    };
  }, [filteredInitiatives]);

  const FilterSection = ({ children, divider = true }) => (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 1.5,
        pr: 2,
        mr: 2,

        ...(divider && {
          borderRight: "1px solid rgba(148,163,184,0.25)", // light divider
        }),

        minHeight: 34, // same divider height
      }}
    >
      {children}
    </Box>
  );

  return (
    <Box sx={{ overflow: "scroll" }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.8 }}>
        <Box
          sx={{
            display: "flex",
            gap: "5px",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box>
            <Typography
              variant="body2"
              sx={{
                lineHeight: "1.5",
                letterSpacing: "0.00938em",
                fontWeight: 700,
                color: "#010035",
                fontSize: "12px",
                marginRight: "20px",
              }}
            >
              Initiatives
            </Typography>
          </Box>
        </Box>

        {/* {!isOn && ( */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 1,
          }}
        >
          <Box
            display="flex"
            alignItems="center"
            gap={0.5}
            sx={{ marginRight: "20px" }}
          >
            <Typography
              sx={{
                fontSize: "10px",
                fontWeight: !isOn ? 700 : 400,
                opacity: !isOn ? 1 : 0.5,
                transition: "all 0.2s ease",
                color: "rgb(1 47 107 / 83%)",
              }}
            >
              Progress View
            </Typography>

            <Switch
              checked={isOn}
              onChange={(e) => {
                const checked = e.target.checked;

                setIsOn(checked);

                // Reset filters
                setSelectedStatus(null);
                setSelectedTowers(towerOptions);
                setSelectedPriority(null);
                setSelectedPriorities([]);
              }}
              size="small"
              sx={{
                transform: "scale(0.75)",
                m: 0,

                "& .MuiSwitch-switchBase.Mui-checked": {
                  color: "rgb(1 47 107 / 83%)",
                },

                "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                  backgroundColor: "rgb(1 47 107 / 33%)",
                  opacity: 1,
                },
              }}
            />

            <Typography
              sx={{
                fontSize: "10px",
                fontWeight: isOn ? 700 : 400,
                opacity: isOn ? 1 : 0.5,
                color: "rgb(1 47 107 / 83%)",
                transition: "all 0.2s ease",
              }}
            >
              Metrics View
            </Typography>
          </Box>
          <Box
            sx={{
              visibility: isOn ? "hidden" : "visible",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              flexWrap: "wrap",
              gap: 1,
            }}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0,
                flexWrap: "wrap",
                mr: 3,
              }}
            >
              {/* TITLE */}
              <Typography
                fontWeight={700}
                sx={{
                  fontSize: "10px",
                  color: theme.textPrimary,
                  whiteSpace: "nowrap",
                }}
              >
                Priority:
              </Typography>

              {/* {!isOn && ( */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 0.3,
                  // border: "1px solid #DCE3EC",
                  // borderRadius: 2,
                  bgcolor: "#FFF",
                  px: 0,
                  py: 0.5,
                  visibility: isOn ? "hidden" : "visible",
                }}
              >
                {["p1", "p2", "p3"].map((priority) => (
                  <Box
                    key={priority}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      // border: selectedPriorities.includes(priority)
                      //   ? "1px solid #333366"
                      //   : "1px solid #DCE3EC",
                      // borderRadius: 1,
                      px: 0.4,
                      py: 0.1,
                      bgcolor: selectedPriorities.includes(priority)
                        ? "#EEF2FF"
                        : "#FFF",
                    }}
                  >
                    <Checkbox
                      size="small"
                      checked={selectedPriorities.includes(priority)}
                      onChange={() => handlePriorityChange(priority)}
                      sx={{
                        p: 0.2,

                        color: "#9CA3AF",

                        "&.Mui-checked": {
                          color: "#333366",
                        },
                      }}
                    />

                    <Typography
                      sx={{
                        fontSize: "10px",
                        fontWeight: 600,
                        textTransform: "uppercase",
                        color: selectedPriorities.includes(priority)
                          ? "#333366"
                          : "#374151",
                      }}
                    >
                      {priority}
                    </Typography>
                  </Box>
                ))}
              </Box>
              {/* )} */}
            </Box>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
              }}
            >
              {/* Label */}
              <Typography
                sx={{
                  fontSize: 10,
                  fontWeight: 600,
                  color: theme.textSecondary,
                  minWidth: 75,
                  lineHeight: "40px", // align with dropdown
                }}
              >
                Filter By Tower:
              </Typography>

              <FormControl sx={{ width: 220 }} size="small">
                <Box sx={{ position: "relative", width: "100%" }}>
                  {!isAllSelected && (
                    <IconButton
                      size="small"
                      onClick={handleClearAll}
                      sx={{
                        position: "absolute",
                        right: 30,
                        top: "50%",
                        transform: "translateY(-50%)",
                        zIndex: 2,
                        p: 0.4,
                      }}
                    >
                      <CloseIcon sx={{ fontSize: 12 }} />
                    </IconButton>
                  )}

                  <Tooltip
                    title={
                      isAllSelected
                        ? "All"
                        : selectedTowers.length
                        ? selectedTowers.join(", ")
                        : ""
                    }
                    arrow
                    placement="top"
                  >
                    <Select
                      multiple
                      open={open}
                      onOpen={() => setOpen(true)}
                      onClose={() => setOpen(false)}
                      value={selectedTowers}
                      onChange={handleTowerChange}
                      displayEmpty
                      IconComponent={() => (
                        <KeyboardArrowDownIcon
                          sx={{
                            position: "absolute",
                            right: 8,
                            top: "50%",
                            transform: open
                              ? "translateY(-50%) rotate(180deg)"
                              : "translateY(-50%) rotate(0deg)",
                            transition: "0.3s",
                            color: "#d0271d",
                            fontSize: 18,
                          }}
                        />
                      )}
                      sx={{
                        width: "100%",
                        height: 30,
                        borderRadius: 0,
                        pr: 5,

                        "& .MuiSelect-select": {
                          height: "40px !important",
                          display: "flex",
                          alignItems: "center",
                          padding: "0 36px 0 10px !important",

                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",

                          fontSize: 11,
                        },

                        "& .MuiOutlinedInput-notchedOutline": {
                          borderColor: "#010035",
                        },

                        "&:hover .MuiOutlinedInput-notchedOutline": {
                          borderColor: "#010035",
                        },

                        "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                          borderColor: "#010035",
                          borderWidth: 1,
                        },

                        ...(open && {
                          boxShadow: "0 0 4px 2px #ae2019",
                        }),
                      }}
                      renderValue={() =>
                        isAllSelected
                          ? "All"
                          : selectedTowers.length
                          ? selectedTowers.join(", ")
                          : "Select"
                      }
                    >
                      <MenuItem value="ALL">
                        <Checkbox checked={isAllSelected} />
                        <ListItemText
                          primary="Select All"
                          primaryTypographyProps={{
                            fontSize: 10,
                          }}
                        />
                      </MenuItem>

                      {towerOptions.map((tower) => (
                        <MenuItem key={tower} value={tower}>
                          <Checkbox checked={selectedTowers.includes(tower)} />
                          <ListItemText
                            primary={tower}
                            primaryTypographyProps={{
                              fontSize: 10,
                            }}
                          />
                        </MenuItem>
                      ))}
                    </Select>
                  </Tooltip>
                </Box>
              </FormControl>
            </Box>
            {statusItems.map((item) => (
              <Box
                key={item.label}
                onClick={() =>
                  item.label === "Reset"
                    ? handleResetFilters()
                    : setSelectedStatus(item.label)
                }
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 0.5,
                  cursor: "pointer",
                  px: "5px",
                  py: 0.7,
                  borderRadius: 2,
                  transition: "all 0.2s ease",

                  backgroundColor:
                    item.label === "Reset"
                      ? "rgba(107,114,128,0.04)"
                      : selectedStatus === item.label && statusBg[item.label]
                      ? statusBg[item.label].active
                      : statusBg[item.label]?.default || "transparent",

                  border:
                    selectedStatus === item.label
                      ? `1px solid ${
                          item.label === "On Track"
                            ? "rgba(16, 185, 129, 0.6)"
                            : item.label === "Needs Attention"
                            ? "rgba(242, 153, 0, 0.6)"
                            : item.label === "Off Track"
                            ? "rgba(217, 48, 37, 0.6)"
                            : "rgba(107,114,128,0.6)"
                        }`
                      : "1px solid transparent",

                  "&:hover": {
                    backgroundColor:
                      item.label === "Reset"
                        ? "rgba(107,114,128,0.15)"
                        : selectedStatus === item.label
                        ? statusBg[item.label].active
                        : statusBg[item.label]?.hover || "rgba(0,0,0,0.04)",

                    border:
                      selectedStatus === item.label
                        ? `1px solid ${
                            item.label === "On Track"
                              ? "rgba(16, 185, 129, 0.8)"
                              : item.label === "Needs Attention"
                              ? "rgba(242, 153, 0, 0.8)"
                              : item.label === "Off Track"
                              ? "rgba(217, 48, 37, 0.8)"
                              : "rgba(107,114,128,0.8)"
                          }`
                        : "1px solid transparent",
                  },
                }}
              >
                {/* Icon / dot */}
                {item.label === "Reset" ? (
                  <RestartAltIcon sx={{ fontSize: 12, color: "#6B7280" }} />
                ) : (
                  <Box
                    sx={{
                      width: 6,
                      height: 6,
                      borderRadius: "50%",
                      bgcolor: item.color,
                    }}
                  />
                )}

                <Typography
                  variant="caption"
                  sx={{
                    // width: "45px",
                    fontSize: 9,
                    fontWeight: selectedStatus === item.label ? 700 : 500,
                  }}
                >
                  {item.label}
                </Typography>
              </Box>
            ))}
          </Box>
        </Box>
        {/* )} */}
      </Box>
      {!isOn ? (
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: 1,
            alignItems: "start",
          }}
        >
          {teams.map((team) => {
            const visibleInitiatives = filteredInitiatives.filter(
              (i) =>
                i.team === team.id &&
                (!selectedStatus || i.status === selectedStatus)
            );

            return (
              <Box
                key={team.id}
                // sx={{
                //   border: "1px solid #DCE3EC",
                //   borderRadius: 2,
                //   bgcolor: "#f5f7fb",
                //   height: "fit-content",
                // }}
              >
                <Box p={1}>
                  {/* HEADER */}
                  <Paper
                    sx={{
                      p: 0.5,
                      textAlign: "center",
                      bgcolor: teamColors[team.name] || "#757575",
                      color: "#fff",
                      borderRadius: 1,
                      mb: 1.25,
                      display:"flex",
                      justifyContent:"space-between",
                      alignItems:"center"
                    }}
                  >
                    <Typography
                      fontWeight={700}
                      sx={{
                        fontSize: "11px",
                      }}
                    >
                      {team.name}
                    </Typography>
                    {/* <Typography
                      fontWeight={700}
                      sx={{
                        fontSize: "11px",
                      }}
                    >
                      {visibleInitiatives.length}
                    </Typography> */}
                    <Box sx={{
                      bgcolor:"rgba(255,255,255,0.25)",
                      borderRadius:"50%",
                      width:28,
                      height:28,
                      display:"flex",
                      alignItems:"center",
                      justifyContent:"center",
                      fontSize:"12px",
                      fontWeight:700
                    }}
                    >
                      {visibleInitiatives.length}
                    </Box>
                  </Paper>

                  {/* CONTENT */}
                  {visibleInitiatives.length > 0 ? (
                    <Card
                      key={team.id}
                      sx={{
                        border: "1px solid #DCE3EC",
                        borderRadius: 2,
                        bgcolor: "#f5f7fb",
                        height: "fit-content",
                        p: 1,
                      }}
                    >
                      <Stack spacing={1}>
                        {visibleInitiatives.map((initiative) => (
                          <Box key={initiative.id}>
                            <Paper
                              sx={{
                                p: 1,
                                border: "1px solid #E4E7EC",
                                bgcolor: "#fff",
                                borderRadius: 1.5,
                                height: "fit-content",
                              }}
                            >
                              <InitiativeCell
                                initiatives={[initiative]}
                                selectedStatus={selectedStatus}
                                selectedTowers={selectedTowers}
                                selectedPriorities={selectedPriorities}
                              />
                            </Paper>
                          </Box>
                        ))}
                      </Stack>
                    </Card>
                  ) : (
                    <Paper
                      sx={{
                        minHeight: 80,
                        border: "1px dashed #D0D7E2",
                        borderRadius: 1.5,
                        bgcolor: "#fff",

                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Typography
                        sx={{
                          fontSize: 10,
                          color: "#94A3B8",
                          fontWeight: 600,
                        }}
                      >
                        NA
                      </Typography>
                    </Paper>
                  )}
                </Box>
              </Box>
            );
          })}
        </Box>
      ) : (
        //  <PillarOverview />
        <Dashboard />
      )}
    </Box>
  );
}
