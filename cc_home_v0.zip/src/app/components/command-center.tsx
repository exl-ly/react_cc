import { AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import type { Initiative, Pillar, Status } from "../data/initiatives";
import { useTheme } from "../theme-context";

interface CommandCenterProps {
  initiatives: Initiative[];
  activeTower: string | null;
  onTowerSelect: (tower: string) => void;
  activePriority: string | null;
  onPrioritySelect: (priority: string) => void;
  onSelectInitiative: (ini: Initiative) => void;
}

const PRIORITIES: { key: Initiative["priority"]; tier: string }[] = [
  { key: "Critical", tier: "P1" },
  { key: "High", tier: "P2" },
  { key: "Medium", tier: "P3" },
];

const PRIORITY_TIER: Record<string, string> = {
  Critical: "P1",
  High: "P2",
  Medium: "P3",
};

const PRIORITY_RANK: Record<string, number> = {
  Critical: 0,
  High: 1,
  Medium: 2,
};

const STATUS_RANK: Record<Status, number> = {
  "off-track": 0,
  attention: 1,
  "on-track": 2,
};

const STATUS_LABEL: Record<Status, string> = {
  "on-track": "On Track",
  "off-track": "Off Track",
  attention: "Needs Attention",
};

const PILLAR_LETTER: Record<Pillar, string> = {
  Focus: "F",
  Acceleration: "A",
  Scale: "S",
  Transform: "T",
};

type Theme = ReturnType<typeof useTheme>["theme"];

function statusCounts(items: Initiative[]) {
  return {
    on: items.filter((i) => i.status === "on-track").length,
    att: items.filter((i) => i.status === "attention").length,
    off: items.filter((i) => i.status === "off-track").length,
  };
}

function healthColor(items: Initiative[], theme: Theme) {
  if (items.length === 0) return theme.textTertiary;
  if (items.some((i) => i.status === "off-track")) return theme.offTrack;
  if (items.some((i) => i.status === "attention")) return theme.attention;
  return theme.onTrack;
}

function SectionTitle({ children, theme }: { children: React.ReactNode; theme: Theme }) {
  return (
    <div
      style={{
        color: theme.textTertiary,
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        marginBottom: 8,
      }}
    >
      {children}
    </div>
  );
}

export function CommandCenter({
  initiatives,
  activeTower,
  onTowerSelect,
  activePriority,
  onPrioritySelect,
  onSelectInitiative,
}: CommandCenterProps) {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";

  const towers = Array.from(new Set(initiatives.map((i) => i.tower)));

  const cardBase: React.CSSProperties = {
    background: theme.surface,
    border: `1px solid ${theme.border}`,
    borderRadius: 9,
    boxShadow: isLight ? "0 1px 2px rgba(60,64,67,0.05)" : "none",
  };

  const topAttention = [...initiatives]
    .filter((i) => i.status !== "on-track")
    .sort((a, b) => {
      const s = STATUS_RANK[a.status] - STATUS_RANK[b.status];
      if (s !== 0) return s;
      return PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority];
    })
    .slice(0, 3);

  return (
    <div style={{ padding: "16px 16px 0", display: "flex", flexDirection: "column", gap: 16 }}>
      {/* Top Attention Items */}
      <div>
        <SectionTitle theme={theme}>Top Attention Items</SectionTitle>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {topAttention.length === 0 ? (
            <div style={{ ...cardBase, padding: "12px 14px", color: theme.textTertiary, fontSize: 12 }}>
              No off-track or attention initiatives.
            </div>
          ) : (
            topAttention.map((ini) => {
              const color = ini.status === "off-track" ? theme.offTrack : theme.attention;
              const Icon = ini.status === "off-track" ? XCircle : AlertTriangle;
              return (
                <button
                  key={ini.name}
                  onClick={() => onSelectInitiative(ini)}
                  title="Open in portfolio table"
                  style={{
                    ...cardBase,
                    borderLeft: `3px solid ${color}`,
                    padding: "9px 14px",
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    cursor: "pointer",
                    textAlign: "left",
                    fontFamily: "inherit",
                  }}
                >
                  <span style={{ color: theme.textTertiary, fontSize: 11, fontFamily: "var(--font-mono)", whiteSpace: "nowrap" }}>
                    {ini.tower} / {PRIORITY_TIER[ini.priority]} / {PILLAR_LETTER[ini.pillar]} {ini.pillar}
                  </span>
                  <span style={{ color: theme.textPrimary, fontSize: 13, fontWeight: 600, flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {ini.name}
                  </span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 5, color, fontSize: 11, fontWeight: 600, whiteSpace: "nowrap" }}>
                    <Icon size={11} color={color} strokeWidth={2.5} />
                    {STATUS_LABEL[ini.status]}
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Business Tower Health */}
      <div>
        <SectionTitle theme={theme}>Business Tower Health</SectionTitle>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {towers.map((tower) => {
            const items = initiatives.filter((i) => i.tower === tower);
            const c = statusCounts(items);
            const dot = healthColor(items, theme);
            const active = activeTower === tower;
            return (
              <button
                key={tower}
                onClick={() => onTowerSelect(tower)}
                title={`Filter by tower: ${tower}`}
                style={{
                  ...cardBase,
                  borderColor: active ? theme.brandPrimary : theme.border,
                  boxShadow: active ? `0 0 0 2px ${theme.brandPrimary}22` : cardBase.boxShadow,
                  padding: "10px 12px",
                  minWidth: 180,
                  flex: "1 1 180px",
                  textAlign: "left",
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ width: 9, height: 9, borderRadius: "50%", background: dot, flexShrink: 0 }} />
                  <span style={{ color: theme.textPrimary, fontSize: 13, fontWeight: 600, flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {tower}
                  </span>
                  <span style={{ color: theme.textSecondary, fontSize: 12, fontWeight: 700, fontFamily: "var(--font-mono)" }}>
                    {items.length}
                  </span>
                </div>
                <div style={{ marginTop: 5, fontSize: 10, color: theme.textTertiary }}>
                  <span style={{ color: theme.onTrack, fontWeight: 600 }}>{c.on} On</span>
                  {" · "}
                  <span style={{ color: theme.attention, fontWeight: 600 }}>{c.att} Att</span>
                  {" · "}
                  <span style={{ color: theme.offTrack, fontWeight: 600 }}>{c.off} Off</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Priority x Tower Heatmap */}
      <div>
        <SectionTitle theme={theme}>Priority x Tower Heatmap</SectionTitle>
        <div
          style={{
            ...cardBase,
            padding: 10,
            display: "grid",
            gridTemplateColumns: `minmax(96px, 0.7fr) repeat(${towers.length}, 1fr)`,
            gap: 6,
          }}
        >
          <div />
          {towers.map((tower) => (
            <div
              key={tower}
              title={tower}
              style={{ color: theme.textTertiary, fontSize: 10, fontWeight: 700, textAlign: "center", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", padding: "0 4px" }}
            >
              {tower}
            </div>
          ))}

          {PRIORITIES.map((p) => (
            <Row
              key={p.key}
              priority={p}
              towers={towers}
              initiatives={initiatives}
              theme={theme}
              isLight={isLight}
              activePriority={activePriority}
              activeTower={activeTower}
              onPrioritySelect={onPrioritySelect}
              onTowerSelect={onTowerSelect}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function Row({
  priority,
  towers,
  initiatives,
  theme,
  isLight,
  activePriority,
  activeTower,
  onPrioritySelect,
  onTowerSelect,
}: {
  priority: { key: Initiative["priority"]; tier: string };
  towers: string[];
  initiatives: Initiative[];
  theme: Theme;
  isLight: boolean;
  activePriority: string | null;
  activeTower: string | null;
  onPrioritySelect: (priority: string) => void;
  onTowerSelect: (tower: string) => void;
}) {
  return (
    <>
      <div style={{ display: "flex", alignItems: "center", color: theme.textSecondary, fontSize: 11, fontWeight: 600 }}>
        <span style={{ color: theme.textPrimary, fontWeight: 800, marginRight: 6 }}>{priority.tier}</span>
        {priority.key}
      </div>
      {towers.map((tower) => {
        const items = initiatives.filter((i) => i.priority === priority.key && i.tower === tower);
        const dot = healthColor(items, theme);
        const active = activePriority === priority.key && activeTower === tower;
        return (
          <button
            key={tower}
            onClick={() => {
              onPrioritySelect(priority.key);
              onTowerSelect(tower);
            }}
            title={`${priority.tier} ${priority.key} - ${tower}: ${items.length}`}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
              padding: "6px 4px",
              borderRadius: 7,
              border: active ? `1.5px solid ${theme.brandPrimary}` : `1px solid ${theme.border}`,
              background: active
                ? `${theme.brandPrimary}14`
                : isLight
                  ? "rgba(0,0,0,0.015)"
                  : "rgba(255,255,255,0.02)",
              cursor: items.length ? "pointer" : "default",
              fontFamily: "inherit",
              opacity: items.length ? 1 : 0.55,
            }}
          >
            <span style={{ width: 8, height: 8, borderRadius: "50%", background: dot, flexShrink: 0 }} />
            <span style={{ color: theme.textPrimary, fontSize: 12, fontWeight: 700, fontFamily: "var(--font-mono)" }}>
              {items.length}
            </span>
          </button>
        );
      })}
    </>
  );
}
