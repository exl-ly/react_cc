import { Box, Typography } from "@mui/material";
import InitiativeCard from "./InitiativeCard";
import { Initiative } from "../../data/types";

interface Props {
  initiatives: Initiative[];
}

export default function InitiativeCell({ initiatives, selectedStatus, selectedTowers }: Props) {

  const filteredInitiatives = initiatives.filter(
    (item) =>
      selectedTowers.includes(item.towerTeam) &&
      (item.status === selectedStatus || !selectedStatus) && item.hasdata === true
  );
  return (
    <Box
      sx={{
        // minHeight: 30,
        display: "flex",
        flexDirection: "column",
        gap: 1,
        // p: 1,
      }}
    >
      {filteredInitiatives.length > 0 ? (
        filteredInitiatives.map((item) => (
          <InitiativeCard
            key={item.id}
            initiative={item}
            selectedStatus={selectedStatus}
            selectedTowers={selectedTowers}
          />
        ))
      ) : (
        <Box
          sx={{
            minHeight: 64,
            maxHeight: 66,
            padding: "4px 5px",

            // 1. Core Centering Properties
            display: "flex",
            alignItems: "center",
            justifyContent: "center",

            // border: "1px solid #E2E8F0",
            borderRadius: "5px",
            backgroundColor: "#fff",
            boxSizing: "border-box",
          }}
        >
          {/* 2. Direct Child without the unnecessary inner Box */}
          <Typography variant="body2" sx={{ fontSize: "10px" }}>
            NA
          </Typography>
        </Box>
      )}
    </Box>
  );
}
