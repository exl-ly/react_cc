import { Card, Chip, Typography, Stack, Box, Tooltip } from "@mui/material";
import { InitiativeV1 } from "../../data/typesTower";
import WarningIcon from "@mui/icons-material/Warning";
import CommentIcon from "@mui/icons-material/Comment";

const towerColors = {
  Focus: "rgb(26, 115, 232)",
  Accelerate: "rgb(123, 31, 162)",
  Scale: "rgb(0, 151, 167)",
  Transform: "rgb(230, 81, 0)",
};

const towerBorders = {
  Focus: "1px solid rgba(26, 115, 232, 0.25)",
  Accelerate: "1px solid rgba(123, 31, 162, 0.25)",
  Scale: "1px solid rgba(0, 151, 167, 0.25)",
  Transform: "1px solid rgba(230, 81, 0, 0.25)",
};

const towerBGColors = {
  Focus: "rgba(26, 115, 232, 0.082)",
  Accelerate: "rgba(123, 31, 162, 0.082)",
  Scale: "rgba(0, 151, 167, 0.082)",
  Transform: "rgba(230, 81, 0, 0.082)",
};

interface Props {
  initiative: InitiativeV1;
}

export default function InitiativeCardV1({
  initiative,
  selectedStatus,
}: Props) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "On Track":
        return "#34A853";
      case "Needs Attention":
        return "#FB8C00";
      case "Off Track":
        return "#EA4335";
      default:
        return "#9AA0A6"; // Not Started
    }
  };
  const showData = !selectedStatus || initiative.status === selectedStatus;

  return (
    <>
      {initiative.hasdata === true && showData ? (
        <Box
          sx={{
            minHeight: 64,
            maxHeight: 66,
            padding: "4px 5px",

            display: "flex",
            alignItems: "start",

            border: "1px solid #E2E8F0", // card border
            borderRight: `6px solid ${getStatusColor(initiative.status)}`, // status border
            borderRadius: "5px",
            backgroundColor: "#fff",
            boxSizing: "border-box",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              gap: 0.2,
              width: "100%",
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "start",
                gap: 0.5,
                width: "100%",
              }}
            >
              <Typography
                variant="subtitle2"
                sx={{
                  fontWeight: 600,
                  fontSize: "10px",
                  lineHeight: 1.4,
                  mb: 0.5,
                  color: "rgb(95, 99, 104)",
                }}
              >
                {initiative.name}
              </Typography>
              {initiative.error === true && (
                <Tooltip
                  title="Immediate attention required"
                  arrow
                  slotProps={{
                    tooltip: {
                      sx: {
                        fontSize: "10px",
                      },
                    },
                  }}
                >
                  <WarningIcon
                    sx={{
                      color: "#ef4444",
                      fontSize: "17px",
                      cursor: "pointer",
                      flexShrink: 0,
                    }}
                  />
                </Tooltip>
              )}
            </Box>

            <Typography
              variant="caption"
              // color="text.secondary"
              sx={{
                fontSize: "10px",
                lineHeight: 1.4,
                mb: 0.5,
              }}
            >
              FAST Pillar: {initiative.tower}
            </Typography>

            <Typography
              variant="caption"
              color="text.secondary"
              sx={{
                fontSize: "9px",
                lineHeight: 1.1,
                mt: 0.2,
              }}
            >
              Leader: {initiative.owner}
            </Typography>

            <Box
              sx={{
                alignItems: "right",
                textAlign: "right",
                position: "relative",
                bottom: "15px",
              }}
            >
              <CommentIcon sx={{ fontSize: "16px" }} />
            </Box>
          </Box>
        </Box>
      ) : (
        <Box
          sx={{
            minHeight: 64,
            maxHeight: 66,
            padding: "4px 5px",

            // 1. Core Centering Properties
            display: "flex",
            alignItems: "center",
            justifyContent: "center",

            border: "1px solid #E2E8F0",
            borderRadius: "5px",
            backgroundColor: "#fff",
            boxSizing: "border-box",
          }}
        >
          {/* 2. Direct Child without the unnecessary inner Box */}
          <Typography variant="body2" sx={{ fontSize: "10px" }}>
            NA
          </Typography>
        </Box>
      )}
    </>
  );
}
