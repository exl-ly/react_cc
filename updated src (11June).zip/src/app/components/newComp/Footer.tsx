import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  Stack,
  IconButton,
} from "@mui/material";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import { useNavigate } from "react-router-dom";

export default function Footer() {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        width: "100%",
        padding: "0 10px",
        background: "#fff",
        boxShadow: "none",
        borderRadius: "5px",
      }}
    >
      <Card
        elevation={0}
        sx={{
          margin: "10px 0 0",
          padding: "5px",
          border: "1px solid #E5E7EB",
          borderRadius: "5px",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Stack direction="row" spacing={1} alignItems="center">
            <IconButton
              sx={{
                width: "fit-content",
                borderRadius: 2,
                bgcolor: "#eef5ff",
                border: "1px solid #d7e7ff",
              }}
            >
              <GridViewRoundedIcon sx={{ color: "#d0271d" }} />
            </IconButton>

            <Box>
              <Typography fontWeight={700} fontSize={12}>
                Explore the full strategic portfolio
              </Typography>
              <Typography color="text.secondary" fontSize={8}>
                Dive deeper into initiatives across all towers.
              </Typography>
            </Box>
          </Stack>

          <Button
            variant="contained"
            endIcon={<ArrowForwardRoundedIcon />}
            onClick={() => navigate("/cockpit-view")}
            sx={{
              textTransform: "none",
              borderRadius: 1.5,
              px: 2,
              py: 0,
              fontWeight: 600,
              fontSize: "10px",
              bgcolor: "#d0271d",
              height: "30px",
              "&:hover": {
                bgcolor: "#f90e00",
              },
            }}
          >
            Open Detailed View
          </Button>
        </Box>
      </Card>
    </Box>
  );
}
