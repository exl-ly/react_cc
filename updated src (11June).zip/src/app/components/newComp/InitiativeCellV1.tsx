import { Box } from "@mui/material";
import { InitiativeV1 } from "../../data/typesTower";
import InitiativeCardV1 from "./InitiativeCardV1";

interface Props {
  initiatives: InitiativeV1[];
}

export default function InitiativeCellV1({
  initiatives,
  selectedStatus,
}: Props) {
  return (
    <Box
      sx={{
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        gap: 0,
        p: 0,
      }}
    >
      {initiatives.map((item) => (
        <InitiativeCardV1
          key={item.id}
          initiative={item}
          selectedStatus={selectedStatus}
        />
      ))}
    </Box>
  );
}
