import React from "react";
import { Box, Typography, Paper, Stack, Avatar } from "@mui/material";

import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import WarningIcon from "@mui/icons-material/Warning";
import ErrorIcon from "@mui/icons-material/Error";
import AppsIcon from "@mui/icons-material/Apps";
import BoltIcon from "@mui/icons-material/Bolt";
import GroupsIcon from "@mui/icons-material/Groups";
import SettingsSuggestIcon from "@mui/icons-material/SettingsSuggest";
import MemoryIcon from "@mui/icons-material/Memory";

import FilterCenterFocusIcon from "@mui/icons-material/FilterCenterFocus";
import SpeedIcon from "@mui/icons-material/Speed";
import AspectRatioIcon from "@mui/icons-material/AspectRatio";
import TransformIcon from "@mui/icons-material/Transform";

import healthData from "../../data/dashboard-new.json";
import LinearProgress from "@mui/material/LinearProgress";

const icons: Record<string, React.ReactNode> = {
  Focus: <FilterCenterFocusIcon sx={{ fontSize: 30 }} />,
  Accelerate: <SpeedIcon sx={{ fontSize: 20 }} />,
  Scale: <AspectRatioIcon sx={{ fontSize: 20 }} />,
  Transform: <TransformIcon sx={{ fontSize: 20 }} />,

  FAST: <BoltIcon sx={{ fontSize: 14 }} />,
  People: <GroupsIcon sx={{ fontSize: 14 }} />,
  Process: <SettingsSuggestIcon sx={{ fontSize: 14 }} />,
  Technology: <MemoryIcon sx={{ fontSize: 14 }} />,
};

const TransformationHealth = () => {
  const { overallHealth, cards } = healthData;
  const pillarCards = ["Focus", "Accelerate", "Scale", "Transform"];
  return (
    <Paper
      elevation={0}
      sx={{
        width: "100%",
        borderRadius: 2,
        // border: "1px solid #E5E7EB",
        // overflow: "hidden",
        background: "#fff",
        padding: "10px",
      }}
    >
      <Box
        sx={{
          display: "flex",
          gap: 1,
          alignItems: "stretch",
          width: "100%",
        }}
      >
        {/* Overall Health Card */}
        <Box
          sx={{
            p: 1,
            border: "1px solid #E5E7EB",
            borderRadius: 2,
            bgcolor: "#fff",
            height: 55,
            width: 215,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between", // Pushes title to the left and status to the right
          }}
        >
          {/* Title on the left */}
          <Typography
            fontWeight={700}
            sx={{ color: "rgb(32, 33, 36)", fontSize: "12.5px" }}
          >
            {overallHealth.title}
          </Typography>

          {/* Status group (circle + text) on the right */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1, // Adds a clean space between the circle and "On Track" text
            }}
          >
            <Box
              sx={{
                width: 14,
                height: 14,
                borderRadius: "50%",
                backgroundColor: "#34A853",
              }}
            />
            <Typography
              variant="body2"
              sx={{ fontSize: "12px", color: "#34A853", fontWeight: 800 }}
            >
              On Track
            </Typography>
          </Box>
        </Box>

        {/* KPI Cards */}
        {cards.map((card) => (
          <Box
            key={card.label}
            sx={{
              p: 1,
              border: "1px solid #E5E7EB",
              borderRadius: 2,
              bgcolor: "#fff",
              flex: pillarCards.includes(card.label) ? 1.2 : 0.8,
              minWidth: pillarCards.includes(card.label) ? 110 : 120,
              height: 55,
              // Key additions for vertical centering
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}
          >
            <Stack direction="row" spacing={0.5} alignItems="center">
              <Avatar
                sx={{
                  width: 20,
                  height: 20,
                  bgcolor: card.color,
                  "& svg": {
                    fontSize: 10,
                  },
                }}
              >
                {icons[card.label]}
              </Avatar>

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Typography
                  fontWeight={700}
                  sx={{ color: "rgb(32, 33, 36)", fontSize: "12.5px" }}
                >
                  {card.label}
                </Typography>

                <Typography
                  fontSize={12}
                  fontWeight={400}
                  sx={{ color: "#333" }}
                >
                  {card.totStats}
                </Typography>
              </Box>
            </Stack>

            <Typography
              fontSize={20}
              fontWeight={700}
              noWrap
              sx={{
                textAlign: "left",
                // Changed hardcoded margins to a clean, small gap spacing
                mt: card.value === null ? 0 : 0.5,
              }}
            >
              {card.value}
            </Typography>
          </Box>
        ))}
      </Box>
    </Paper>
  );
};

export default TransformationHealth;
