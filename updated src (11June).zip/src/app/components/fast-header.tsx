import { Sun, Moon } from "lucide-react";
import type { Initiative } from "../data/initiatives";
import { useTheme } from "../theme-context";
import {
  Box,
  Button,
  FormControlLabel,
  Switch,
  Tooltip,
  Typography,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import { useNavigate } from "react-router-dom";
import adplogo from "../../images/adp-logo.jpg";

interface FastHeaderProps {
  initiatives: Initiative[];
  filteredInitiatives: Initiative[];
  activePillar?: string | null;
  onPillarFilter?: (pillar: string | null) => void;
  activeStatus?: string | null;
  onStatusFilter?: (status: string | null) => void;
}

const FAST_PILLARS = [
  {
    key: "All",
    letter: "A",
    full: "All Strategic Initiatives",
    sub: "Portfolio Overview",
    pillarKey: "pillarFast" as const,
  },
  {
    key: "Focus",
    letter: "F",
    full: "Focus",
    sub: "BU & Functional Priorities",
    pillarKey: "pillarFast" as const,
  },
  {
    key: "Acceleration",
    letter: "A",
    full: "Accelerate",
    sub: "Product Portfolio Impact",
    pillarKey: "pillarAccel" as const,
  },
  {
    key: "Scale",
    letter: "S",
    full: "Scale",
    sub: "GPT Led Growth Bets",
    pillarKey: "pillarScale" as const,
  },
  {
    key: "Transform",
    letter: "T",
    full: "Transform",
    sub: "GPT Operations & Engagement",
    pillarKey: "pillarTrans" as const,
  },
];

export function FastHeader({
  initiatives,
  filteredInitiatives,
  activePillar,
  onPillarFilter,
  activeStatus,
  onStatusFilter,
}: FastHeaderProps) {
  const { theme, toggle } = useTheme();
  const pool = initiatives;
  const navigate = useNavigate();
  const totals = {
    all: pool.length,
    onTrack: pool.filter((i) => i.status === "on-track").length,
    offTrack: pool.filter((i) => i.status === "off-track").length,
    attention: pool.filter((i) => i.status === "attention").length,
  };

  const isLight = theme.mode === "light";
  console.log("filteredInitiatives", filteredInitiatives);

  return (
    <div
      style={{
        background: theme.surface,
        borderBottom: `1px solid ${theme.border}`,
      }}
    >
      {/* Top bar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "10px 8px 10px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {/* ADP-style logo bar */}
          {/* <div style={{ display: "flex", alignItems: "center", gap: 2 }}>
            {["#4285f4", "#ea4335", "#fbbc04", "#34a853"].map((c, i) => (
              <div
                key={i}
                style={{ width: 4, height: 28, background: c, borderRadius: 2 }}
              />
            ))}
          </div> */}
          <img
            src={adplogo}
            alt="ADP-Logo"
            style={{ width: "60px", height: "26px" }}
          />

          <div>
            <div
              style={{
                color: theme.textPrimary,
                fontSize: 15,
                fontWeight: 500,
                letterSpacing: "0.01em",
                lineHeight: 1.3,
              }}
            >
              Command Center Cockpit
            </div>
            <div
              style={{
                color: theme.textTertiary,
                fontSize: 11,
                marginTop: 1,
                letterSpacing: "0.02em",
              }}
            >
              Strategic Initiative Dashboard · FY2026
            </div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
          {/* Summary stats */}

          <Button
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate("/")}
            sx={{
              textTransform: "none",
              color: "#006be6",
              fontWeight: 600,
              p: 0,
              minWidth: "auto",
            }}
          >
            Back
          </Button>
          <div style={{ display: "flex", gap: 4 }}>
            {[
              {
                label: "Total",
                value: totals.all,
                color: theme.textSecondary,
                bg: isLight ? "#f1f3f4" : theme.surface,
                key: null,
              },
              {
                label: "On Track",
                value: totals.onTrack,
                color: theme.onTrack,
                bg: theme.onTrackBg,
                key: "on-track",
              },
              {
                label: "Off Track",
                value: totals.offTrack,
                color: theme.offTrack,
                bg: theme.offTrackBg,
                key: "off-track",
              },
              {
                label: "Needs Attention",
                value: totals.attention,
                color: theme.attention,
                bg: theme.attentionBg,
                key: "attention",
              },
            ].map((s) => {
              const isActive =
                s.key === null ? activeStatus === null : activeStatus === s.key;

              return (
                <button
                  key={s.label}
                  onClick={() => onStatusFilter?.(isActive ? null : s.key)}
                  title={
                    s.key === null
                      ? "Show all statuses"
                      : `Filter by ${s.label}`
                  }
                  style={{
                    textAlign: "center",
                    padding: "6px 5px",
                    borderRadius: 8,
                    background: s.bg,
                    minWidth: "75px",
                    maxWidth: "75px",
                    border: isActive
                      ? `1.5px solid ${s.color}`
                      : `1px solid ${theme.border}`,
                    cursor: "pointer",
                    transition: "all 0.15s ease",
                    boxShadow: isActive ? `0 0 0 2px ${s.color}22` : "none",
                    outline: "none",
                  }}
                  onMouseEnter={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.border = `1px solid ${s.color}`;
                      e.currentTarget.style.boxShadow = `0 2px 8px ${s.color}22`;
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.border = `1px solid ${theme.border}`;
                      e.currentTarget.style.boxShadow = "none";
                    }
                  }}
                >
                  <div
                    style={{
                      color: s.color,
                      fontSize: 20,
                      fontWeight: 700,
                      lineHeight: 1,
                      letterSpacing: "-0.02em",
                    }}
                  >
                    {s.value}
                  </div>
                  <div
                    style={{
                      color: theme.textTertiary,
                      fontSize: 8,
                      marginTop: 3,
                      fontWeight: 500,
                      letterSpacing: "0.02em",
                    }}
                  >
                    {s.label}
                  </div>
                </button>
              );
            })}
          </div>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {/* <Tooltip title="Switch to FAST View" arrow placement="bottom">
              <Box
                onClick={() => navigate("/")}
                sx={{
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: "10px",
                  background:
                    "linear-gradient(145deg, #7dd3fc 0%, #3b82f6 45%, #1d4ed8 100%)",
                  border: "2px solid rgba(255,255,255,0.5)",
                  boxShadow: `
                  inset 0 2px 6px rgba(255,255,255,0.6),
                  inset 0 4px 2px rgba(0,0,0,0.2),
                  0 2px 5px rgba(29,78,216,0.35)
                `,
                  position: "relative",
                  overflow: "hidden",
                  transition: "all 0.25s ease",

                  "&::before": {
                    content: '""',
                    position: "absolute",
                    top: 6,
                    left: 10,
                    right: 10,
                    height: "40%",
                    borderRadius: "50%",
                    background:
                      "linear-gradient(to bottom, rgba(255,255,255,0.7), rgba(255,255,255,0.05))",
                  },

                  "&:hover": {
                    background:
                      "linear-gradient(145deg, #2563eb 0%, #1d4ed8 45%, #1e3a8a 100%)",
                    transform: "translateY(-2px)",
                  },
                }}
              >
                <Box
                  sx={{
                    color: "#fff",
                    fontSize: 10,
                    fontWeight: 800,
                    textShadow: "0 2px 4px rgba(0,0,0,0.3)",
                    zIndex: 1,
                    userSelect: "none",
                  }}
                >
                  F
                </Box>
              </Box>
            </Tooltip> */}
            <div
              style={{
                padding: "5px 10px",
                background: theme.brandPrimaryBg,
                borderRadius: 6,
                color: theme.brandPrimaryText,
                fontSize: 11,
                fontFamily: "var(--font-mono)",
                border: `1px solid ${theme.chipActiveBorder}`,
                fontWeight: 500,
              }}
            >
              Live ·{" "}
              {new Date().toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
                year: "numeric",
              })}
            </div>
          </Box>

          {/* Theme toggle */}
          {/* <button
            onClick={toggle}
            title={`Switch to ${theme.mode === "dark" ? "light" : "dark"} mode`}
            style={{
              width: 36,
              height: 36,
              borderRadius: 18,
              border: `1px solid ${theme.border}`,
              background: theme.surface,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: theme.textSecondary,
              boxShadow: theme.shadow,
              transition: "all 0.2s",
            }}
          >
            {theme.mode === "dark" ? <Sun size={15} /> : <Moon size={15} />}
          </button> */}
        </div>
      </div>

      {/* FAST CARDS */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "85px repeat(4, 1fr)",
          borderTop: `1px solid ${theme.divider}`,
        }}
      >
        {FAST_PILLARS.map((p, idx) => {
          const isAll = p.key === "All";
          const group = isAll ? pool : pool.filter((i) => i.pillar === p.key);

          const total = group.length;
          const onTrack = group.filter((i) => i.status === "on-track").length;
          const offTrack = group.filter((i) => i.status === "off-track").length;
          const attention = group.filter(
            (i) => i.status === "attention"
          ).length;

          const isActive = activePillar === p.key || (isAll && !activePillar);

          const color = isAll
            ? isLight
              ? "#5f6368"
              : "#9aa0a6"
            : theme[p.pillarKey];

          const badgeBg = isAll
            ? isLight
              ? "#f1f3f4"
              : "rgba(154,160,166,0.14)"
            : `${color}18`;

          const activeBg = isActive
            ? isAll
              ? isLight
                ? "rgba(95,99,104,0.12)"
                : "rgba(154,160,166,0.16)"
              : `${color}20`
            : "transparent";

          const hoverBg = isActive
            ? isAll
              ? isLight
                ? "rgba(95,99,104,0.15)"
                : "rgba(154,160,166,0.20)"
              : `${color}25`
            : isAll
            ? isLight
              ? "rgba(95,99,104,0.08)"
              : "rgba(154,160,166,0.10)"
            : `${color}12`; // was 08

          const topLineColor = isAll
            ? isLight
              ? "#dadce0"
              : theme.divider
            : color;

          return (
            <div
              key={p.key}
              onClick={() => onPillarFilter?.(isAll ? null : p.key)}
              style={{
                padding: isAll ? "10px 12px" : "12px 18px",
                borderRight:
                  idx < FAST_PILLARS.length - 1
                    ? `1px solid ${theme.divider}`
                    : "none",
                cursor: "pointer",
                position: "relative",
                background: activeBg,
                transition: "all 0.2s ease",
                minHeight: 84,
                display: "flex",
                flexDirection: "column",
                justifyContent: "flex-start",
                alignItems: "stretch",
                textAlign: "left",
                overflow: "hidden",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-1px)";
                e.currentTarget.style.boxShadow = "0 2px 6px rgba(0,0,0,0.4)";
                e.currentTarget.style.background = hoverBg;
                e.currentTarget.style.boxShadow =
                  "0 4px 16px rgba(59,130,246,0.25)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "none";
                e.currentTarget.style.background = activeBg;
                e.currentTarget.style.boxShadow = "";
              }}
            >
              {/* Top line */}
              <div
                style={{
                  height: 2,
                  background: topLineColor,
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                }}
              />

              {/* Header */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  gap: 10,
                }}
              >
                <div style={{ minWidth: 0 }}>
                  <div
                    style={{ display: "flex", gap: 6, alignItems: "center" }}
                  >
                    {isAll ? (
                      <></>
                    ) : (
                      <span
                        style={{
                          fontWeight: 700,
                          color,
                          fontSize: 14,
                          lineHeight: 1,
                          flexShrink: 0,
                        }}
                      >
                        {p.letter}
                      </span>
                    )}

                    <span
                      style={{
                        fontSize: 12.5,
                        fontWeight: 600,
                        color: theme.textPrimary,
                        lineHeight: 1.2,
                        textAlign: "center",
                        alignItems: "center",
                        marginTop: isAll ? "10px" : "",
                        // whiteSpace: "nowrap",
                        // overflow: "hidden",
                        // textOverflow: "ellipsis",
                      }}
                    >
                      {p.full}
                    </span>
                  </div>
                  {isAll ? (
                    <></>
                  ) : (
                    <div
                      style={{
                        fontSize: 10,
                        color: theme.textTertiary,
                        marginTop: 3,
                        lineHeight: 1.2,
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {p.sub}
                    </div>
                  )}
                </div>
                {isAll ? (
                  <></>
                ) : (
                  <div
                    style={{
                      padding: "3px 8px",
                      background: badgeBg,
                      borderRadius: 999,
                      fontWeight: 700,
                      fontSize: 11.5,
                      color: theme.textPrimary,
                      alignSelf: "flex-start",
                      lineHeight: 1.35,
                      flexShrink: 0,
                      border: isAll
                        ? `1px solid ${isLight ? "#e0e3e7" : theme.divider}`
                        : "none",
                    }}
                  >
                    {total}
                  </div>
                )}
              </div>

              {isAll ? (
                <>
                  {/* Compact All stats to preserve height */}

                  {total > 0 && <></>}
                </>
              ) : (
                <>
                  {/* Regular Details */}
                  <div
                    style={{
                      display: "flex",
                      gap: 10,
                      marginTop: 8,
                      flexWrap: "wrap",
                    }}
                  >
                    <MiniStat
                      count={onTrack}
                      color={theme.onTrack}
                      label="On"
                      textColor={theme.textSecondary}
                    />
                    <MiniStat
                      count={attention}
                      color={theme.attention}
                      label="Att"
                      textColor={theme.textSecondary}
                    />
                    <MiniStat
                      count={offTrack}
                      color={theme.offTrack}
                      label="Off"
                      textColor={theme.textSecondary}
                    />
                  </div>

                  {total > 0 && (
                    <div
                      style={{
                        height: 4,
                        marginTop: 8,
                        display: "flex",
                        borderRadius: 999,
                        overflow: "hidden",
                        background: theme.divider,
                      }}
                    >
                      <div
                        style={{
                          width: `${(onTrack / total) * 100}%`,
                          background: theme.onTrack,
                        }}
                      />
                      <div
                        style={{
                          width: `${(attention / total) * 100}%`,
                          background: theme.attention,
                        }}
                      />
                      <div
                        style={{
                          width: `${(offTrack / total) * 100}%`,
                          background: theme.offTrack,
                        }}
                      />
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MiniStat({
  count,
  color,
  label,
  textColor,
}: {
  count: number;
  color: string;
  label: string;
  textColor: string;
}) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
      <div
        style={{
          width: 6,
          height: 6,
          borderRadius: "50%",
          background: color,
          flexShrink: 0,
        }}
      />
      <span style={{ fontSize: 10, color: textColor, lineHeight: 1 }}>
        {count} {label}
      </span>
    </div>
  );
}

function CompactAllStat({
  count,
  color,
  label,
  textColor,
}: {
  count: number;
  color: string;
  label: string;
  textColor: string;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 4,
        minWidth: 0,
        flex: 1,
        justifyContent: "center",
      }}
    >
      <div
        style={{
          width: 5,
          height: 5,
          borderRadius: "50%",
          background: color,
          flexShrink: 0,
        }}
      />
      <span
        style={{
          fontSize: 9.5,
          color: textColor,
          lineHeight: 1,
          whiteSpace: "nowrap",
        }}
      >
        {count} {label}
      </span>
    </div>
  );
}
