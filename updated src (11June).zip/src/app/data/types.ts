export type Tower = "Focus" | "Accelerate" | "Scale" | "Transform";

export interface Team {
  id: string;
  name: string;
  leader: string;
}

export interface Priority {
  id: string;
  name: string;
}

export interface Initiative {
  id: string;
  priority: string;
  team: string;
  name: string;
  owner: string;
  tower: Tower;
  status: string;
  towerTeam: string;
  timeline: string;
  budget: string;
  outcome: string;
  timelineStatus: string;
  budgetStatus: string;
  outcomeStatus: string;
  error: boolean;
  hasdata: boolean;
}
