import { useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
} from "lucide-react";
import type { Initiative, Pillar, Status } from "../data/initiatives";
import { useTheme } from "../theme-context";

interface InitiativeTableProps {
  initiatives: Initiative[];
  groupByPillar?: boolean;
}

const COLS = "28px 24px 35px 230px 120px 70px 70px 90px 80px 90px 88px 90px";

export function InitiativeTable({ initiatives }: InitiativeTableProps) {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [sortField, setSortField] = useState("status");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const toggleRow = (name: string) =>
    setExpandedRows((p) => {
      const n = new Set(p);
      n.has(name) ? n.delete(name) : n.add(name);
      return n;
    });

  const sorted = [...initiatives].sort((a, b) => {
    // Default to Pillar order if no sort field is selected
    if (!sortField) {
      const pillarOrder = {
        Focus: 0,
        Acceleration: 1,
        Scale: 2,
        Transform: 3,
      };
      return pillarOrder[a.pillar] - pillarOrder[b.pillar];
    }
    const statusOrder = {
      "off-track": 0,
      attention: 1,
      "on-track": 2,
    };
    if (sortField === "status") {
      const d = statusOrder[a.status] - statusOrder[b.status];
      return sortDir === "asc" ? d : -d;
    }
    if (sortField === "progress") {
      const d = a.progress - b.progress;
      return sortDir === "asc" ? d : -d;
    }
    if (sortField === "dueDate") {
      const d = a.dueDate.localeCompare(b.dueDate);
      return sortDir === "asc" ? d : -d;
    }
    return 0;
  });

  const handleSort = (field: string) => {
    if (sortField === field) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortField(field);
      setSortDir("asc");
    }
  };

  const PILLAR_INFO: Record<Pillar, { color: string; letter: string }> = {
    Focus: { color: theme.pillarFast, letter: "F" },
    Acceleration: { color: theme.pillarAccel, letter: "A" },
    Scale: { color: theme.pillarScale, letter: "S" },
    Transform: { color: theme.pillarTrans, letter: "T" },
  };

  const STATUS = {
    "on-track": {
      label: "On Track",
      color: theme.onTrack,
      bg: theme.onTrackBg,
      border: theme.onTrackBorder,
      Icon: CheckCircle2,
    },
    "off-track": {
      label: "Off Track",
      color: theme.offTrack,
      bg: theme.offTrackBg,
      border: theme.offTrackBorder,
      Icon: XCircle,
    },
    attention: {
      label: "Needs Attention",
      color: theme.attention,
      bg: theme.attentionBg,
      border: theme.attentionBorder,
      Icon: AlertTriangle,
    },
  };

  const PRIORITY = {
    Critical: { color: theme.offTrack, bg: theme.offTrackBg },
    High: { color: theme.attention, bg: theme.attentionBg },
    Medium: {
      color: theme.textTertiary,
      bg: isLight ? "#f1f3f4" : theme.elevated,
    },
  };

  const headerBg = isLight ? "#f8f9fa" : "#0c1018";
  const rowEvenBg = isLight ? "#ffffff" : "#0f1117";
  const rowOddBg = isLight ? "#fafafa" : "#111521";
  const rowExpandBg = isLight ? "#f0f4ff" : "rgba(66,133,244,0.05)";

  if (initiatives.length === 0) {
    return (
      <div
        style={{
          padding: 56,
          textAlign: "center",
          color: theme.textTertiary,
        }}
      >
        <div style={{ fontSize: 32, marginBottom: 8 }}>—</div>
        <div style={{ fontSize: 13 }}>
          No initiatives match the current filters.
        </div>
      </div>
    );
  }

  return (
    <div style={{ width: "100%" }}>
      {/* Column headers */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: COLS,
          padding: "8px 16px",
          background: headerBg,
          borderBottom: `1px solid ${theme.borderStrong}`,
          position: "sticky",
          top: 0,
          zIndex: 10,
        }}
      >
        {[
          { label: "", field: "" },
          { label: "", field: "" },
          { label: "ID", field: "" },
          { label: "Initiative", field: "" },
          { label: "Status", field: "status" },
          { label: "Priority", field: "priorityWeight" },
          { label: "Budget", field: "overallBudget" },
          { label: "Leader", field: "" },
          { label: "Start Date", field: "startDate" },
          { label: "Due Date", field: "dueDate" },
          { label: "Category", field: "" },
          { label: "% Completion", field: "" },
        ].map((col, i) => (
          <div
            key={i}
            onClick={() => col.field && handleSort(col.field)}
            style={{
              color: theme.textTertiary,
              fontSize: 10,
              fontWeight: 700,
              letterSpacing: "0.08em",
              cursor: col.field ? "pointer" : "default",
              display: "flex",
              alignItems: "center",
              gap: 3,
              padding: "0 4px",
              userSelect: "none",
            }}
          >
            {col.label.toUpperCase()}
            {col.field && col.field === sortField && (
              <span style={{ color: theme.brandPrimary }}>
                {sortDir === "asc" ? " ↑" : " ↓"}
              </span>
            )}
          </div>
        ))}
      </div>

      <div
        style={{
          background: isLight ? "rgba(0,0,0,0.005)" : "rgba(255,255,255,0.005)",
        }}
      >
        {sorted.map((ini, idx) => {
          const key = ini.pillar?.trim() as keyof typeof PILLAR_INFO;
          const pInfo = PILLAR_INFO[key] ?? { letter: "?", color: "#999" };
          return (
            <InitiativeRow
              key={ini.name}
              ini={ini}
              idx={idx}
              pillarLetter={pInfo.letter}
              pillarColor={pInfo.color}
              expanded={expandedRows.has(ini.name)}
              onToggle={() => toggleRow(ini.name)}
              theme={theme}
              isLight={isLight}
              STATUS={STATUS}
              PRIORITY={PRIORITY}
              rowExpandBg={rowExpandBg}
              rowEvenBg={rowEvenBg}
              rowOddBg={rowOddBg}
            />
          );
        })}
      </div>
    </div>
  );
}

function InitiativeRow({
  ini,
  idx,
  pillarLetter,
  pillarColor,
  expanded,
  onToggle,
  theme,
  isLight,
  STATUS,
  PRIORITY,
  rowExpandBg,
  rowEvenBg,
  rowOddBg,
}: {
  ini: Initiative;
  idx: number;
  pillarLetter: string;
  pillarColor: string;
  expanded: boolean;
  onToggle: () => void;
  theme: any;
  isLight: boolean;
  STATUS: any;
  PRIORITY: any;
  rowExpandBg: string;
  rowEvenBg: string;
  rowOddBg: string;
}) {
  const sm = STATUS[ini.status];
  const pm = PRIORITY[ini.priority];
  const days = Math.ceil(
    (new Date(ini.dueDate).getTime() - Date.now()) / 86400000
  );
  const overdue = days < 0;
  const soon = days >= 0 && days <= 30;

  return (
    <div>
      <div
        onClick={onToggle}
        style={{
          display: "grid",
          gridTemplateColumns: COLS,
          padding: "9px 16px",
          background: expanded
            ? rowExpandBg
            : idx % 2 === 0
            ? rowEvenBg
            : rowOddBg,
          borderBottom: `1px solid ${theme.divider}`,
          cursor: "pointer",
          borderLeft: expanded
            ? `3px solid ${sm.color}`
            : "3px solid transparent",
          transition: "background 0.12s",
        }}
      >
        <C center>
          <div
            style={{
              width: 18,
              height: 18,
              borderRadius: 4,
              background: `${pillarColor}15`,
              border: `1px solid ${pillarColor}40`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 9,
              fontWeight: 800,
              color: pillarColor,
            }}
            title={ini.pillar}
          >
            {pillarLetter}
          </div>
        </C>
        <C center>
          {expanded ? (
            <ChevronDown size={12} color={theme.textTertiary} />
          ) : (
            <ChevronRight size={12} color={theme.textTertiary} />
          )}
        </C>
        <C>
          <span
            style={{
              color: theme.textTertiary,
              fontSize: 10,
              fontFamily: "var(--font-mono)",
              width: "fit-content",
            }}
          >
            {ini.id}
          </span>
        </C>
        <C>
          <span
            style={{
              color: theme.textPrimary,
              fontSize: 12,
              fontWeight: 500,
              // whiteSpace: "nowrap",
              // overflow: "visible",
              // textOverflow: "ellipsis",
              width: "fit-content",
              minWidth: 0,
              display: "block",
            }}
          >
            {ini.name}
          </span>
        </C>
        <C>
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 2,
              padding: "3px 8px",
              borderRadius: 12,
              background: sm.bg,
              border: `1px solid ${sm.border}`,
            }}
          >
            <sm.Icon size={9} color={sm.color} strokeWidth={2.5} />
            <span
              style={{
                color: sm.color,
                fontSize: 10,
                fontWeight: 600,
                whiteSpace: "nowrap",
              }}
            >
              {sm.label}
            </span>
          </div>
        </C>
        <C>
          <div>
            <span
              style={{
                color: theme.textSecondary,
                fontSize: 11,
              }}
            >
              {ini.priorityWeight}
            </span>
          </div>
        </C>
        <C>
          <div>
            <span
              style={{
                color: theme.textSecondary,
                fontSize: 11,
              }}
            >
              {ini.overallBudget}
            </span>
          </div>
        </C>
        <C>
          <div>
            <span
              style={{
                color: theme.textSecondary,
                fontSize: 11,
              }}
            >
              {ini.leader}
            </span>
            {ini.coleaders && (
              <div
                style={{
                  color: theme.textTertiary,
                  fontSize: 9,
                  marginTop: 1,
                }}
              >
                {ini.coleaders}
              </div>
            )}
          </div>
        </C>
        <C>
          <span
            style={{
              color: theme.textTertiary,
              fontSize: 10,
              fontFamily: "var(--font-mono)",
            }}
          >
            {ini.startDate || "2026-06-01"}
          </span>
        </C>
        <C>
          <span
            style={{
              color: "green",
              fontSize: 10,
              fontFamily: "var(--font-mono)",
              display: "flex",
              alignItems: "center",
              gap: 3,
            }}
          >
            {/* {(overdue || soon) && (
              <Clock
                size={9}
                color={overdue ? theme.offTrack : theme.attention}
              />
            )} */}
            <Clock size={9} color={theme.onTrack} />
            {ini.dueDate}
          </span>
        </C>
        <C>
          <span
            style={{
              padding: "2px 6px",
              borderRadius: 8,
              background: isLight ? "#f1f3f4" : "rgba(255,255,255,0.06)",
              color: theme.textTertiary,
              fontSize: 9,
              fontWeight: 500,
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              maxWidth: 86,
              display: "block",
            }}
            title={ini.category}
          >
            {ini.category}
          </span>
        </C>
        <C>
          <div>
            <div
              style={{
                color: theme.textSecondary,
                fontSize: 11,
                fontFamily: "var(--font-mono)",
                fontWeight: 500,
              }}
            >
              {ini.budget}
            </div>
            <div
              style={{
                color: theme.textTertiary,
                fontSize: 9,
                fontFamily: "var(--font-mono)",
                marginTop: 1,
              }}
            >
              {ini.totalTarget} target
            </div>
          </div>
        </C>
      </div>

      {expanded && <ExpandedDetail ini={ini} sm={sm} />}
    </div>
  );
}

function C({
  children,
  center,
}: {
  children: React.ReactNode;
  center?: boolean;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: center ? "center" : "flex-start",
        padding: "0 4px",
        minWidth: 0,
        overflow: "hidden",
      }}
    >
      {children}
    </div>
  );
}

function GS({
  count,
  color,
  label,
}: {
  count: number;
  color: string;
  label: string;
}) {
  const { theme } = useTheme();
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
      <div
        style={{
          width: 7,
          height: 7,
          borderRadius: "50%",
          background: color,
        }}
      />
      <span style={{ color, fontSize: 10, fontWeight: 700 }}>{count}</span>
      <span style={{ color: theme.textTertiary, fontSize: 10 }}>{label}</span>
    </div>
  );
}

function ExpandedDetail({
  ini,
  sm,
}: {
  ini: Initiative;
  sm: { color: string; bg: string; border: string };
}) {
  const { theme } = useTheme();
  const isLight = theme.mode === "light";
  const done = ini.milestones.filter((m) => m.done).length;
  const panelBg = isLight ? "#f8f9ff" : "#0b1120";
  const cardBg = isLight ? "#ffffff" : "#111827";
  const trackBg = isLight ? "#e8eaed" : "rgba(255,255,255,0.07)";

  const STATUS_COLOR: Record<Status, string> = {
    "on-track": theme.onTrack,
    "off-track": theme.offTrack,
    attention: theme.attention,
  };
  const STATUS_BG: Record<Status, string> = {
    "on-track": theme.onTrackBg,
    "off-track": theme.offTrackBg,
    attention: theme.attentionBg,
  };
  const STATUS_BORDER: Record<Status, string> = {
    "on-track": theme.onTrackBorder,
    "off-track": theme.offTrackBorder,
    attention: theme.attentionBorder,
  };
  const TREND_ICON: Record<string, string> = {
    up: "↑",
    down: "↓",
    flat: "→",
  };
  const TREND_COLOR = (trend: string, kpiStatus: Status) => {
    if (trend === "flat") return theme.textTertiary;
    return STATUS_COLOR[kpiStatus];
  };

  const formatValue = (label: string, value: string, unit: string) => {
    const num = parseFloat(value);
    const labelUpper = label.toUpperCase();

    const isCustomerCount = labelUpper.includes("CUSTOMER COUNT");
    const isPercentMetric = labelUpper.includes("%") || unit === "%";

    if (isCustomerCount) {
      return `${num}`;
    }

    if (isPercentMetric) {
      return `${num}%`;
    }

    if (unit === "M") {
      if (num >= 1) {
        return `$${num} M`;
      }

      if (num >= 0.001) {
        return `$${(num * 1000).toFixed(1)} K`;
      }
    }

    return `${value} ${unit || ""}`.trim();
  };

  return (
    <div
      style={{
        background: panelBg,
        borderBottom: `1px solid ${theme.border}`,
        borderLeft: `3px solid ${sm.color}`,
      }}
    >
      {/* ── Row 1: Status note + KPIs ── */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "415px 1fr",
          gap: 0,
          borderBottom: `1px solid ${theme.divider}`,
        }}
      >
        {/* Status note */}
        <div
          style={{
            padding: "16px 20px 16px 52px",
            borderRight: `1px solid ${theme.divider}`,
          }}
        >
          <SL>STATUS UPDATE</SL>
          <div
            style={{
              padding: "10px 12px",
              background: `${sm.color}0e`,
              border: `1px solid ${sm.color}28`,
              borderRadius: 8,
              color: theme.textSecondary,
              fontSize: 12,
              lineHeight: 1.65,
              marginBottom: 8,
            }}
          >
            {ini.statusNote}
          </div>
          {ini.coleaders && (
            <div
              style={{
                marginTop: 6,
                padding: "4px 8px",
                background: isLight ? "#f1f3f4" : "rgba(255,255,255,0.04)",
                borderRadius: 6,
                fontSize: 10,
                color: theme.textTertiary,
              }}
            >
              <span style={{ fontWeight: 600 }}>Co-leads:</span> {ini.coleaders}
            </div>
          )}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginTop: 4,
            }}
          >
            <div
              style={{
                color: theme.textTertiary,
                fontSize: 10,
                margin: "0 0 0 8px",
              }}
            >
              Updated {ini.lastUpdated}
            </div>
            <div
              style={{
                padding: "2px 8px",
                borderRadius: 10,
                background: isLight ? "#f1f3f4" : "rgba(255,255,255,0.06)",
                color: theme.textTertiary,
                fontSize: 9,
                fontWeight: 600,
                letterSpacing: "0.04em",
                whiteSpace: "nowrap",
              }}
            >
              {ini.tower}
            </div>
          </div>

          {/* Budget and Execution progress */}
          <div
            style={{
              marginTop: 14,
              display: "grid",
              gridTemplateColumns: "1fr 0fr",
              gap: 0,
            }}
          >
            <div
              style={{
                background: "white",
                padding: "10px",
                borderRadius: "10px",
              }}
            >
              {ini.name === "GPT Global Delivery Model" ? (
                <SL>OVERALL COST REALIZED</SL>
              ) : ini.name === "Vendor Management(TESM)" ? (
                <SL>OVERALL COST REALIZED</SL>
              ) : (
                <SL>OVERALL EXECUTION</SL>
              )}
              {ini.name === "GPT Global Delivery Model" ? (
                <>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginBottom: "10px",
                    }}
                  >
                    <span
                      style={{
                        color: theme.textTertiary,
                        fontSize: 9,
                        fontWeight: 600,
                      }}
                    >
                      $~1M
                    </span>

                    <span
                      style={{
                        color: theme.textTertiary,
                        fontSize: 9,
                        fontWeight: 600,
                      }}
                    >
                      Target: $70M
                    </span>
                  </div>
                  <div
                    style={{
                      height: 5,
                      borderRadius: 3,
                      background: trackBg,
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${ini.progress}%`,
                        height: "100%",
                        background: STATUS_COLOR[ini.status],
                        borderRadius: 3,
                      }}
                    />
                  </div>
                </>
              ) : ini.name === "Vendor Management(TESM)" ? (
                <>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginBottom: "10px",
                    }}
                  >
                    <span
                      style={{
                        color: theme.textTertiary,
                        fontSize: 9,
                        fontWeight: 600,
                      }}
                    >
                      $~2M
                    </span>

                    <span
                      style={{
                        color: theme.textTertiary,
                        fontSize: 9,
                        fontWeight: 600,
                      }}
                    >
                      Target: $140M
                    </span>
                  </div>
                  <div
                    style={{
                      height: 5,
                      borderRadius: 3,
                      background: trackBg,
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${ini.progress}%`,
                        height: "100%",
                        background: STATUS_COLOR[ini.status],
                        borderRadius: 3,
                      }}
                    />
                  </div>
                </>
              ) : (
                <>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginBottom: 5,
                    }}
                  >
                    <span
                      style={{
                        color: theme.textTertiary,
                        fontSize: 11,
                      }}
                    >
                      {/* Cost Saving Realized for FY29 Goal */}
                      {ini.name === "Vendor Management(TESM)"
                        ? "Total Cost Savings Realized towards FY29 goal"
                        : "Cost Saving Realized for FY29 Goal"}
                    </span>
                    {ini.id === "T02" ? (
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "flex-end",
                          lineHeight: 1.2,
                        }}
                      >
                        <span
                          style={{
                            color: theme.textTertiary,
                            fontSize: 9,
                            fontWeight: 600,
                          }}
                        >
                          Target 20%
                        </span>

                        <span
                          style={{
                            color: STATUS_COLOR[ini.status],
                            fontSize: 11,
                            fontFamily: "var(--font-mono)",
                            fontWeight: 600,
                          }}
                        >
                          {ini.progress}%
                        </span>
                      </div>
                    ) : (
                      <span
                        style={{
                          color: STATUS_COLOR[ini.status],
                          fontSize: 11,
                          fontFamily: "var(--font-mono)",
                          fontWeight: 600,
                        }}
                      >
                        {ini.name === "Vendor Management(TESM)"
                          ? "$28M/$140M"
                          : `${ini.progress}%`}
                      </span>
                    )}
                  </div>
                  <div
                    style={{
                      height: 5,
                      borderRadius: 3,
                      background: trackBg,
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${ini.progress}%`,
                        height: "100%",
                        background: STATUS_COLOR[ini.status],
                        borderRadius: 3,
                      }}
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* KPI cards */}
        <div style={{ padding: "14px 20px 14px 16px" }}>
          <SL>KEY PERFORMANCE INDICATORS</SL>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: `repeat(${ini.kpis.length}, 1fr)`,
              gap: 10,
            }}
          >
            {ini.kpis.map((kpi, i) => {
              const kColor = STATUS_COLOR[kpi.status];
              const kBg = STATUS_BG[kpi.status];
              const kBdr = STATUS_BORDER[kpi.status];

              const isPercent = kpi.unit === "%";
              const isGST = ini.id === "T02";

              const progress =
                parseFloat(kpi.target) > 0
                  ? (parseFloat(kpi.value) / parseFloat(kpi.target)) * 100
                  : 0;
              return (
                <div
                  key={i}
                  style={{
                    background: cardBg,
                    border: `1px solid ${kBdr}`,
                    borderRadius: 10,
                    padding: "12px 14px 18px 14px",
                    position: "relative",
                    overflow: "hidden",
                    boxShadow: isLight ? theme.shadow : "none",
                  }}
                >
                  {/* Top accent */}
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      right: 0,
                      height: 3,
                      background: kColor,
                      opacity: 0.7,
                    }}
                  />
                  <div
                    style={{
                      color: theme.textTertiary,
                      fontSize: 9,
                      fontWeight: 700,
                      letterSpacing: "0.1em",
                      marginBottom: 8,
                      marginTop: 2,
                    }}
                  >
                    {kpi.label.toUpperCase()}
                  </div>

                  {/* Value vs target */}
                  <div
                    style={{
                      display: "flex",
                      alignItems: "baseline",
                      gap: 6,
                      marginBottom: 4,
                    }}
                  >
                    <span
                      style={{
                        color: theme.textPrimary,
                        fontSize: 22,
                        fontWeight: 700,
                        fontFamily: "var(--font-mono)",
                        lineHeight: 1,
                        letterSpacing: "-0.02em",
                        marginBottom: 10,
                      }}
                    >
                      {formatValue(kpi.label, kpi.value, kpi.unit)}
                    </span>
                  </div>

                  {/* Target */}
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 5,
                      marginBottom: 8,
                    }}
                  >
                    <span
                      style={{
                        color: theme.textTertiary,
                        fontSize: 10,
                      }}
                    >
                      Target:
                    </span>
                    <span
                      style={{
                        color: theme.textSecondary,
                        fontSize: 10,
                        fontFamily: "var(--font-mono)",
                        fontWeight: 500,
                      }}
                    >
                      {formatValue(kpi.label, kpi.target, kpi.unit)}
                    </span>
                  </div>

                  {/* Progress bar: value vs target (numeric only) */}
                  {!isNaN(parseFloat(kpi.value)) &&
                    !isNaN(parseFloat(kpi.target)) &&
                    parseFloat(kpi.target) > 0 && (
                      <div
                        style={{
                          height: 4,
                          borderRadius: 2,
                          background: trackBg,
                          overflow: "hidden",
                          marginBottom: 20,
                        }}
                      >
                        <div
                          style={{
                            width: `${Math.min(100, progress)}%`,
                            height: "100%",
                            background: kColor,
                            borderRadius: 2,
                          }}
                        />
                      </div>
                    )}

                  {/* Trend pill */}
                  <div
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 4,
                      padding: "2px 7px",
                      borderRadius: 10,
                      background: kBg,
                      border: `1px solid ${kBdr}`,
                    }}
                  >
                    <span
                      style={{
                        color: TREND_COLOR(kpi.trend, kpi.status),
                        fontSize: 10,
                        fontWeight: 700,
                      }}
                    >
                      {TREND_ICON[kpi.trend]}
                    </span>
                    <span
                      style={{
                        color: kColor,
                        fontSize: 9,
                        fontWeight: 600,
                      }}
                    >
                      {kpi.trendValue}
                    </span>
                  </div>

                  {kpi.label.toLowerCase().includes("total revenue") && (
                    <div
                      style={{
                        position: "absolute",
                        bottom: 15,
                        right: 12,
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "flex-end",
                        gap: 0,
                        fontSize: 9,
                        fontWeight: 600,
                        color: theme.textTertiary,
                        lineHeight: 1.9,
                        whiteSpace: "nowrap",
                      }}
                    >
                      <span>MoM: {kpi.momTrend ?? "94:6"}</span>
                      <span>QoQ: {kpi.qoqTrend ?? "80:20"}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function SL({ children }: { children: React.ReactNode }) {
  const { theme } = useTheme();
  return (
    <div
      style={{
        color: theme.textTertiary,
        fontSize: 9,
        fontWeight: 700,
        letterSpacing: "0.12em",
        marginBottom: 8,
      }}
    >
      {children}
    </div>
  );
}
