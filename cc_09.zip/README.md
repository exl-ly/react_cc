
  # Executive Dashboard Builder

  This is a code bundle for Executive Dashboard Builder. The original project is available at https://www.figma.com/design/thHlWyI0frUbDDw8DT6JOa/Executive-Dashboard-Builder.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  